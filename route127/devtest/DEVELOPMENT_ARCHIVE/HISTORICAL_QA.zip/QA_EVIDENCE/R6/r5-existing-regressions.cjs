const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const dir=process.env.ROUTE127_SOURCE||path.join(__dirname,'..','route127_r6');
class Element{
 constructor(){this.childNodes=[];this.children=this.childNodes;this.style={};this.dataset={};this.value='';this.disabled=false;this._text='';this.hidden=false;this.classList={add(){},remove(){},toggle(){},contains(){return false}};}
 appendChild(n){this.childNodes.push(n);n.parentElement=this;return n} append(n){this.appendChild(n)}
 set textContent(v){this._text=String(v);this.childNodes=[]}get textContent(){return this._text+this.childNodes.map(x=>x.textContent||'').join('')}
 set innerHTML(v){this._text='';this.childNodes=[]}get innerHTML(){return this.textContent}
 addEventListener(){} focus(){}querySelectorAll(){return []}querySelector(){return null}setAttribute(){}removeAttribute(){}insertAdjacentElement(_,n){this.appendChild(n)}getBoundingClientRect(){return {width:100,height:100}}remove(){}
}
const nodes={};const node=k=>nodes[k]||(nodes[k]=new Element());node('.utility-name').childNodes=[{nodeValue:''}];node('#side-inv').parentElement=new Element();
const storage=new Map();let clock=Date.now(),roll=.2;
const ctx=vm.createContext({console,document:{querySelector:node,querySelectorAll:()=>[],createElement:()=>new Element(),createTextNode:s=>({textContent:s}),body:new Element()},window:{ROUTE127_QA_BUILD:true,addEventListener(){}},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},setTimeout:(fn,ms)=>{if(ms<15000)queueMicrotask(fn);return 1},clearTimeout(){},setInterval:()=>1,clearInterval(){},Date:class extends Date{static now(){return clock}},Math:Object.assign(Object.create(Math),{random:()=>roll}),performance:{now:()=>clock},requestAnimationFrame:()=>1,cancelAnimationFrame(){}});
for(const file of ['app.js','casino.js','polish.js','expansion.js','crime.js','consolidation.js','factory.js','seaport.js','wanderer_fix.js','v55.js','recruitment.js','stabilization.js','final_polish.js']){let s=fs.readFileSync(path.join(dir,file),'utf8');if(file==='app.js')s=s.replace(/startRefillTimer\(\);\s*titleScreen\(\);\s*$/,'');vm.runInContext(s,ctx,{filename:file});}
const run=s=>vm.runInContext(s,ctx),text=()=>node('#screen').textContent,lines=()=>node('#screen').childNodes.map(x=>x.textContent),results=[];
async function drain(){for(let i=0;i<8;i++)await run('outputQueue')}
async function command(s){await run(`handleCommand(${JSON.stringify(s)})`);await drain()}
async function reset(){await drain();storage.clear();run(`resetPlayer();stage='mercy';mercyLocation='town';player.handle='RepairQA';player.flags.interfaceUnlocked=true;player.flags.mainSolaceQuest='complete';player.flags.mercyDiscovered=true;player.hp=player.maxHp;currentHotkeys={};numberedChoices={};busy=false;activeSaveSlot=1;`);node('#screen').innerHTML='';}
async function test(name,fn){try{await reset();await fn();await drain();results.push({name,pass:true})}catch(e){results.push({name,pass:false,error:e.stack,state:run('JSON.stringify({stage,flags:player.flags})'),tail:lines().slice(-35)});}}
async function choose(label){await drain();const map=run('numberedChoices'),key=Object.keys(map).find(k=>map[k]===label.toLowerCase());assert(key,'Missing numbered choice '+label+': '+JSON.stringify(map));await command(key);}
async function road(name='June',unlocked=true){run(`stage='wandererRoad';currentRoadWanderer=${JSON.stringify(name)};player.bolts=1000;port55State().freed=${unlocked};port55State().stage=${unlocked?"'done'":"'investigate'"};v53WandererMenu(wandererByName(currentRoadWanderer),true)`);await drain();}
async function hire(name='June'){await road(name);await choose('recruit');await choose('confirm hire');assert(run(`portIsHired(${JSON.stringify(name)})`));}
async function building(role,name){run(`stage='seaport'`);await command(role);if(name){await choose('assign staff');await choose('assign '+name);await choose('confirm assignment');}assert.equal(run('stage'),'port55Service');}
(async()=>{
await test('Murphy main and Talk render exactly one menu through command pipeline',async()=>{await command('murphy');assert.equal(lines().filter(x=>x==="MURPHY'S WORKSHOP").length,1);await command('3');assert.equal(lines().filter(x=>x==='MURPHY — TALK').length,1);assert.equal(run("numberedChoices['3']"),'ask about relay station');});
await test('Save and load menus do not trigger duplicate fallback',async()=>{await command('save');assert.equal(lines().filter(x=>x==='SAVE / LOAD').length,1);await command('1');assert.equal(lines().filter(x=>x==='SAVE / LOAD').length,2);await command('2');assert.equal(lines().filter(x=>x==='SAVE / LOAD').length,2);assert(text().includes('LOAD GAME — SELECT A SLOT'));});
await test('Combat entry visibly renders one actionable menu and numeric attack works',async()=>{run(`startCombat({name:'QA ENEMY',level:1,hp:50,min:1,max:1,xp:0,bolts:0},'encounter')`);await drain();assert.equal(lines().filter(x=>x.includes('[1] ATTACK')).length,1);assert.equal(run("numberedChoices['1']"),'attack');await command('1');assert(run('combatState.hp')<50);});
await test('Combat items render once and healing consumes one item',async()=>{run(`player.hp=30;startCombat({name:'QA ENEMY',level:1,hp:50,min:1,max:1,xp:0,bolts:0},'encounter')`);await drain();await command('2');assert.equal(lines().filter(x=>x.includes('COMBAT ITEMS')).length,1);await command('1');assert.equal(run('player.hp'),40);assert.equal(run("findItem('Energy Bars').qty"),1);});
await test('R6 full backpack boss equipment goes safely to bank without dropping equipped gear',async()=>{run("player.packMax=0;player.weapon='Rusted Pipe';factoryAwardBossWeapon(1)");await drain();assert(run("player.stash.some(x=>GEAR[x.name]?.rarity==='rare')"));assert.equal(run('player.weapon'),'Rusted Pipe');});
await test('Full backpack holds finished bandage then permits collection',async()=>{run(`stage='factoryBench';player.packMax=0;player.flags.v49Job={endsAt:0,success:true};v49Workbench()`);await drain();await command('collect result');assert(run('!!player.flags.v49Job'));assert(text().includes('HELD AT BENCH'));assert(!text().includes('leave Reinforced Bandage behind'));run('player.packMax=10');await command('collect result');assert(run("hasItem('Reinforced Bandage')"));assert(run('player.flags.v49RecipeBandage'));});
await test('Cleared boss rooms and Inspect no longer describe waiting bosses',async()=>{run(`factoryState().done=[0,1,2,3];factoryState().floor=1;factoryState().room=5;stage='factoryDungeonRoom';factoryRender()`);await drain();await command('inspect');assert(!text().includes('worker waits'));assert(text().includes('Grinder has been defeated'));});
await test('R2 numeric clinic sale accepts spare Common and Rare gear with confirmation',async()=>{
 run(`stage='mercy';mercyLocation='wayne';player.bolts=100;player.weapon='Rusted Pipe';player.armor='Worn Jacket';player.pack=[];addPack('Canvas Coat','armor');addPack("King's Breaker",'weapon');player.armor='Canvas Coat';player.pack[0].name='Worn Jacket'`);
 await command('sell items');await command('1');assert.equal(run('player.flags.v53Sale?.name'),'Worn Jacket');
 await command('1');assert.equal(run('player.flags.v53Sale.mode'),'confirm');await command('1');
 assert(!run("hasItem('Worn Jacket')"));assert.equal(run('player.bolts'),102);
 await command('1');assert.equal(run('player.flags.v53Sale?.name'),"King's Breaker");await command('1');assert.equal(run('player.bolts'),102);await command('1');assert.equal(run('player.bolts'),133);assert(!run(`hasItem("King's Breaker")`));
 run(`addPack('Canvas Coat','armor');addPack('Prepared Dynamite Charge','quest');GEAR['QA Legendary']={rarity:'legendary',type:'weapon'};addPack('QA Legendary','weapon')`);
 assert.equal(run("v48SellPrice(findItem('Canvas Coat'))"),0);assert.equal(run("v48SellPrice(findItem('Prepared Dynamite Charge'))"),0);assert.equal(run("v48SellPrice(findItem('QA Legendary'))"),0);
});
await test('R2 map identifies Seaport, submenus, road and obstruction including overlay/reload',async()=>{
 run(`player.level=7;roadGoal='east';stage='seaport';port55State().freed=true;updateHud()`);await command('town streets');assert(node('#live-map').textContent.startsWith('SEAPORT'));
 await command('q');assert(node('#live-map').textContent.startsWith('SEAPORT'));run('saveGame(1);loadGame(1)');await drain();assert(node('#live-map').textContent.startsWith('SEAPORT'));
 run(`stage='portRoad';portState().position=3;v49LiveMap()`);assert(node('#live-map').textContent.includes('SEAPORT ROAD'));assert(node('#live-map').textContent.includes('<YOU>'));
 run(`stage='portObstruction';v49LiveMap()`);assert(node('#live-map').textContent.includes('COLLAPSED OVERPASS'));
 run(`stage='port55Pets';returnStage='mercy';mercyLocation='town';v49LiveMap()`);assert(node('#live-map').textContent.startsWith('SOLACE'));
 run(`returnStage='seaport';v49LiveMap()`);assert(node('#live-map').textContent.startsWith('SEAPORT'));
 run(`player.level=4;v49LiveMap()`);assert.equal(node('#live-map').hidden,true);
});
await test('R2 clinic death-reset notice only when an actual death streak is cleared',async()=>{
 run(`stage='mercy';mercyLocation='wayne';player.hp=50;player.bolts=100;player.deathStreak=0`);await command('treat wounds');assert(!text().includes('DEATH PENALTY RESET'));assert.equal(run('player.hp'),100);
 node('#screen').innerHTML='';run(`player.hp=90;player.deathStreak=2`);await command('treat wounds');assert(text().includes('DEATH PENALTY RESET'));assert.equal(run('player.deathStreak'),0);
 node('#screen').innerHTML='';run(`player.hp=50;player.bolts=1;player.deathStreak=2`);await command('treat wounds');assert(!text().includes('DEATH PENALTY RESET'));assert.equal(run('player.deathStreak'),2);
});
await test('R2 quick controls refresh immediately after Seaport combat victory',async()=>{
 run(`stage='seaport';startCombat({name:'QA ENFORCER',level:1,hp:1,min:1,max:1,xp:0,bolts:0},'seaportLiberation')`);await drain();
 assert(node('#utility-panel button:nth-of-type(2)').textContent.includes('USE ITEM'));
 await command('1');assert.equal(run('stage'),'port55Docks');assert.equal(node('#utility-panel button:nth-of-type(2)').textContent,'(I) INVENTORY');assert.equal(node('#utility-panel button:nth-of-type(2)').dataset.command,'inventory');
});

await test('R3 Manage Pets numeric equip, switch, unequip, reload and overlay exits',async()=>{
 run(`stage='seaport';port55State().freed=true;player.flags.ownedPets=['Scrap Rat','Ferret'];`);
 await command('i');await command('manage pets');await command('1');assert.equal(run('player.flags.equippedPet'),'Scrap Rat');
 await command('2');assert.equal(run('player.flags.equippedPet'),'Ferret');await command('3');assert.equal(run('player.flags.equippedPet'),null);
 await command('2');run('saveGame(1);loadGame(1)');await drain();assert.equal(run('player.flags.equippedPet'),'Ferret');
 await command('i');await command('manage pets');await command('i');await command('b');assert.equal(run('stage'),'seaport');
 await command('i');await command('manage pets');await command('4');assert.equal(run('stage'),'inventory');await command('b');assert.equal(run('stage'),'seaport');
 await command('i');await command('manage pets');await command('b');await command('b');assert.equal(run('stage'),'seaport');
});
await test('R6 five-step return ends at crossroads; selecting destination is free even exhausted',async()=>{run("stage='seaport';player.flags.portRoadCleared=true;player.turns=5");await command('return west');assert.equal(run('player.turns'),5);for(let i=0;i<5;i++){run('r6Move();combatState=null;if(r6Road().active)completeRoadTurn()');}await drain();assert.equal(run('stage'),'eastEnd');assert.equal(run('player.turns'),0);});

fs.writeFileSync(path.join(dir,'QA_EVIDENCE/r5-existing-results.json'),JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2));process.exit(results.some(x=>!x.pass)?1:0);})();