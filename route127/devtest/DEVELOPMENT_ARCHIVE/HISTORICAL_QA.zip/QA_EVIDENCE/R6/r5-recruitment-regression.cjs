const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const dir=process.env.ROUTE127_SOURCE||path.join(__dirname,'..','route127_r6');
class Element{
 constructor(){this.childNodes=[];this.children=this.childNodes;this.style={};this.dataset={};this.value='';this.disabled=false;this._text='';this.hidden=false;this.classList={add(){},remove(){},toggle(){},contains(){return false}};}
 appendChild(n){this.childNodes.push(n);n.parentElement=this;return n} append(n){this.appendChild(n)}
 set textContent(v){this._text=String(v);this.childNodes=[]}get textContent(){return this._text+this.childNodes.map(x=>x.textContent||'').join('')}
 set innerHTML(v){this._text='';this.childNodes=[]}get innerHTML(){return this.textContent}
 addEventListener(){} focus(){}querySelectorAll(){return []}querySelector(){return null}setAttribute(){}removeAttribute(){}insertAdjacentElement(_,n){this.appendChild(n)}getBoundingClientRect(){return {width:100,height:100}}remove(){}
}
const nodes={};const node=k=>nodes[k]||(nodes[k]=new Element());node('.utility-name').childNodes=[{nodeValue:''}];node('#side-inv').parentElement=new Element();
const storage=new Map();let clock=Date.now(),roll=.2;
const ctx=vm.createContext({console,document:{querySelector:node,querySelectorAll:()=>[],createElement:()=>new Element(),createTextNode:s=>({textContent:s}),body:new Element()},window:{ROUTE127_QA_BUILD:true,addEventListener(){}},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},setTimeout:fn=>{queueMicrotask(fn);return 1},clearTimeout(){},setInterval:()=>1,clearInterval(){},Date:class extends Date{static now(){return clock}},Math:Object.assign(Object.create(Math),{random:()=>roll}),performance:{now:()=>clock},requestAnimationFrame:()=>1,cancelAnimationFrame(){}});
for(const file of ['app.js','casino.js','polish.js','expansion.js','crime.js','consolidation.js','factory.js','seaport.js','wanderer_fix.js','v55.js','recruitment.js','stabilization.js','final_polish.js']){let s=fs.readFileSync(path.join(dir,file),'utf8');if(file==='app.js')s=s.replace(/startRefillTimer\(\);\s*titleScreen\(\);\s*$/,'');vm.runInContext(s,ctx,{filename:file});}
const run=s=>vm.runInContext(s,ctx),text=()=>node('#screen').textContent,lines=()=>node('#screen').childNodes.map(x=>x.textContent),results=[];
async function drain(){for(let i=0;i<8;i++)await run('outputQueue')}
async function command(s){await run(`handleCommand(${JSON.stringify(s)})`);await drain()}
async function reset(){await drain();storage.clear();run(`resetPlayer();stage='mercy';mercyLocation='town';player.handle='RepairQA';player.flags.interfaceUnlocked=true;player.flags.mainSolaceQuest='complete';player.flags.mercyDiscovered=true;player.hp=player.maxHp;currentHotkeys={};numberedChoices={};busy=false;activeSaveSlot=1;`);node('#screen').innerHTML='';}
async function test(name,fn){try{await reset();await fn();await drain();results.push({name,pass:true})}catch(e){results.push({name,pass:false,error:e.stack,state:run('JSON.stringify({stage,flags:player.flags})'),tail:lines().slice(-35)});}}
async function choose(label){await drain();const map=run('numberedChoices'),key=Object.keys(map).find(k=>map[k]===label.toLowerCase());assert(key,'Missing numbered choice '+label+': '+JSON.stringify(map));await command(key);}
async function road(name='June',unlocked=true){run(`stage='wandererRoad';currentRoadWanderer=${JSON.stringify(name)};player.bolts=1000;port55State().freed=${unlocked};port55State().stage=${unlocked?"'done'":"'investigate'"};v53WandererMenu(wandererByName(currentRoadWanderer),true)`);await drain();}
async function hire(name='June'){await road(name);await choose('recruit');await choose('confirm hire');assert(run(`portIsHired(${JSON.stringify(name)})`));}
async function building(role,name){run(`stage='seaport'`);await command(role);if(name){await choose('assign staff');await choose('assign '+name);await choose('confirm assignment');}assert.equal(run('stage'),'port55Service');}
(async()=>{
await test('Recruitment, aptitudes, staffing labels and notifications stay hidden before liberation',async()=>{
 await road('June',false);assert(!Object.values(run('numberedChoices')).some(x=>x.includes('recruit')));
 await command('inspect');assert(!text().includes('APTITUDES'));assert(!run("ws('June').seaportInspected"));
 await command('recruit');assert.equal(run('stage'),'wandererRoad');assert.equal(run('player.bolts'),1000);
 run(`stage='seaport';port55Menu()`);await drain();assert(!text().includes('NEED TO HIRE'));assert(!text().includes('one-time hiring'));await command('clinic');assert.equal(run('stage'),'seaport');assert(!text().includes('RECRUIT'));
 run(`stage='seaport';port55State().stage='free';port55Menu()`);await drain();assert(!Object.values(run('numberedChoices')).some(x=>x.includes('hire')));
});
await test('Freeing residents unlocks recruitment immediately once, no chapter completion requirement',async()=>{
 run(`stage='port55Docks';port55State().stage='free';port55Free()`);await drain();assert(run('portRecruitUnlocked()'));assert(!run('player.flags.chapterOneComplete'));assert(text().includes('one-time hiring'));
 const n=lines().filter(x=>x.includes('one-time hiring')).length;run('stage="seaport";port55Menu();port55Menu()');await drain();assert.equal(lines().filter(x=>x.includes('one-time hiring')).length,n);
 await road();assert(Object.values(run('numberedChoices')).includes('recruit'));
});
await test('INSPECT reveals stable 1-5 strengths and weaknesses only after unlock',async()=>{
 await road('June');assert(!run("ws('June').seaportInspected"));await choose('inspect');assert(text().includes('APTITUDES'));assert(text().includes('Strength: medicine'));assert(text().includes('weakness: trading'));
 const a=run("JSON.stringify(portAptitudes(wandererByName('June')))");assert(Object.values(JSON.parse(a)).every(v=>v>=1&&v<=5));await command('inspect');assert.equal(run("JSON.stringify(portAptitudes(wandererByName('June')))"),a);
 run('saveGame(1);loadGame(1)');await drain();assert(run("ws('June').seaportInspected"));assert.equal(run("JSON.stringify(portAptitudes(wandererByName('June')))"),a);
});
await test('Numeric hiring confirmation charges exactly once; cancel and insufficient funds are safe',async()=>{
 await road('June');const price=run("portHireCost(wandererByName('June'))");await choose('recruit');await choose('cancel hire');assert.equal(run('player.bolts'),1000);assert(!run("portIsHired('June')"));
 await choose('recruit');run('player.bolts=1');await choose('confirm hire');assert.equal(run('player.bolts'),1);assert(!run("portIsHired('June')"));
 run('player.bolts=1000');await command('recruit');await choose('confirm hire');assert.equal(run('player.bolts'),1000-price);const paid=run('player.bolts');await command('confirm hire');assert.equal(run('player.bolts'),paid);assert.equal(run('portStaffState().hired.length'),1);
});
await test('Recruited wanderer leaves road and town pools but inventory, identity and crime state survive',async()=>{
 await road('June');run(`v52Inventory(wandererByName('June'));ws('June').profile.v52Inventory.bolts=23;ws('June').v52Suspicion=2`);const inv=run("JSON.stringify(v52Inventory(wandererByName('June')))");await choose('recruit');await choose('confirm hire');
 assert.equal(run('currentRoadWanderer'),null);assert.equal(run("wandererLocations.June"),'seaport');assert.equal(run("JSON.stringify(v52Inventory(wandererByName('June')))"),inv);assert.equal(run("ws('June').v52Suspicion"),2);assert(run("wandererAlive(wandererByName('June'))"));
 run('moveWanderers()');assert.equal(run('wandererLocations.June'),'seaport');run(`wandererLocations.June='mercy';showWanderersAt('mercy')`);assert.notEqual(run('currentTownWanderer'),'June');
 for(let i=0;i<80;i++){run(`stage='between';showRoadWanderer()`);assert.notEqual(run('currentRoadWanderer'),'June');}
});
await test('Town recruitment keeps normal interactions and requires confirmation',async()=>{
 run(`port55State().freed=true;stage='mercy';mercyLocation='town';currentTownWanderer='Patch';townWandererFocus='Patch';player.bolts=500;v53WandererMenu(wandererByName('Patch'),false)`);await drain();const opts=Object.values(run('numberedChoices'));for(const x of ['small talk patch','trade patch','steal from patch','inspect patch','fight patch','leave','recruit patch'])assert(opts.includes(x),x);
 await choose('recruit patch');await choose('confirm hire');assert(run("portIsHired('Patch')"));assert.notEqual(run('currentTownWanderer'),'Patch');assert.equal(run('stage'),'mercy');
});
await test('Assignment, replacement confirmation and one-worker-one-building guards',async()=>{
 await hire('June');await hire('Patch');await building('clinic');await choose('assign staff');await choose('assign june');assert.equal(run('portStaffState().assignments.clinic'),undefined);await choose('confirm assignment');assert.equal(run('portStaffState().assignments.clinic'),'June');
 assert(text().includes('APTITUDE UNKNOWN'));await choose('inspect staff june');assert(text().includes('MEDICINE 5/5'));
 await choose('assign staff');await choose('assign patch');await choose('cancel assignment');assert.equal(run('portStaffState().assignments.clinic'),'June');await choose('assign patch');await choose('confirm assignment');assert.equal(run('portStaffState().assignments.clinic'),'Patch');
 await choose('return to harbor');await building('workshop');await choose('assign staff');assert(!Object.values(run('numberedChoices')).includes('assign patch'));await command('assign patch');assert(!run("portStaffState().assignments.workshop"));await choose('assign june');await choose('confirm assignment');assert.equal(run('portStaffState().assignments.workshop'),'June');assert.equal(new Set(Object.values(run('portStaffState().assignments'))).size,2);
});
await test('Staffed clinic heals, charges once, clears death penalty only on full recovery; aptitude improves rate',async()=>{
 await hire('June');await building('clinic','June');run('player.hp=40;player.bolts=100;player.deathStreak=2');await choose('treat wounds');assert.equal(run('player.hp'),100);assert.equal(run('player.bolts'),90);assert.equal(run('player.deathStreak'),0);await choose('treat wounds');assert.equal(run('player.bolts'),90);
 run('player.hp=1;player.bolts=1;player.deathStreak=2');await command('treat wounds');assert.equal(run('player.hp'),7);assert.equal(run('player.deathStreak'),2);assert.equal(run('player.bolts'),0);
 run('player.bolts=50');const qty=run("findItem('Bandage')?.qty||0");await choose('buy bandage');assert.equal(run("findItem('Bandage').qty"),qty+1);assert.equal(run('player.bolts'),42);
});
await test('General store buys/sells once, protects gear/quest items, persists stock and blocks full-pack loss',async()=>{
 await hire('Vera');await building('general store','Vera');run('player.bolts=100;player.pack=[]');const buy=run("portStorePrice('Tent')");assert(buy<12);await choose('buy supplies');await choose('buy tent');assert.equal(run('player.bolts'),100-buy);assert.equal(run("findItem('Tent').qty"),1);assert.equal(run("portStoreStock().Tent"),2);
 run('saveGame(1);loadGame(1)');await drain();assert.equal(run("portStoreStock().Tent"),2);await command('back');await choose('sell items');await choose('sell tent');const before=run('player.bolts');await choose('confirm store sale');assert.equal(run('player.bolts'),before+3);await command('confirm store sale');assert.equal(run('player.bolts'),before+3);
 run(`addPack('Prepared Dynamite Charge','quest');addPack("Niko's Collar",'accessory');addPack('Rusted Pipe','weapon');player.weapon='Rusted Pipe'`);await command('sell items');const opts=Object.values(run('numberedChoices'));assert(!opts.some(x=>/charge|collar|rusted pipe/.test(x)));
 await command('back');await command('buy supplies');run('player.packMax=0');const money=run('player.bolts'),stock=run("portStoreStock().Tent");await command('buy tent');assert.equal(run('player.bolts'),money);assert.equal(run("portStoreStock().Tent"),stock);
});
await test('Trading aptitude changes equipment sale payout modestly and stock refresh uses daily clock',async()=>{
 await hire('Vera');await building('general store','Vera');run(`addPack('Tempered Steel Pipe','weapon')`);const base=run("v48SellPrice(findItem('Tempered Steel Pipe'))"),bonus=run("portStoreSellPrice(findItem('Tempered Steel Pipe'))");assert(bonus>base&&bonus<=base*1.08);
 run("portStoreStock().Tent=0;player.flags.nextRefillAt+=86400000");assert.equal(run('portStoreStock().Tent'),3);
});
await test('Workshop reuses recipes, learning/level gates, timer, material cost, and held output',async()=>{
 await hire('Patch');await building('workshop','Patch');await choose('crafting');assert(!Object.values(run('numberedChoices')).some(x=>x.startsWith('craft ')));run('player.flags.v49RecipeBandage=true;player.level=5');await command('crafting');assert(!Object.values(run('numberedChoices')).includes('craft iron reaper'));
 run("addPack('Cloth','material',2);addPack('Scrap Metal','material',1)");const before=run('player.bolts');run('portStaffRender()');await drain();await choose('craft reinforced bandage');assert(run('!!player.flags.v49MurphyJob'));assert(!run("hasItem('Cloth')"));assert.equal(run('player.bolts'),before);assert.equal(run('Math.round((player.flags.v49MurphyJob.endsAt-Date.now())/1000)'),28);
 const job=run('JSON.stringify(player.flags.v49MurphyJob)');await command('craft reinforced bandage');assert.equal(run('JSON.stringify(player.flags.v49MurphyJob)'),job);
 await choose('collect craft');assert(run('!!player.flags.v49MurphyJob'));run('player.flags.v49MurphyJob.endsAt=0;player.packMax=0');await command('collect craft');assert(run('!!player.flags.v49MurphyJob'));run('player.packMax=10');await command('collect craft');assert(!run('player.flags.v49MurphyJob'));assert.equal(run("findItem('Reinforced Bandage').qty"),1);await command('collect craft');assert.equal(run("findItem('Reinforced Bandage').qty"),1);
});
await test('Bank uses shared protected account/storage, valid amounts and aptitude fee with no duplication',async()=>{
 await hire('Tess');await building('bank','Tess');run('player.bolts=200;player.bankBolts=0');assert.equal(run('portBankFee()'),0);await choose('deposit bolts');await command('100');assert.equal(run('player.bolts'),100);assert.equal(run('player.bankBolts'),100);await command('-1');assert.equal(run('player.bankBolts'),100);
 await command('back');await choose('withdraw bolts');await command('50');assert.equal(run('player.bolts'),150);assert.equal(run('player.bankBolts'),50);await command('999');assert.equal(run('player.bolts'),150);
 await command('back');await choose('stash items');const item=run("findItem('Tent').qty");await choose('stash tent');assert(!run("hasItem('Tent')"));assert.equal(run("player.stash.find(i=>i.name==='Tent').qty"),item);await command('stash tent');assert.equal(run("player.stash.find(i=>i.name==='Tent').qty"),item);
 await command('back');await choose('retrieve items');await choose('retrieve tent');assert.equal(run("findItem('Tent').qty"),item);assert(!run("player.stash.some(i=>i.name==='Tent')"));
 run("ws('Tess').seaportAptitudes.banking=1;player.bolts=10;player.bankBolts=50");await command('back');await command('withdraw bolts');await command('10');assert.equal(run('player.bolts'),16);assert.equal(run('player.bankBolts'),40);run('loadGame(1)');await drain();assert.equal(run('player.bolts'),16);assert.equal(run('player.bankBolts'),40);
});
await test('Recruitment, assignments, active craft, account and inventory survive actual save/load independently',async()=>{
 await hire('Patch');await building('workshop','Patch');run(`player.flags.v49RecipeBandage=true;addPack('Scrap Metal','material',2);player.bolts=100;player.bankBolts=77`);await command('crafting');await command('craft rusted pipe');const snap=run('JSON.stringify({staff:portStaffState(),job:player.flags.v49MurphyJob,pack:player.pack,bolts:player.bolts,bank:player.bankBolts})');
 run('saveGame(1);player.flags.seaportStaff=null;player.flags.v49MurphyJob=null;player.bankBolts=0;loadGame(1)');await drain();assert.equal(run('JSON.stringify({staff:portStaffState(),job:player.flags.v49MurphyJob,pack:player.pack,bolts:player.bolts,bank:player.bankBolts})'),snap);assert.equal(run('stage'),'port55Service');
 run('resetPlayer()');assert(!run('portRecruitUnlocked()'));assert.equal(run('portStaffState().hired.length'),0);run('loadGame(1)');await drain();assert(run("portIsHired('Patch')"));assert.equal(run('player.bankBolts'),77);
});
await test('Legacy R3 save initializes safely with liberation as the only unlock',async()=>{
 run('delete player.flags.seaportStaff;delete player.flags.seaport55;saveGame(1);loadGame(1)');await drain();assert(!run('portRecruitUnlocked()'));assert.equal(run('portStaffState().hired.length'),0);
 run("port55State().freed=true;port55State().stage='meet';stage='seaport';port55Menu()");await drain();assert(text().includes('one-time hiring'));await command('market area');assert(Object.values(run('numberedChoices')).some(x=>x.startsWith('clinic')));await command('clinic');assert.equal(run('stage'),'port55Service');
});
await test('Confirmed unassignment enables role changes without duplicate staff or another hiring charge',async()=>{
 await hire('June');await building('clinic','June');const money=run('player.bolts');await choose('unassign staff');await choose('cancel unassignment');assert.equal(run('portStaffState().assignments.clinic'),'June');await choose('unassign staff');await choose('confirm unassignment');assert(!run('portStaffState().assignments.clinic'));await choose('return to harbor');await building('bank','June');assert.equal(run('portStaffState().assignments.bank'),'June');assert.equal(run('player.bolts'),money);assert.equal(run('portStaffState().hired.length'),1);
});
await test('Hiring offer survives save/load and interface Back; repeated confirmation cannot charge twice',async()=>{
 await road('June');await choose('recruit');await command('q');await command('b');assert.equal(run('stage'),'port55Recruit');run('saveGame(1);loadGame(1)');await drain();assert.equal(run('stage'),'port55Recruit');await choose('confirm hire');const money=run('player.bolts');await command('confirm hire');assert.equal(run('player.bolts'),money);assert.equal(run('portStaffState().hired.length'),1);
});
await test('Store exact item sale preserves similarly named reinforced medicine',async()=>{
 await hire('Vera');await building('general store','Vera');run("player.pack=[];addPack('Reinforced Bandage','consumable');addPack('Bandage','consumable')");await command('sell items');await choose('sell bandage');await choose('confirm store sale');assert.equal(run("player.pack.find(i=>i.name==='Reinforced Bandage').qty"),1);assert(!run("player.pack.some(i=>i.name==='Bandage')"));
});
await test('Workshop failed jobs, level gate, gear overlay and shared Murphy job stay safe',async()=>{
 await hire('Patch');await building('workshop','Patch');await choose('manage equipment');assert.equal(run('stage'),'inventory');await command('b');assert.equal(run('stage'),'port55Service');
 run("player.flags.v49RecipeBandage=true;player.level=5;addPack('Scrap Metal','material',20);addPack('Cloth','material',10);addPack('Wire','material',10);player.bolts=500");await command('craft iron reaper');assert(!run('player.flags.v49MurphyJob'));
 run("player.flags.v49MurphyJob={key:'pipe',endsAt:0,success:false}");await command('collect craft');assert(!run('player.flags.v49MurphyJob'));assert(!run("hasItem('Rusted Pipe')"));
 run("player.flags.v49MurphyJob={key:'pipe',endsAt:0,success:true}");await command('collect craft');assert.equal(run("findItem('Rusted Pipe').qty"),1);await command('collect craft');assert.equal(run("findItem('Rusted Pipe').qty"),1);
});
await test('Unrecruited wanderer trade, theft, fight/crime and pet flags remain functional after unlock',async()=>{
 await road('Patch');run("player.flags.equippedPet='Ferret';player.flags.ownedPets=['Ferret'];v52Inventory(wandererByName('Patch')).items=[{name:'Wire',qty:2,type:'material',price:6,trade:true}];v52Inventory(wandererByName('Patch')).bolts=100");await choose('trade');const money=run('player.bolts');await choose('buy wire');assert.equal(run('player.bolts'),money-6);assert.equal(run("v52Inventory(wandererByName('Patch')).items[0].qty"),1);await command('back');
 run("player.level=10;player.turns=50");const turns=run('player.turns');await command('steal');assert.equal(run('player.turns'),turns-1);assert.equal(run('player.flags.equippedPet'),'Ferret');assert.equal(run("player.flags.ownedPets[0]"),'Ferret');
 run("stage='mercy';mercyLocation='town';currentTownWanderer='Rook';townWandererFocus='Rook';v53WandererMenu(wandererByName('Rook'),false)");await drain();await command('fight rook');await command('confirm fight');assert.equal(run('stage'),'combat');assert(run('v52Crime().bounty')>0);assert(!run("portIsHired('Rook')"));
});
await test('All survivors recruited leaves ordinary road encounters available without duplicate wanderers',async()=>{
 run(`port55State().freed=true;portStaffState().hired=wanderers.map(w=>w.name);roadGoal='east';roadTripLength=6;rerollRoad(6);roadTurn=1;stage='between';player.turns=20;player.flags.wandererRoadCooldown=0;showEncounter()`);await drain();assert.equal(run('stage'),'encounter');assert.equal(run('currentRoadWanderer'),null);assert.equal(run('player.turns'),19);
});
console.log(JSON.stringify(results,null,2));fs.writeFileSync(path.join(__dirname,'r5-recruitment-results.json'),JSON.stringify(results,null,2));process.exitCode=results.some(x=>!x.pass)?1:0;
})();
