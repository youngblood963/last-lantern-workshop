const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const dir=process.env.ROUTE127_SOURCE||path.join(__dirname,'..','route127_r7');
class Element{
 constructor(){this.childNodes=[];this.children=this.childNodes;this.style={};this.dataset={};this.value='';this.disabled=false;this._text='';this.hidden=false;this.classList={add(){},remove(){},toggle(){},contains(){return false}};}
 appendChild(n){this.childNodes.push(n);n.parentElement=this;return n} append(n){this.appendChild(n)}
 set textContent(v){this._text=String(v);this.childNodes=[]}get textContent(){return this._text+this.childNodes.map(x=>x.textContent||'').join('')}
 set innerHTML(v){this._text='';this.childNodes=[]}get innerHTML(){return this.textContent}
 addEventListener(){} focus(){}querySelectorAll(){return []}querySelector(){return null}setAttribute(){}removeAttribute(){}insertAdjacentElement(_,n){this.appendChild(n)}getBoundingClientRect(){return {width:100,height:100}}remove(){}
}
const nodes={};const node=k=>nodes[k]||(nodes[k]=new Element());node('.utility-name').childNodes=[{nodeValue:''}];node('#side-inv').parentElement=new Element();
const storage=new Map();let clock=Date.now(),roll=.2;
const ctx=vm.createContext({console,crypto:require('crypto').webcrypto,document:{querySelector:node,querySelectorAll:()=>[],createElement:()=>new Element(),createTextNode:s=>({textContent:s}),body:new Element()},window:{ROUTE127_QA_BUILD:true,addEventListener(){}},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},setTimeout:(fn,ms)=>{if(ms<15000)queueMicrotask(fn);return 1},clearTimeout(){},setInterval:()=>1,clearInterval(){},Date:class extends Date{static now(){return clock}},Math:Object.assign(Object.create(Math),{random:()=>roll}),performance:{now:()=>clock},requestAnimationFrame:()=>1,cancelAnimationFrame(){}});
for(const file of ['app.js','casino.js','polish.js','expansion.js','crime.js','consolidation.js','factory.js','seaport.js','wanderer_fix.js','v55.js','recruitment.js','stabilization.js','final_polish.js','banking_identity.js']){let s=fs.readFileSync(path.join(dir,file),'utf8');if(file==='app.js')s=s.replace(/startRefillTimer\(\);\s*titleScreen\(\);\s*$/,'');vm.runInContext(s,ctx,{filename:file});}
const run=s=>vm.runInContext(s,ctx),text=()=>node('#screen').textContent,lines=()=>node('#screen').childNodes.map(x=>x.textContent),results=[];
async function drain(){for(let i=0;i<8;i++)await run('outputQueue')}
async function command(s){await run(`handleCommand(${JSON.stringify(s)})`);await drain()}
async function reset(){await drain();storage.clear();run(`resetPlayer();stage='mercy';mercyLocation='town';player.handle='RepairQA';player.flags.interfaceUnlocked=true;player.flags.mainSolaceQuest='complete';player.flags.mercyDiscovered=true;player.hp=player.maxHp;currentHotkeys={};numberedChoices={};busy=false;activeSaveSlot=1;`);node('#screen').innerHTML='';}
async function test(name,fn){try{await reset();await fn();await drain();results.push({name,pass:true})}catch(e){results.push({name,pass:false,error:e.stack,state:run('JSON.stringify({stage,flags:player.flags})'),tail:lines().slice(-35)});}}
async function choose(label){await drain();const map=run('numberedChoices'),key=Object.keys(map).find(k=>map[k]===label.toLowerCase());assert(key,'Missing numbered choice '+label+': '+JSON.stringify(map));await command(key);}
async function road(name='June',unlocked=true){run(`stage='wandererRoad';currentRoadWanderer=${JSON.stringify(name)};player.bolts=1000;port55State().freed=${unlocked};port55State().stage=${unlocked?"'done'":"'investigate'"};v53WandererMenu(wandererByName(currentRoadWanderer),true)`);await drain();}
async function hire(name='June'){await road(name);await choose('recruit');await choose('confirm hire');assert(run(`portIsHired(${JSON.stringify(name)})`));}
async function building(role,name){run(`stage='seaport'`);await command(role);if(name){await choose('assign staff');await choose('assign '+name);await choose('confirm assignment');}assert.equal(run('stage'),'port55Service');}
(async()=>{
await test('Legacy tutorial completion migrates to recipe; carried scrap counts and missing Cloth is honest',async()=>{
 run("player.flags.v49CraftCompleted=true;player.flags.v49RecipeBandage=false;player.pack=[{name:'scrap metal',type:'material',qty:3}];v49Workbench()");await drain();assert(run('player.flags.v49RecipeBandage'));await command('craft reinforced bandage');assert(!run('player.flags.v49MurphyJob'));assert(text().includes('Cloth 0/2'));assert.equal(run("findItem('Scrap Metal').qty"),3);
 run("addPack('Cloth','material',2)");await command('craft reinforced bandage');assert(run('!!player.flags.v49MurphyJob'));assert.equal(run("findItem('Scrap Metal').qty"),2);assert(!run("findItem('Cloth')"));await command('collect craft');assert(run('!!player.flags.v49MurphyJob'));run('saveGame(1);loadGame(1)');await drain();assert(run('!!player.flags.v49MurphyJob'));clock+=31000;await command('collect craft');assert(!run('player.flags.v49MurphyJob'));assert.equal(run("findItem('Reinforced Bandage').qty"),1);await command('collect craft');assert.equal(run("findItem('Reinforced Bandage').qty"),1);
});
await test('Relay legacy items move to durable flags; installed parts hidden; unfinished progress survives',async()=>{
 run("player.flags.relayQuest='stabilize';player.pack=[{name:'Power Regulator',type:'quest',qty:1}];r5Migrate()");assert(run('ensureRelayParts().johnny'));assert(!run("hasItem('Power Regulator')"));run("player.flags.relayQuest='complete';showInventory();saveGame(1);loadGame(1)");await drain();assert.equal(run('player.flags.relayQuest'),'complete');assert(run('ensureRelayParts().johnny'));assert(!text().includes('RELAY COMPONENTS — QUEST STORAGE'));assert(!text().includes('INSTALLED'));
});
await test('Full-pack replacement protects quest/equipped gear, confirms Rare sacrifice and survives reload',async()=>{
 run("player.packMax=2;player.pack=[{name:'Cloth',type:'material',qty:2},{name:'Tempered Steel Pipe',type:'weapon',qty:1},{name:'Prepared Dynamite Charge',type:'quest',qty:1}];stage='turnComplete';addPack('Wire','material');r5LootMenu()");await drain();assert.deepEqual(Object.values(run('numberedChoices')),['leave behind','replace an item']);run('saveGame(1);loadGame(1)');await drain();await command('inventory');assert.equal(run('stage'),'r5Loot');await choose('replace an item');assert(!Object.values(run('numberedChoices')).some(x=>x.includes('charge')));await choose('replace tempered steel pipe');assert(text().includes('WARNING'));const slots=run('packSlotsUsed()');await choose('confirm replacement');assert.equal(run('packSlotsUsed()'),slots);assert(run("hasItem('Wire')"));assert(!run("hasItem('Tempered Steel Pipe')"));await command('confirm replacement');assert.equal(run("findItem('Wire').qty"),1);
});
await test('Leave Behind resolves once without granting item; capacity cannot be bypassed',async()=>{
 run("player.packMax=1;player.pack=[{name:'Cloth',type:'material',qty:1}];stage='turnComplete';addPack('Wire','material');r5LootMenu()");await drain();await choose('leave behind');assert(!run("hasItem('Wire')"));assert.equal(run('player.flags.r5LootQueue.length'),0);await command('leave behind');assert(!run("hasItem('Wire')"));
});
await test('Funded and low-cash wanderer sales report exact funds, preserve item or pay once',async()=>{
 await road('Hollis');run("player.pack=[{name:\"Yardman's Wrench\",type:'weapon',qty:1}];player.weapon='Rusted Pipe';v52Inventory(wandererByName('Hollis')).bolts=0");await command('browse wares');await command("sell yardman's wrench");await command('sell 1');await command('confirm sale');assert(text().includes('has 0 Bolts available'));assert(run("hasItem(\"Yardman's Wrench\")"));run("v52Inventory(wandererByName('Hollis')).bolts=100");const before=run('player.bolts');await command("sell yardman's wrench");await command('sell 1');await command('confirm sale');assert(run('player.bolts')>before);assert(!run("hasItem(\"Yardman's Wrench\")"));
});
await test('Journal has separate active/completed views and hides undiscovered side quests',async()=>{
 await command('q');await choose('active quests');assert(!text().includes('The Old Badge'));run("player.flags.timQuest='active'");await command('active quests');assert(text().includes('The Old Badge — ACTIVE'));run("player.flags.timQuest='done'");await choose('completed quests');assert(text().includes('The Old Badge — DONE'));const turns=run('player.turns');await command('back');assert.equal(run('player.turns'),turns);assert.equal(run('stage'),'mercy');
});
await test('Rusty reachable both before/after bosses; priced trades have stock/funding/capacity guards',async()=>{
 run('v49FactoryRoom();player.bolts=500;player.pack=[]');await drain();await choose('rusty');assert.equal(run('stage'),'factoryRusty');const turns=run('player.turns');await choose('buy supplies');await choose('buy bandage');assert.equal(run('player.bolts'),485);assert.equal(run("findItem('Bandage').qty"),1);assert.equal(run('player.turns'),turns);await command('back');await choose('sell items');await choose('sell bandage');await choose('confirm rusty sale');assert.equal(run('player.bolts'),488);assert(!run("hasItem('Bandage')"));run('saveGame(1);loadGame(1)');await drain();assert.equal(run('r5RustyStock().bolts'),512);await command('return to forge');run('factoryState().done=[0,1,2,3]');await choose('rusty');assert.equal(run('stage'),'factoryRusty');
});
await test('Basement still requires all three minibosses; direct boss-room access needs no room clears',async()=>{
 run("stage='factoryDungeonHub';factoryCommand('4')");assert.equal(run('stage'),'factoryDungeonHub');run("factoryState().done=[0,1,2];factoryCommand('4')");assert.equal(run('stage'),'factoryDungeonFloor');assert.equal(run('factoryState().floor'),3);run("factoryState().floor=0;stage='factoryDungeonFloor';factoryCommand('6')");assert.equal(run('factoryState().room'),5);assert.equal(run('stage'),'factoryDungeonRoom');
});
await test('Charge components are deterministic searches not boss drops; once-only real timer persists',async()=>{
 run("player.flags.v49TerminalRead=true;r5Story()");for(const key of Object.keys(run('R5_CHARGE_SITES'))){const [floor,room]=key.split(':');run(`factoryState().floor=${floor};factoryState().room=${room};stage='factoryDungeonRoom'`);await command('search');}assert.equal(run('r5ChargeCount()'),4);assert(run('player.flags.factoryFinalComponent'));run('factoryState().done=[0,1,2]');await command('talk to forge');run('v49Forge()');assert(!run('player.flags.r5ChargeJob'));run('factoryState().done=[0,1,2,3];v49Forge()');await drain();assert(run('!!player.flags.r5ChargeJob'));assert(!run('player.flags.portChargePrepared'));run('saveGame(1);loadGame(1)');clock+=31000;run('v49Forge()');await drain();assert(run('player.flags.portChargePrepared'));assert.equal(run("findItem('Prepared Dynamite Charge').qty"),1);run('v49Forge()');assert.equal(run("findItem('Prepared Dynamite Charge').qty"),1);
});
await test('Legacy completed and partial progression migrate without reset or duplicated charge',async()=>{
 run("player.flags.factoryFinalComponent=true;player.flags.r5StoryVersion=undefined;factoryState().done=[0,1,2,3];r5Story()");assert.equal(run('r5ChargeCount()'),4);run("player.flags.chapterOneComplete=true;player.flags.r5StoryVersion=undefined;r5Story()");assert(run('player.flags.r5TerminalDone'));assert(run('player.flags.chapterOneComplete'));
});
await test('Occupied town is exactly two options and protected typed vendors cannot bypass',async()=>{
 run("stage='seaport';port55Menu()");await drain();assert.deepEqual(Object.values(run('numberedChoices')),['harbor docks','return west']);for(const c of ['pet vendor','market area','town streets','rusty anchor','clinic','workshop','demo status']){await command(c);assert.equal(run('stage'),'seaport',c);assert(!run('portRecruitUnlocked()'));}await choose('harbor docks');await choose('inspect fishermen');assert.equal(run('port55State().stage'),'confront');await choose('confront fishermen');assert.equal(run('stage'),'combat');
});
await test('Victory prompts Free/Back Away; liberation persists, reward once, no early story completion',async()=>{
 run("stage='combat';portLiberationVictory()");await drain();assert.deepEqual(Object.values(run('numberedChoices')),['free the survivors','back away']);await choose('back away');assert(!run('portRecruitUnlocked()'));await choose('harbor docks');await choose('free the survivors');assert(run('portRecruitUnlocked()'));assert(!run('player.flags.chapterOneComplete'));assert.equal(run("findItem('Harbor Guard Cutlass').qty"),1);run('saveGame(1);loadGame(1)');await drain();assert(run('portRecruitUnlocked()'));await command('free the survivors');assert.equal(run("findItem('Harbor Guard Cutlass').qty"),1);
});
await test('Liberated top menu exactly five; market exactly six, vacant services closed, Pet Store opens',async()=>{
 run("port55State().freed=true;stage='seaport';port55Menu()");await drain();assert.deepEqual(Object.values(run('numberedChoices')),['town streets','harbor docks','market area','rusty anchor','return west']);await choose('market area');assert.equal(Object.values(run('numberedChoices')).length,6);await choose('clinic [vacant]');assert.equal(run('stage'),'port55Service');assert(!Object.values(run('numberedChoices')).includes('treat wounds'));await command('return to harbor');await choose('market area');await choose('pet store');assert.equal(run('stage'),'port55Vendor');await choose('return to market');assert.equal(run('stage'),'port55Market');
});
await test('Pack Mule costs 350, grants only active +2, over-capacity switches keep every item and block intake',async()=>{
 run("port55State().freed=true;stage='port55Vendor';player.bolts=500;player.packMax=10;port55Vendor()");await drain();assert(text().includes('10% chance to find 2–5 Bolts'));await choose('pack mule — 350 bolts');assert.equal(run('player.bolts'),150);run("stage='port55Pets';port55Pets()");await drain();await choose('pack mule');assert.equal(run('player.packMax'),12);run("player.pack=Array.from({length:12},(_,i)=>({name:'Material '+i,type:'material',qty:1}))");await command('unequip pet');assert.equal(run('player.packMax'),10);assert.equal(run('player.pack.length'),12);assert(!run("addPack('Wire','material',1,true)"));run('saveGame(1);loadGame(1)');await drain();assert.equal(run('player.pack.length'),12);assert.equal(run('player.packMax'),10);
});
await test('Unstaffed Workshop terminal completes once, saves before credits; replay leaves flags and economy alone',async()=>{
 run("port55State().freed=true;stage='seaport'");await command('workshop');await choose('tomorrow project terminal');assert(run('player.flags.chapterOneComplete'));assert(run('player.flags.r5TerminalDone'));assert(run('getSaveData("auto").player.flags.chapterOneComplete'));assert(run('!!r5Credits'));await command('skip');assert(run('r5Credits.final'));await command('continue');assert(!run('r5Credits'));const state=run('JSON.stringify(player)');await command('credits');assert(run('!!r5Credits'));await command('skip');await command('continue');assert.equal(run('JSON.stringify(player)'),state);await command('inventory');assert.equal(run('stage'),'inventory');
});
await test('All reworked road choices are meaningful and resolve once; safe retreats grant zero rewards',async()=>{
 for(const e of run('[...encounters,...eastEncounters].filter(e=>R5_ROAD_REWORK[e.title]).map(e=>({title:e.title,choices:e.choices}))')){
  for(const choice of e.choices.split(/\s{2,}/)){
   run(`resetPlayer();player.flags.interfaceUnlocked=true;player.packMax=10;player.turns=100;player.hp=100;player.pack=[{name:'Cloth',type:'material',qty:5},{name:'Wire',type:'material',qty:5},{name:'Battered Flashlight',type:'tool',qty:1}];stage='encounter';currentEncounter=()=>[...encounters,...eastEncounters].find(e=>e.title===${JSON.stringify(e.title)})`);
   const before=run('JSON.stringify({xp:player.xp,bolts:player.bolts,pack:player.pack})');run(`resolveEncounter(${JSON.stringify(choice.toLowerCase())})`);await drain();if(choice==='BACK AWAY')assert.equal(run('JSON.stringify({xp:player.xp,bolts:player.bolts,pack:player.pack})'),before);assert(['combat','turnComplete','zeroTurns'].includes(run('stage')),e.title+' '+choice+' '+run('stage'));
  }
 }
});

await test('Existing combat, combat items, Murphy and save menus remain single and numbered',async()=>{
 await command('murphy');assert.equal(lines().filter(x=>x==="MURPHY'S WORKSHOP").length,1);await command('3');assert.equal(lines().filter(x=>x==='MURPHY — TALK').length,1);await command('town');await command('save');assert.equal(lines().filter(x=>x==='SAVE / LOAD').length,1);
 run("stage='mercy';startCombat({name:'QA ENEMY',level:1,hp:50,min:1,max:1,xp:0,bolts:0},'encounter')");await drain();assert.equal(lines().filter(x=>x.includes('[1] ATTACK')).length,1);await command('1');assert(run('combatState.hp')<50);await command('2');assert.equal(run('stage'),'combatItems');await command('back');assert.equal(run('stage'),'combat');
});
await test('Zero-turn authorized QA access remains available; exit restores normal mode',async()=>{
 run("player.turns=0;stage='factoryWorkshop'");await command('testing');assert.equal(run('stage'),'testingCode');await command('lantern127');assert(run('testMode'));await command('test off');assert(!run('testMode'));
});
await test('Backpack purchase upgrades base 8 to 10 while Mule stays active at +2',async()=>{
 run("player.flags.equippedPet='Pack Mule';player.packMax=8;r5Capacity();player.bolts=100;v48BuyBackpack()");assert.equal(run('player.packMax'),12);assert.equal(run('player.bolts'),25);run("player.flags.equippedPet=null;r5Capacity()");assert.equal(run('player.packMax'),10);
});
await test('New reward drop offers replacement; legacy pending drop can be claimed only once',async()=>{
 run("player.packMax=1;player.pack=[{name:'Cloth',type:'material',qty:1}];stage='turnComplete';v555AwardEquipmentDrop();r5LootMenu()");await drain();assert.equal(run('player.flags.r5LootQueue.length'),1);await choose('leave behind');assert.equal(run('player.pack.length'),1);
 run("player.flags.pendingEquipmentDrops=['Tempered Steel Pipe'];v555ClaimEquipmentDrop();r5LootMenu()");await drain();assert.equal(run('player.flags.pendingEquipmentDrops'),undefined);await choose('replace an item');await choose('replace cloth');await choose('confirm replacement');assert(run("hasItem('Tempered Steel Pipe')"));assert(!run('v555ClaimEquipmentDrop()'));
});
await test('Level-five art threshold and compact scene widths preserve early text',async()=>{
 run("player.level=4;r5LastScene='';r5Scene('factory')");await drain();assert(!text().includes('FACTORY []'));run("player.level=5;r5Scene('factory')");await drain();assert(text().includes('FACTORY []'));assert(run('Object.values(R5_ART).every(rows=>rows.every(line=>line.length<=31))'));
});
await test('All East discoveries and original route choices accept advertised paths; failure/retreat accounting',async()=>{
 const entries=run("eastEncounters.filter(e=>R5_DISCOVERIES[e.title]||R5_ROAD_REWORK[e.title]).map(e=>({title:e.title,choices:e.choices}))");assert.equal(entries.length,44);
 for(const e of entries)for(const random of [.1,.9])for(const choice of e.choices.split(/\s{2,}/)){
  roll=random;run(`resetPlayer();player.flags.interfaceUnlocked=true;player.packMax=20;player.turns=100;player.hp=100;player.pack=[{name:'Cloth',type:'material',qty:5},{name:'Wire',type:'material',qty:5},{name:'Battered Flashlight',type:'tool',qty:1}];player.flags.r5LootQueue=[];stage='encounter';currentEncounter=()=>eastEncounters.find(e=>e.title===${JSON.stringify(e.title)})`);
  const before=run('JSON.stringify({xp:player.xp,bolts:player.bolts,pack:player.pack})');run(`resolveEncounter(${JSON.stringify(choice.toLowerCase())})`);await drain();if(choice==='BACK AWAY')assert.equal(run('JSON.stringify({xp:player.xp,bolts:player.bolts,pack:player.pack})'),before);assert(['combat','turnComplete','zeroTurns'].includes(run('stage')),e.title+' '+choice);assert(run('player.hp>=0&&player.bolts>=0'));const after=run('JSON.stringify(player)');run(`resolveEncounter(${JSON.stringify(choice.toLowerCase())})`);assert.equal(run('JSON.stringify(player)'),after,'repeat '+e.title);
 }
 roll=.2;
});
await test('East combat/discovery pool and existing repetition/cooldown constraints are preserved',async()=>{
 assert.equal(run('eastEncounters.length'),57);assert.equal(run('eastEncounters.filter(e=>e.combat).length'),8);run("roadGoal='east';player.level=7;rerollRoad(6)");const a=run('Array.from(roadEncounterOrder)');assert.equal(new Set(a).size,a.length);run('rememberEncounter(roadEncounterOrder[0]);rerollRoad(6)');assert(!run('roadEncounterOrder.some(i=>player.recentEncounters.includes(encounterHistoryKey(i)))'));
});


await test('Rusty sells the selected exact Bandage rather than a similarly named item',async()=>{
 run("player.pack=[{name:'Reinforced Bandage',type:'consumable',qty:1},{name:'Bandage',type:'consumable',qty:1}];r5RustyMenu()");await drain();await command('sell items');await choose('sell bandage');await choose('confirm rusty sale');assert(run("player.pack.some(i=>i.name==='Reinforced Bandage')"));assert(!run("player.pack.some(i=>i.name==='Bandage')"));
});
await test('Old occupied casino saves return to occupied Seaport and cannot trade',async()=>{
 run("player.flags.port55Casino=true;stage='mercy';mercyLocation='casino';port55State().freed=false;r5Migrate()");assert.equal(run('stage'),'seaport');assert(!run('player.flags.port55Casino'));
});
await test('Kaiden remains reachable from Town Streets at every patrol stop',async()=>{
 run("port55State().freed=true;stage='seaport';port55Menu()");await drain();await choose('town streets');await choose('find kaiden');assert.equal(run('stage'),'port55Kaiden');await command('small talk');assert(run('port55State().metKaiden'));assert(!run('player.flags.chapterOneComplete'));
});


await test('Over-capacity bank and house retrieval cannot bypass intake protection by stacking',async()=>{
 run("player.packMax=1;player.pack=[{name:'Cloth',type:'material',qty:1},{name:'Wire',type:'material',qty:1}];player.stash=[{name:'Cloth',type:'material',qty:2}];player.houseStorage=[{name:'Wire',type:'material',qty:2}];player.flags.houseOwned=true;stage='houseWithdraw'");assert(!run("v48Retrieve('Cloth')"));assert(!run("transferHouseItem('Wire',false)"));assert.equal(run("findItem('Cloth').qty"),1);assert.equal(run("findItem('Wire').qty"),1);assert.equal(run('player.stash.length'),1);assert.equal(run('player.houseStorage.length'),1);
});

console.log(JSON.stringify(results,null,2));fs.writeFileSync(path.join(dir,'QA_EVIDENCE/r5-results.json'),JSON.stringify(results,null,2));process.exit(results.some(r=>!r.pass)?1:0);
})();
