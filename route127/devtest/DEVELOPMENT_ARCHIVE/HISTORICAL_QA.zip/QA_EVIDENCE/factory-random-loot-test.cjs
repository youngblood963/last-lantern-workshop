const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync(__dirname+'/../factory.js','utf8');
const app=fs.readFileSync(__dirname+'/../app.js','utf8');
const stats=app.match(/const FACTORY_WEAPON_STATS=([\s\S]*?);\nconst GEAR=/)[1];
const gear=vm.runInNewContext('('+stats+')');
const ctx={Math,GEAR:gear,player:{flags:{factoryDungeon:{floor:0,room:5,done:[],weaponAwards:{}}},weapon:'Rusted Pipe',pack:[],stash:[]},stage:'factoryDungeonRoom',add:()=>{},addPack:(name,type)=>{ctx.player.pack.push({name,type,qty:1});return true},gearLabel:n=>n,updateHud:()=>{},factoryRender:()=>{},day:1};
vm.createContext(ctx);vm.runInContext(src,ctx);
const pools=vm.runInContext('FACTORY_BOSS_LOOT',ctx);
assert.equal(pools.length,4);
for(let i=0;i<4;i++){
 assert.equal(pools[i].reduce((s,x)=>s+x.weight,0),100);
 assert.equal(pools[i].length,3);
 const seen=new Set();for(let n=0;n<2000;n++)seen.add(vm.runInContext(`factoryRollBossWeapon(${i})`,ctx));
 assert.equal(seen.size,3);
 for(const w of pools[i])assert.equal(gear[w.name].type,'weapon');
 ctx.player.flags.factoryDungeon.weaponAwards={};ctx.player.flags.factoryDungeon.floor=i;
 vm.runInContext(`factoryAwardBossWeapon(${i})`,ctx);
 const chosen=ctx.player.flags.factoryDungeon.weaponAwards[i];assert(pools[i].some(x=>x.name===chosen));
 const before=JSON.stringify(ctx.player);
 vm.runInContext(`factoryAwardBossWeapon(${i})`,ctx);
 assert.equal(JSON.stringify(ctx.player),before);
 // Roundtrip serialization retains award state.
 assert.equal(JSON.parse(JSON.stringify(ctx.player)).flags.factoryDungeon.weaponAwards[i],chosen);
}
ctx.player.flags.factoryDungeon.weaponAwards={0:true};const before=JSON.stringify(ctx.player);vm.runInContext('factoryAwardBossWeapon(0)',ctx);assert.equal(JSON.stringify(ctx.player),before);
console.log('PASS: 4 tables, 12 valid weapons, weighted diversity, one-time awards, JSON persistence, legacy award flags');
