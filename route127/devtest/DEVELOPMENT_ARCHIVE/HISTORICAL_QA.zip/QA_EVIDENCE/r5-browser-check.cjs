const path=require('path');const ROOT=path.resolve(__dirname,'..');
const {chromium}=require('playwright'),assert=require('assert'),fs=require('fs');
(async()=>{
const browser=await chromium.launch({executablePath:process.env.R127_CHROMIUM_PATH||chromium.executablePath(),headless:true});
const results=[];const errors=[];
for(const width of [1366,390]){
 const context=await browser.newContext({viewport:{width,height:900},reducedMotion:width===390?'reduce':'no-preference'});const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));
 await page.goto(require('url').pathToFileURL(path.join(ROOT,'QA_MODE.html')).href);
 await page.evaluate(()=>{const nativeTimeout=window.setTimeout;window.setTimeout=(fn,ms,...args)=>ms<15000?(queueMicrotask(()=>fn(...args)),0):nativeTimeout(fn,ms,...args);typeLine=async function(text,cls=''){const div=document.createElement('div');div.className='line '+cls;div.textContent=text;screen.appendChild(div);applyLevelEvolution(div,text,cls);followOutput();};});await page.evaluate(()=>outputQueue);
 async function send(cmd){console.log(width,cmd);await page.locator('#command').fill(cmd);await page.locator('#command').press('Enter');await page.evaluate(async()=>{await handleCommandPending();function handleCommandPending(){return outputQueue;}});await page.waitForFunction(()=>!busy&&!commandProcessing);await page.evaluate(async()=>{for(let i=0;i<8;i++)await outputQueue;});}
 // A real fresh opening through visible command input, not injected completion flags.
 for(const c of ['new game','yes','stand up','BrowserQA','yes','check cabinet','inspect computer','hello','listen','log coordinates'])await send(c);
 assert.equal(await page.evaluate(()=>player.level),1);assert.equal(await page.evaluate(()=>player.flags.interfaceUnlocked),true);await send('testing');await send('lantern127');assert(await page.evaluate(()=>testMode));await send('test off');
 results.push({name:'Fresh opening, interface and QA toggle '+width,pass:true});
 // Representative existing-save context for scoped endgame UI, not natural progression.
 await page.evaluate(()=>{player.level=7;player.flags.seaport55={stage:'investigate',freed:false};player.flags.seaportRoute={position:5,cleared:{},seen:{},arrived:true};stage='seaport';port55Menu();updateHud();});await page.evaluate(()=>outputQueue);
 assert.deepEqual(await page.evaluate(()=>Object.values(numberedChoices)),['harbor docks','return west']);await send('1');await send('1');assert.equal(await page.evaluate(()=>port55State().stage),'confront');
 // Combat victory is covered with actual handlers in VM; seed the post-battle prompt here.
 await page.evaluate(()=>{portLiberationVictory();});await page.evaluate(()=>outputQueue);await send('2');assert(!await page.evaluate(()=>portRecruitUnlocked()));await send('1');await send('1');assert(await page.evaluate(()=>portRecruitUnlocked()));assert(!await page.evaluate(()=>player.flags.chapterOneComplete));
 await page.screenshot({path:path.join(ROOT,'QA_EVIDENCE/seaport-')+width+'.png',fullPage:false});
 await send('3');assert.equal(await page.evaluate(()=>stage),'port55Market');await send('5');assert.equal(await page.evaluate(()=>stage),'port55Vendor');await send('7');assert.equal(await page.evaluate(()=>stage),'port55Market');await send('3');assert.equal(await page.evaluate(()=>stage),'port55Service');
 assert(await page.evaluate(()=>Object.values(numberedChoices).includes('tomorrow project terminal')));await send('1');assert(await page.evaluate(()=>player.flags.chapterOneComplete));await page.locator('.r5-credits').waitFor();
 assert(await page.locator('.r5-skip').isVisible());assert.equal(await page.locator('.r5-burger').count(),2);if(width===1366){assert.deepEqual(await page.locator('.r5-burger').evaluateAll(es=>es.map(e=>getComputedStyle(e).animationName)),['r5-run-right','r5-run-left']);}const bounds=await page.locator('.r5-credits').boundingBox();assert(bounds.width<=width);await page.screenshot({path:path.join(ROOT,'QA_EVIDENCE/credits-')+width+'.png'});
 if(width===1366){await page.waitForTimeout(20500);assert(await page.locator('.r5-thanks').isVisible());results.push({name:'Actual 20-second credits timeout',pass:true});}else{assert.equal(await page.locator('.r5-credit-roll').evaluate(e=>getComputedStyle(e).animationName),'none');await page.locator('.r5-skip').click();assert(await page.locator('.r5-thanks').isVisible());results.push({name:'Reduced-motion credits, phone skip',pass:true});}
 await page.getByRole('button',{name:'CONTINUE EXPLORING'}).click();await page.evaluate(()=>outputQueue);assert.equal(await page.locator('.r5-credits').count(),0);await page.locator('button[data-command="credits"]').click();await page.locator('.r5-credits').waitFor();await page.keyboard.press('Escape');assert(await page.locator('.r5-thanks').isVisible());await page.keyboard.press('Enter');assert.equal(await page.locator('.r5-credits').count(),0);
 await page.locator('button[data-command="inventory"]').click();await page.evaluate(()=>outputQueue);assert.equal(await page.evaluate(()=>stage),'inventory');await send('back');
 // Reload after completion: persistent flags, no automatic replay/lock.
 await send('save current');await page.reload();await page.evaluate(()=>{const nativeTimeout=window.setTimeout;window.setTimeout=(fn,ms,...args)=>ms<15000?(queueMicrotask(()=>fn(...args)),0):nativeTimeout(fn,ms,...args);typeLine=async function(text,cls=''){const div=document.createElement('div');div.className='line '+cls;div.textContent=text;screen.appendChild(div);applyLevelEvolution(div,text,cls);followOutput();};});await page.evaluate(()=>outputQueue);await send('load autosave');assert(await page.evaluate(()=>player.flags.chapterOneComplete));assert.equal(await page.locator('.r5-credits').count(),0);await send('q');assert.equal(await page.evaluate(()=>stage),'quests');
 const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth);assert(!overflow,'Page width overflow at '+width);
 results.push({name:'Occupied/liberated menus, market/vendor escape, vacant terminal, credits replay and restored controls '+width,pass:true});await context.close();
}
assert.deepEqual(errors,[]);results.push({name:'Browser console uncaught errors',pass:true});fs.writeFileSync(path.join(ROOT,'QA_EVIDENCE/r5-browser-results.json'),JSON.stringify(results,null,2));console.log(JSON.stringify(results));await browser.close();
})().catch(e=>{console.error(e.stack);process.exit(1)});
