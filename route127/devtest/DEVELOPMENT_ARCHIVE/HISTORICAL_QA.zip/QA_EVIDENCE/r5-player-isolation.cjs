const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const dir=path.join(__dirname,'..');
class Element{
 constructor(){this.childNodes=[];this.children=this.childNodes;this.style={};this.dataset={};this.value='';this.disabled=false;this._text='';this.hidden=false;this.classList={add(){},remove(){},toggle(){},contains(){return false}};}
 appendChild(n){this.childNodes.push(n);n.parentElement=this;return n} append(n){this.appendChild(n)}
 set textContent(v){this._text=String(v);this.childNodes=[]}get textContent(){return this._text+this.childNodes.map(x=>x.textContent||'').join('')}
 set innerHTML(v){this._text='';this.childNodes=[]}get innerHTML(){return this.textContent}
 addEventListener(){} focus(){}querySelectorAll(){return []}querySelector(){return null}setAttribute(){}removeAttribute(){}insertAdjacentElement(_,n){this.appendChild(n)}getBoundingClientRect(){return {width:100,height:100}}remove(){}
}
const nodes={};const node=k=>nodes[k]||(nodes[k]=new Element());node('.utility-name').childNodes=[{nodeValue:''}];node('#side-inv').parentElement=new Element();
const storage=new Map();let clock=Date.now(),roll=.2;
const ctx=vm.createContext({console,document:{querySelector:node,querySelectorAll:()=>[],createElement:()=>new Element(),createTextNode:s=>({textContent:s}),body:new Element()},window:{ROUTE127_QA_BUILD:false,addEventListener(){}},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},setTimeout:(fn,ms)=>{if(ms<15000)queueMicrotask(fn);return 1},clearTimeout(){},setInterval:()=>1,clearInterval(){},Date:class extends Date{static now(){return clock}},Math:Object.assign(Object.create(Math),{random:()=>roll}),requestAnimationFrame:fn=>fn()});
for(const file of ['app.js','casino.js','polish.js','expansion.js','crime.js','consolidation.js','factory.js','seaport.js','wanderer_fix.js','v55.js','recruitment.js','stabilization.js']){let s=fs.readFileSync(path.join(dir,file),'utf8');if(file==='app.js')s=s.replace(/startRefillTimer\(\);\s*titleScreen\(\);\s*$/,'');vm.runInContext(s,ctx,{filename:file});}
const run=s=>vm.runInContext(s,ctx),text=()=>node('#screen').textContent,lines=()=>node('#screen').childNodes.map(x=>x.textContent),results=[];
async function drain(){for(let i=0;i<8;i++)await run('outputQueue')}
async function command(s){await run(`handleCommand(${JSON.stringify(s)})`);await drain()}
async function reset(){await drain();storage.clear();run(`resetPlayer();stage='mercy';mercyLocation='town';player.handle='RepairQA';player.flags.interfaceUnlocked=true;player.flags.mainSolaceQuest='complete';player.flags.mercyDiscovered=true;player.hp=player.maxHp;currentHotkeys={};numberedChoices={};busy=false;activeSaveSlot=1;`);node('#screen').innerHTML='';}
async function test(name,fn){try{await reset();await fn();await drain();results.push({name,pass:true})}catch(e){results.push({name,pass:false,error:e.stack,state:run('JSON.stringify({stage,flags:player.flags})'),tail:lines().slice(-35)});}}
async function choose(label){await drain();const map=run('numberedChoices'),key=Object.keys(map).find(k=>map[k]===label.toLowerCase());assert(key,'Missing numbered choice '+label+': '+JSON.stringify(map));await command(key);}
async function road(name='June',unlocked=true){run(`stage='wandererRoad';currentRoadWanderer=${JSON.stringify(name)};player.bolts=1000;port55State().freed=${unlocked};port55State().stage=${unlocked?"'done'":"'investigate'"};v53WandererMenu(wandererByName(currentRoadWanderer),true)`);await drain();}
async function hire(name='June'){await road(name);await choose('recruit');await choose('confirm hire');assert(run(`portIsHired(${JSON.stringify(name)})`));}
async function building(role,name){run(`stage='seaport'`);await command(role);if(name){await choose('assign staff');await choose('assign '+name);await choose('confirm assignment');}assert.equal(run('stage'),'port55Service');}
(async()=>{
await test('Production rejects QA commands and code at zero turns',async()=>{run("player.turns=0;stage='factoryWorkshop'");await command('testing');assert(!run('testMode'));assert.notEqual(run('stage'),'testingCode');await command('lantern127');assert(!run('testMode'));assert.equal(run('player.turns'),0);});
await test('Production cannot bypass Seaport occupation or staffing',async()=>{run("stage='seaport';port55Menu()");await drain();for(const c of ['clinic','workshop','pet vendor','rusty anchor','recruit','confirm hire']){await command(c);assert(!run('portRecruitUnlocked()'));assert.equal(run('stage'),'seaport');}assert(!run('player.flags.chapterOneComplete'));});
fs.writeFileSync(path.join(dir,'QA_EVIDENCE/r5-player-results.json'),JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2));process.exit(results.some(x=>!x.pass)?1:0);})();