const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const dir=path.join(__dirname,'..');
class Element{
 constructor(){this.childNodes=[];this.children=this.childNodes;this.style={};this.dataset={};this.value='';this.disabled=false;this._text='';this.hidden=false;this.classList={add(){},remove(){},toggle(){},contains(){return false}};}
 appendChild(n){this.childNodes.push(n);n.parentElement=this;return n} append(n){this.appendChild(n)}
 set textContent(v){this._text=String(v);this.childNodes=[]}get textContent(){return this._text+this.childNodes.map(x=>x.textContent||'').join('')}
 set innerHTML(v){this._text='';this.childNodes=[]}get innerHTML(){return this.textContent}
 addEventListener(){} focus(){}querySelectorAll(){return []}querySelector(){return null}setAttribute(){}removeAttribute(){}insertAdjacentElement(_,n){this.appendChild(n)}getBoundingClientRect(){return {width:100,height:100}}remove(){}
}
const nodes={};const node=k=>nodes[k]||(nodes[k]=new Element());node('.utility-name').childNodes=[{nodeValue:''}];node('#side-inv').parentElement=new Element();
const storage=new Map();let clock=Date.now(),roll=.2;
const ctx=vm.createContext({console,document:{querySelector:node,querySelectorAll:()=>[],createElement:()=>new Element(),createTextNode:s=>({textContent:s}),body:new Element()},window:{ROUTE127_QA_BUILD:true,addEventListener(){}},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},setTimeout:(fn,ms)=>{if(ms<15000)queueMicrotask(fn);return 1},clearTimeout(){},setInterval:()=>1,clearInterval(){},Date:class extends Date{static now(){return clock}},Math:Object.assign(Object.create(Math),{random:()=>roll}),requestAnimationFrame:fn=>fn()});
for(const file of ['app.js','casino.js','polish.js','expansion.js','crime.js','consolidation.js','factory.js','seaport.js','wanderer_fix.js','v55.js','recruitment.js','stabilization.js']){let s=fs.readFileSync(path.join(dir,file),'utf8');if(file==='app.js')s=s.replace(/startRefillTimer\(\);\s*titleScreen\(\);\s*$/,'');vm.runInContext(s,ctx,{filename:file});}
const run=s=>vm.runInContext(s,ctx),text=()=>node('#screen').textContent,lines=()=>node('#screen').childNodes.map(x=>x.textContent),results=[];
async function drain(){for(let i=0;i<8;i++)await run('outputQueue')}
async function command(s){await run(`handleCommand(${JSON.stringify(s)})`);await drain();if(run('stage')==='r5Loot')await command('leave behind');}
async function reset(){await drain();storage.clear();run(`resetPlayer();stage='mercy';mercyLocation='town';player.handle='RepairQA';player.flags.interfaceUnlocked=true;player.flags.mainSolaceQuest='complete';player.flags.mercyDiscovered=true;player.hp=player.maxHp;currentHotkeys={};numberedChoices={};busy=false;activeSaveSlot=1;`);node('#screen').innerHTML='';}
async function test(name,fn){try{await reset();await fn();await drain();results.push({name,pass:true})}catch(e){results.push({name,pass:false,error:e.stack,state:run('JSON.stringify({stage,flags:player.flags})'),tail:lines().slice(-35)});}}
async function choose(label){await drain();const map=run('numberedChoices'),key=Object.keys(map).find(k=>map[k]===label.toLowerCase());assert(key,'Missing numbered choice '+label+': '+JSON.stringify(map));await command(key);}
async function road(name='June',unlocked=true){run(`stage='wandererRoad';currentRoadWanderer=${JSON.stringify(name)};player.bolts=1000;port55State().freed=${unlocked};port55State().stage=${unlocked?"'done'":"'investigate'"};v53WandererMenu(wandererByName(currentRoadWanderer),true)`);await drain();}
async function hire(name='June'){await road(name);await choose('recruit');await choose('confirm hire');assert(run(`portIsHired(${JSON.stringify(name)})`));}
async function building(role,name){run(`stage='seaport'`);await command(role);if(name){await choose('assign staff');await choose('assign '+name);await choose('confirm assignment');}assert.equal(run('stage'),'port55Service');}
(async()=>{
await test('Fresh new game via Old House and Solace → Factory fights → Forge → charge → road → liberation → saved chapter completion',async()=>{
 run(`stage='title';titleScreen()`);await drain();await command('new game');await command('yes');await command('stand up');await command('RepairFresh');await command('yes');await command('check cabinet');await command('search room');await command('inspect computer');await command('hello');await command('listen');await command('log coordinates');
 assert.equal(run('player.level'),1);assert(!run('player.flags.factoryFinalComponent'));await command('testing');await command('lantern127');assert(run('testMode'));
 async function roadUntil(target){let steps=0;while(run('stage')!==target&&steps++<70){const st=run('stage');let action;
 if(st==='roadReady')action='road';else if(st==='turnComplete'||st==='questRoadComplete')action='continue';else if(st==='wandererRoad')action='move on';else if(st==='fork')action='continue to solace';else if(st==='settlement')action=text().includes('GUARD > State your business.')?'abandoned terminal sent me':'approach gate';else if(st==='encounter'){const opts=run('Object.values(numberedChoices)');action=['move on','back away','walk around','head for lights','keep moving','continue'].find(x=>opts.includes(x))||opts[opts.length-1];}else throw Error('Unexpected road state '+st);await command(action);}
 assert.equal(run('stage'),target);}
 await roadUntil('mercy');await command('east gate');await command('head east');await roadUntil('eastEnd');await command('enter factory');await command('tomorrow project terminal');await command('exit terminal');
 await command('enter inner factory');
 for(let f=0;f<4;f++){
  await command(String(f+1));await command(String([2,4,5,2][f]));await command('search');await command('return to floor');await command(f===3?'4':'6');await command('fight');
  let rounds=0;while(run('stage')==='combat'&&rounds++<80){run('player.hp=player.maxHp');await command('attack')}
  assert.equal(run('factoryDone()'),f+1);await command('return to floor');await command('0');
 }
 assert(run('player.flags.factoryFinalComponent'));await command('5');await command('talk to forge');assert(run('!!player.flags.r5ChargeJob'));clock+=31000;await command('check dynamite');assert(run('player.flags.portChargePrepared'));await command('back');await command('road to seaport');assert.equal(run('stage'),'portObstruction');await command('use dynamite');assert(run('player.flags.portRoadCleared'));assert(!run("hasItem('Prepared Dynamite Charge')"));
 for(let n=0;n<5;n++){await command('continue east');let rounds=0;while(run('stage')==='combat'&&rounds++<80){run('player.hp=player.maxHp');await command('attack')}}
 assert.equal(run('stage'),'seaport');await command('harbor docks');await command('inspect fishermen');await command('confront fishermen');let rounds=0;while(run('stage')==='combat'&&rounds++<80){run('player.hp=player.maxHp');await command('attack')}
 assert.equal(run('port55State().stage'),'free');await command('free the survivors');assert(run('port55State().freed'));await command('the rusty anchor');await command('talk');await command('return to harbor');
 await command('market area');await command('workshop [vacant]');await command('tomorrow project terminal');assert(run('player.flags.chapterOneComplete'));await command('skip');await command('continue');
 const journey=lines().join('\n');run('saveGame(1)');run('player.flags.chapterOneComplete=false;player.flags.portRoadCleared=false');run('loadGame(1)');await drain();assert(run('player.flags.chapterOneComplete'));assert(run('player.flags.portRoadCleared'));assert.equal(run('factoryDone()'),4);assert(run('port55State().freed'));
 fs.writeFileSync(path.join(__dirname,'r5-progression-transcript.txt'),journey+'\n\nAFTER SAVE/LOAD:\n'+lines().join('\n'));fs.writeFileSync(path.join(__dirname,'r5-final-state.json'),run('JSON.stringify({stage,level:player.level,hp:player.hp,turns:player.turns,bosses:factoryDone(),chargePrepared:player.flags.portChargePrepared,roadCleared:player.flags.portRoadCleared,seaport:port55State(),chapterComplete:player.flags.chapterOneComplete})'));});
console.log(JSON.stringify(results,null,2));process.exit(results.some(x=>!x.pass)?1:0);})();