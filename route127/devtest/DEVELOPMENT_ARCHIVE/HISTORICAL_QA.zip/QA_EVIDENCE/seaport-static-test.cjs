const fs=require('fs'),assert=require('assert');const a=fs.readFileSync(__dirname+'/../app.js','utf8'),p=fs.readFileSync(__dirname+'/../seaport.js','utf8'),h=fs.readFileSync(__dirname+'/../index.html','utf8');
for(const x of ['if(portCommand(cmd))return;','portCombatWin(c)','portCombatRetreat(c)','portMenu();'])assert(a.includes(x),x);
for(const x of ['portReady()','factoryDone()===4','portMove(-1)','portMove(1)','s.seen[s.position]','s.cleared[s.position]','s.arrived','gainXp(190)','player.flags.seaportRoute','stage=\'seaport\''])assert(p.includes(x),x);
assert(/seaport\.js\?v=[^"']+/.test(h));console.log('PASS: 15 integration and persistence static checks');
