const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync(__dirname+'/../v55.js','utf8');
let lines=[], player={flags:{},bolts:300,pack:[],packMax:10,lifetimeTurns:0},stage='seaport',numberedChoices={},currentHotkeys={};
const ctx={player,stage,numberedChoices,currentHotkeys,add:(s)=>lines.push(s),updateHud:()=>{},addPack:(n)=>{player.pack.push({name:n});return true},packSlotsUsed:()=>0,findItem:()=>null,showInventory:()=>{},casinoMenu:()=>{},v49Autosave:()=>{},Math,console,portMove:()=>{},startCombat:()=>{},handleCombat:()=>{},};vm.createContext(ctx);vm.runInContext(src,ctx);
const run=(code)=>vm.runInContext(code,ctx);
let checks=0;function ok(condition,msg){assert(condition,msg);checks++;}
ok(run('port55State().stage')==='investigate','initial stage');
run("port55State().stage='meet';port55State().freed=true;port55State().metKaiden=true;port55State().metMia=true;port55State().stage='done'");
ok(run('port55CompleteChapter()')===true,'complete once');ok(player.flags.chapterOneComplete===true,'persistent flag');ok(run('port55CompleteChapter()')===false,'no replay');
ok(lines.some(s=>String(s).includes('YOUR JOURNEY IS NOT')),'finale');
run('player.lifetimeTurns=9;port55PatrolTick()');ok(run('port55PatrolName()')==='Docks','patrol moves');run('port55PatrolTick()');ok(run('player.flags.port55PatrolIndex')===3,'no duplicate patrol');
run('player.flags.equippedPet="Ferret"');run('player.bolts=0');run('Math.random=()=>0');run('petCombatRound({hp:5,bolts:3,name:"RAIDER"})');ok(player.bolts===2,'ferret steals existing bolts');
run('player.flags.equippedPet=null');run('petCombatRound({hp:5,bolts:10,name:"RAIDER"})');ok(player.bolts===2,'unequipped ferret inactive');
run('player.flags.equippedPet="Ferret"');run('petCombatRound({hp:0,bolts:10,name:"RAIDER"})');ok(player.bolts===2,'no steal dead enemy');
run('player.flags.equippedPet="Ferret"');run('port55State().stage="done";port55Menu()');ok(Object.keys(ctx.numberedChoices).length>=10,'menu');
console.log('PASS '+checks+' targeted v55.1 state assertions');
