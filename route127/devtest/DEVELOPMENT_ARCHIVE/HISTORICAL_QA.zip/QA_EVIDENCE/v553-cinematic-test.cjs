
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const src=fs.readFileSync(path.join(__dirname,'../v55.js'),'utf8');
const fn=src.slice(src.indexOf('function port55LiberationArt(replay=false){'));
let logs=[],nodes=[],autosaves=0,turns=20,bolts=42;
const f={seaport55:{freed:false}};
const context={
 player:{flags:f,turns,bolts},outputQueue:Promise.resolve(),
 add:(t)=>logs.push(t),followOutput:()=>{},
 v49Autosave:()=>{autosaves++},
 document:{createElement:(tag)=>({tag,children:[],appendChild(el){this.children.push(el)},set hidden(x){this._hidden=x},get hidden(){return this._hidden}})},
 screen:{appendChild(el){nodes.push(el)}}
 };
vm.createContext(context);vm.runInContext(fn,context);
(async()=>{
 assert.equal(context.port55LiberationArt(false),false,'blocked before freedom');
 f.seaport55.freed=true;
 assert.equal(context.port55LiberationArt(false),true);
 await context.outputQueue;
 assert.equal(nodes.length,1);
 assert.equal(nodes[0].children[0].src,'seaport_liberation.png');
 assert.equal(f.port552ArtSeen,true);
 assert.equal(autosaves,1);
 assert.equal(context.port55LiberationArt(false),false,'once-only auto trigger');
 assert.equal(context.port55LiberationArt(true),true,'replay');
 await context.outputQueue;
 assert.equal(nodes.length,2);
 assert.equal(autosaves,1,'no replay autosave');
 assert.equal(context.player.turns,20);
 assert.equal(context.player.bolts,42);
 nodes[1].children[0].onerror();
 assert.equal(nodes[1].children[0].hidden,true);
 assert.equal(nodes[1].children[1].hidden,false);
 assert(!src.includes('PORT552_HARBOR'),'ASCII array removed');
 assert(fs.existsSync(path.join(__dirname,'../seaport_liberation.png')));
 console.log('PASS: 13 cinematic assertions (stage, once-only, replay, no rewards/turns, fallback, asset, ASCII removal)');
})().catch(e=>{console.error(e);process.exitCode=1});
