const fs=require('fs'),assert=require('assert');
const app=fs.readFileSync(require('path').join(__dirname,'..','app.js'),'utf8');
const polish=fs.readFileSync(require('path').join(__dirname,'..','polish.js'),'utf8');
// Regression checks for the observed name-color leakage: NPC/wanderer handling
// must color a bounded leading name token, never a random fraction of dialogue.
assert(app.includes('const npcMatch=upper.match(/^(TIM|MURPHY|JEN|WAYNE|JOHNNY|AMII)\\b/)'));
assert(app.includes('const wandererName=(typeof wanderers!=="undefined"?wanderers:[]).find'));
assert(app.includes('colorField(div,text,klass,1,0,name.length)'));
assert(app.includes('Color only the speaker/name token'));
// The level-5+ renderer also bounds wanderer color to the leading name.
assert(polish.includes('if(upper.startsWith(w.name.toUpperCase()))ranges.push([0,w.name.length,\'wanderer-green\'])'));
// Gear matching remains separate from the speaker-name path; rarity handling is preserved.
assert(app.includes('const equipment=Object.keys(GEAR).find(name=>upper.includes(name.toUpperCase()))'));
console.log('6/6 ANSI name-boundary source assertions passed');
