const fs=require('fs'),assert=require('assert'),path=require('path');
const src=fs.readFileSync(path.join(__dirname,'..','casino.js'),'utf8');
assert(src.includes("player.level<5&&!['dice','rps','blackjack'].includes(r.game)"),"Blackjack must be playable below Level 5 after selecting it");
assert(src.includes("game==='slots'&&player.level<5"),'Slots must remain Level 5 gated');
assert(src.includes("game==='rats'&&!player.flags.port55Casino"),'Rat racing must remain Seaport gated');
assert(!src.includes("if(player.level<5&&!['dice','rps'].includes(r.game))"),'Old blocking gate must be removed');
console.log('PASS 4 blackjack access and level-gate source assertions');
