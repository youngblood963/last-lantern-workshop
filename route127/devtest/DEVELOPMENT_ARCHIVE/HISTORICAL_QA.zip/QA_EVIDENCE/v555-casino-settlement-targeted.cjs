const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('casino.js','utf8');
const start=src.indexOf('function casinoSettle('),end=src.indexOf('\nfunction casinoDiceFace(',start);
assert(start>=0&&end>start);
const context={player:{bolts:100},updateHud(){},casinoCheckpoint(){}};
vm.createContext(context);vm.runInContext(src.slice(start,end),context);
const r={status:'active'};
assert.strictEqual(context.casinoSettle(r,50,'win'),true);assert.strictEqual(context.player.bolts,150);assert.strictEqual(context.casinoSettle(r,50,'again'),false);assert.strictEqual(context.player.bolts,150);
for(const bad of [-1,NaN,Infinity,0.5,Number.MAX_SAFE_INTEGER]){const round={status:'active'};assert.strictEqual(context.casinoSettle(round,bad,'invalid'),false);assert.strictEqual(round.status,'active');assert.strictEqual(context.player.bolts,150)}
const zero={status:'active'};assert.strictEqual(context.casinoSettle(zero,0,'loss'),true);assert.strictEqual(context.player.bolts,150);
console.log('PASS 13 casino settlement assertions');
