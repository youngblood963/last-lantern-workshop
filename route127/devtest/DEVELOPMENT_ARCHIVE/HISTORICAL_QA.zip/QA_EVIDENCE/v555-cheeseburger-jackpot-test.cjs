const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const gameDir=path.join(__dirname,'..');const el=()=>({addEventListener(){},classList:{add(){},remove(){},toggle(){}},childNodes:[{nodeValue:''}],append(){},appendChild(){},querySelectorAll(){return []},style:{},dataset:{},focus(){},remove(){}});const nodes={},storage=new Map();
const c=vm.createContext({console,document:{querySelector:s=>nodes[s]||(nodes[s]=el()),createElement:el,createTextNode:el,body:el()},window:{ROUTE127_QA_BUILD:true,addEventListener(){}},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},setInterval:()=>1,clearInterval(){},setTimeout,clearTimeout,Date,Math});
let src=fs.readFileSync(path.join(gameDir,'app.js'),'utf8').replace(/startRefillTimer\(\);\s*titleScreen\(\);\s*$/,'');vm.runInContext(src,c);for(const f of ['casino.js','polish.js','expansion.js','crime.js','consolidation.js','factory.js','seaport.js','wanderer_fix.js','v55.js'])vm.runInContext(fs.readFileSync(path.join(gameDir,f),'utf8'),c);const run=s=>vm.runInContext(s,c);let n=0;const eq=(a,b)=>{assert.strictEqual(a,b);n++};
run("player.level=5;player.flags.casino={nextId:2,round:{id:1,game:'slots',status:'active',bet:2}};player.flags.cheeseburgerOwned=false;player.flags.ownedPets=[];player.packMax=10;casinoSlotDraw=()=> 'RAT';Math.random=()=>0.01;casinoResolve(casinoRound())");
eq(run('player.flags.cheeseburgerOwned'),true);eq(run("player.flags.ownedPets.includes('Cheeseburger')"),true);eq(run('player.packMax'),16);eq(run('player.flags.casino.round.status'),'settled');
run("player.flags.casino.round={id:2,game:'slots',status:'active',bet:2};casinoSlotDraw=()=> 'SCRAP';Math.random=()=>0.01;casinoResolve(casinoRound())");eq(run('player.packMax'),16);eq(run("player.flags.ownedPets.filter(x=>x==='Cheeseburger').length"),1);
console.log(`v55.5 Cheeseburger jackpot: ${n}/${n} assertions passed`);

// The application may schedule recurring timers; all synchronous assertions above are complete.
process.exit(0);
