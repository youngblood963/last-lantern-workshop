const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const src=fs.readFileSync(path.join(__dirname,'..','app.js'),'utf8');
const a=src.indexOf('  if(mercyLocation==="jenRoomChest"){'),b=src.indexOf('  if(mercyLocation==="jenRoom"){',a);
assert(a>=0&&b>a);
const handler=src.slice(a,b);
function run(cmd,player){let messages=[];const ctx={cmd,player,mercyLocation:'jenRoomChest',add:s=>messages.push(s),packSlotsUsed:()=>player.pack.length,updateHud:()=>{}};vm.runInNewContext('(function(){'+handler+'})()',ctx);return messages;}
const item=(name,qty=1)=>({name,type:'material',qty});
let p={flags:{rustyRoomOwned:true},packMax:10,weapon:'Knife',armor:'Jacket',pack:[item('Scrap',3)],rustyRoomChest:Array.from({length:10},(_,i)=>item('Stored'+i))};
run('deposit scrap',p);assert.equal(p.pack[0].qty,3);assert.equal(p.rustyRoomChest.length,10);
p.rustyRoomChest[0].name='Scrap';run('deposit scrap x2',p);assert.equal(p.pack[0].qty,1);assert.equal(p.rustyRoomChest[0].qty,3);
p={flags:{rustyRoomOwned:true},packMax:1,weapon:'Knife',armor:'Jacket',pack:[item('Scrap',1)],rustyRoomChest:[item('Wire',2)]};
run('withdraw wire',p);assert.equal(p.pack.length,1);assert.equal(p.rustyRoomChest[0].qty,2);
p.rustyRoomChest=[item('Scrap',2)];run('withdraw scrap x2',p);assert.equal(p.pack[0].qty,3);assert.equal(p.rustyRoomChest.length,0);
console.log('PASS 4 chest full-capacity and same-stack merge assertions');
