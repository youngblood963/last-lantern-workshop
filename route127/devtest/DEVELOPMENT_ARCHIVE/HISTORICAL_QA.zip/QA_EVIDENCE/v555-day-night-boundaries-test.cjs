const fs=require('fs'),path=require('path'),assert=require('assert');
const s=fs.readFileSync(path.join(__dirname,'..','app.js'),'utf8');
const time=s.match(/function timePhase\(\)\s*\{([^}]+)\}/)?.[1]||'';
const spend=s.match(/function spendTurns\(count=1\)\s*\{([\s\S]*?)\n\}/)?.[1]||'';
const checks=[
 ['Hours before 06:00 are DARK',time.includes('h<6?"DARK"')],
 ['06:00 through 07:59 is DAWN',time.includes('h<8?"DAWN"')],
 ['08:00 through 16:59 is DAY',time.includes('h<17?"DAY"')],
 ['17:00 through 19:59 is DUSK',time.includes('h<20?"DUSK"')],
 ['20:00 onward is DARK',time.includes('h<20?"DUSK":"DARK"')],
 ['Turn spending rejects invalid counts',spend.includes('!Number.isInteger(count)||count<0')],
 ['Ordinary players cannot overspend turns',spend.includes('player.turns<count')],
 ['World hour advances by actual turn count',spend.includes('worldHour=((player.flags.worldHour??8)+count)%24')],
 ['Night combat damage uses isDark',s.includes('const nightRaw=isDark()?Math.ceil(raw*1.15):raw')],
 ['Night XP bonus remains in reward paths',s.includes('isDark()?Math.ceil(c.xp*1.1):c.xp')]
];
for(const [label,ok] of checks){assert.ok(ok,label);console.log('PASS',label)}
console.log(`${checks.length}/${checks.length} assertions passed`);
