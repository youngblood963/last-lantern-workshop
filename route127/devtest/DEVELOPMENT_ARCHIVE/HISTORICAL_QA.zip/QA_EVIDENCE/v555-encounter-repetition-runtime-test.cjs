const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const src=fs.readFileSync(path.join(__dirname,'..','app.js'),'utf8');
const a=src.indexOf('function shuffled(ids)'),b=src.indexOf('function currentRoadEncounterIndex()',a);
assert(a>=0&&b>a,'live encounter selection functions found');
const ctx={roadGoal:'early',encounters:Array.from({length:12},(_,i)=>({id:i,...(i===11?{minLevel:5}:{})})),eastEncounters:Array.from({length:5},(_,i)=>({id:i})),player:{level:1,recentEncounters:[],encounterDone:{},flags:{}},roadTurn:0,roadTurnCharged:false};
vm.createContext(ctx);vm.runInContext(src.slice(a,b)+'\nthis.reroll=rerollRoad;this.remember=rememberEncounter;this.key=encounterHistoryKey;this.order=()=>roadEncounterOrder;',ctx);
let n=0;const check=(v,m)=>{assert.ok(v,m);n++};
ctx.reroll(9);const first=Array.from(ctx.order());check(first.length===9,'nine slots');check(new Set(first).size===9,'no duplicate slots');check(!first.includes(11),'level gated');
for(const id of first)ctx.remember(id);
ctx.reroll(9);const next=Array.from(ctx.order());check(!first.includes(next[0]),'fresh encounters precede repeats');check(!first.includes(next[1]),'both fresh encounters first');check(next[0]!==next[1],'fresh events distinct');
ctx.player.recentEncounters=['mercy:1','house:2'];ctx.reroll(9);check(ctx.player.recentEncounters.join(',')==='early:1,early:2','legacy keys migrated');
ctx.player.level=5;ctx.player.recentEncounters=[];ctx.reroll(12);check(Array.from(ctx.order()).includes(11),'level unlock honored');
ctx.roadGoal='east';ctx.player.recentEncounters=['early:0'];ctx.reroll(5);check(Array.from(ctx.order()).length===5,'east pool independent');check(ctx.key(0)==='east:0','east history namespaced');
ctx.remember(0);ctx.remember(0);check(ctx.player.recentEncounters.filter(x=>x==='east:0').length===1,'duplicate history collapsed');
for(let run=0;run<250;run++){ctx.player.recentEncounters=[];ctx.roadGoal='early';ctx.player.level=1;ctx.reroll(9);const arr=Array.from(ctx.order());check(new Set(arr).size===arr.length,'randomized pool remains unique');}
console.log(`PASS encounter repetition live runtime: ${n} assertions`);
