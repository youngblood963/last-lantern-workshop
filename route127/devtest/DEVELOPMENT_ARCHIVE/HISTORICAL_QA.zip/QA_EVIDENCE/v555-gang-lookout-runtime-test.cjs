const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(require('path').join(__dirname,'..','app.js'),'utf8');
const start=source.indexOf('function handleCombat(cmd){');
const end=source.indexOf('\nfunction ',start+10);
assert(start>=0&&end>start,'combat handler present');
const code=source.slice(start,end);
function run(damage,rounds){
 const lines=[];const p={weapon:'Pipe',hp:500,maxHp:500,flags:{},turns:50};
 const ctx={combatState:{name:'GANG LOOKOUT',hp:18,maxHp:18,min:1,max:1,xp:35,bolts:5,source:'encounter',enemies:[{name:'LOOKOUT',hp:18,bolts:5}],signalRounds:0,reinforcementsArrived:false},player:p,stage:'combat',add:(x)=>lines.push(x),rollDamage:()=>damage,isDark:()=>false,armorDefense:()=>0,updateHud:()=>{},gainXp:()=>{},gainBolts:()=>{},flushResults:()=>{},completeRoadTurn:()=>{},resultBuffer:[],petCombatRound:()=>{}};
 vm.createContext(ctx);vm.runInContext(code+'\nthis.attack=handleCombat;',ctx);
 for(let i=0;i<rounds;i++)ctx.attack('attack');return {c:ctx.combatState,lines};
}
let a=run(3,3);assert(a.c.reinforcementsArrived);assert.equal(a.c.enemies.length,4);assert.equal(a.c.maxHp,93);assert.equal(a.c.hp,84);assert.equal(a.c.signalRounds,3);assert(a.lines.some(x=>String(x).includes('whistle')));
let b=run(10,2);assert.equal(b.c,null);assert(!b.lines.some(x=>String(x).includes('whistle')));
console.log('Gang lookout runtime: 7 assertions passed');
