const fs=require('fs'),assert=require('assert'); const s=fs.readFileSync(require('path').join(__dirname,'../app.js'),'utf8');
assert.match(s,/"GANG LOOKOUT":\{name:"GANG LOOKOUT",level:4,hp:18/);
assert.match(s,/signalRounds>=3/);
assert.match(s,/name:"GANG LEADER",hp:35/);
assert.match(s,/name:"GANG MEMBER A",hp:20/);
assert.match(s,/name:"GANG MEMBER B",hp:20/);
assert.match(s,/filter\(e=>e.hp>0\)\.slice\(0,2\)/);
console.log('Gang lookout structural checks: 6 passed');
