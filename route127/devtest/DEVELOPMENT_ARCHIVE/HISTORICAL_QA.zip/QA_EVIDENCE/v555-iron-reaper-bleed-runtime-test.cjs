const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const source=fs.readFileSync(path.join(__dirname,'..','app.js'),'utf8');
const start=source.indexOf('function handleCombat(cmd){');
const end=source.indexOf('\nfunction ',start+10);
assert(start>=0&&end>start,'handleCombat found');
const code=source.slice(start,end);
function attack(randoms,weapon='Iron Reaper'){
 const messages=[];const player={weapon,accessory:'',hp:100,maxHp:100,flags:{},turns:50};
 const rand=[...randoms];const customMath=Object.create(Math);customMath.random=()=>rand.length?rand.shift():0.5;
 const ctx={Math:customMath,GEAR:{'Iron Reaper':{bleedChance:.10},"Niko's Collar":{critBonus:.02}},combatState:{name:'TEST ENEMY',hp:100,maxHp:100,min:1,max:1,xp:0,bolts:0,source:'encounter'},player,stage:'combat',add:x=>messages.push(String(x)),rollDamage:()=>10,isDark:()=>false,armorDefense:()=>0,updateHud:()=>{},gainXp:()=>{},gainBolts:()=>{},flushResults:()=>{},completeRoadTurn:()=>{},resultBuffer:[],petCombatRound:()=>{},handlePlayerDeath:()=>{ctx.died=true},v555AwardEquipmentDrop:()=>{}};
 vm.createContext(ctx);vm.runInContext(code+'\nthis.attack=handleCombat;',ctx);ctx.attack('attack');return {messages,ctx};
}
const proc=attack([0.05,0.5]);assert(proc.messages.some(m=>m.includes('IRON REAPER BLEED')),'proc feedback');assert(proc.messages.some(m=>m.includes('YOU DEAL 13')),'bleed adds 3 damage');
const noProc=attack([0.5,0.5]);assert(!noProc.messages.some(m=>m.includes('IRON REAPER BLEED')),'no-proc has no bleed feedback');assert(noProc.messages.some(m=>m.includes('YOU DEAL 10')),'base damage unchanged without proc');
const wrongWeapon=attack([0.05,0.5],'Pipe');assert(!wrongWeapon.messages.some(m=>m.includes('IRON REAPER BLEED')),'other weapons do not bleed');assert(wrongWeapon.messages.some(m=>m.includes('YOU DEAL 10')),'other weapon damage unchanged');
console.log('Iron Reaper bleed runtime: 7 assertions passed');
