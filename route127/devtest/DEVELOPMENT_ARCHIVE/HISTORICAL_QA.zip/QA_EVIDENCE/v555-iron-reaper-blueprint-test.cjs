const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');const gameDir=path.join(__dirname,'..');
const el=()=>({addEventListener(){},classList:{add(){},remove(){},toggle(){}},childNodes:[{nodeValue:''}],append(){},appendChild(){},querySelectorAll(){return []},style:{},dataset:{},focus(){},remove(){}});const nodes={},storage=new Map();const c=vm.createContext({console,document:{querySelector:s=>nodes[s]||(nodes[s]=el()),createElement:el,createTextNode:el,body:el()},window:{ROUTE127_QA_BUILD:true,addEventListener(){}},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},setInterval:()=>1,clearInterval(){},setTimeout,clearTimeout,Date,Math});let src=fs.readFileSync(path.join(gameDir,'app.js'),'utf8').replace(/startRefillTimer\(\);\s*titleScreen\(\);\s*$/,'');vm.runInContext(src,c);for(const f of ['casino.js','polish.js','expansion.js','crime.js','consolidation.js','factory.js','seaport.js','wanderer_fix.js','v55.js'])vm.runInContext(fs.readFileSync(path.join(gameDir,f),'utf8'),c);const run=s=>vm.runInContext(s,c);let n=0;const eq=(a,b)=>{assert.strictEqual(a,b);n++};
eq(run("GEAR['Iron Reaper'].min"),18);eq(run("GEAR['Iron Reaper'].max"),27);eq(run("GEAR['Iron Reaper'].bleedChance"),0.10);eq(run("CRAFT_RECIPES.ironReaper.scrap"),8);eq(run("CRAFT_RECIPES.ironReaper.wire"),4);eq(run("CRAFT_RECIPES.ironReaper.cloth"),3);eq(run("CRAFT_RECIPES.ironReaper.bolts"),75);eq(run("CRAFT_RECIPES.ironReaper.minLevel"),6);
run("stage='mercy';mercyLocation='murphy';player.flags.v49RecipeBandage=true;player.flags.v49MurphyMenu='recipes';player.level=5");run("v49MurphyCommand('iron reaper')");eq(run("player.flags.v49MurphyRecipe"),undefined); // locked out of selecting the recipe below level 6
run("player.level=6;v49MurphyCommand('iron reaper')");eq(run("player.flags.v49MurphyRecipe"),'ironReaper');
console.log(`v55.5 Iron Reaper blueprint: ${n}/${n} assertions passed`);

// Optional approved bleed chance is active in the main combat attack path.
const combatStart=src.indexOf('function handleCombat(cmd){');
const combatBody=src.slice(combatStart);
assert(combatBody.includes('player.weapon==="Iron Reaper"?(GEAR["Iron Reaper"]?.bleedChance||0):0'),'Iron Reaper bleed is weapon-gated');
assert(combatBody.includes('Math.random()<bleedChance'),'Iron Reaper uses the approved probabilistic bleed chance');
assert(combatBody.includes('(bleedProc?3:0)'),'Bleed proc adds its bounded damage bonus');
assert(combatBody.includes('IRON REAPER BLEED — the hooked edge opens a wound (+3 damage).'),'Bleed proc has combat feedback');
console.log('PASS Iron Reaper optional bleed combat integration (4 assertions)');
