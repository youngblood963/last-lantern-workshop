const fs=require('fs'),assert=require('assert'),path=require('path');
const src=fs.readFileSync(path.join(__dirname,'..','app.js'),'utf8');
const checks=[
 ['Jen menu exposes Unpaid Tab',src.includes('ASK ABOUT UNPAID TAB')],
 ['Jen menu exposes A Familiar Face',src.includes('A FAMILIAR FACE   SMALL TALK')],
 ['Unpaid Tab uses character flag',src.includes('f.jenUnpaidTab="active"')&&src.includes('f.jenUnpaidTab="done"')],
 ['Unpaid Tab checks affordability',src.includes('if(player.bolts<12)')],
 ['Unpaid Tab charges 12 Bolts',src.includes('player.bolts-=12')],
 ['Unpaid Tab grants stated XP and reward',src.includes('gainBolts(20);gainXp(25)')],
 ['A Familiar Face uses character flag',src.includes('f.jenFamiliarFace="active"')&&src.includes('f.jenFamiliarFace="done"')],
 ['A Familiar Face grants one-time reward',src.includes('gainXp(30);gainBolts(10)')],
 ['Both quests appear in active journal',src.includes('UNPAID TAB","Settle the tavern')&&src.includes('A FAMILIAR FACE","Follow up with Jen')],
 ['Both quests appear in completed journal',src.includes('["jenUnpaidTab","UNPAID TAB"],["jenFamiliarFace","A FAMILIAR FACE"]')],
];
for(const [name,ok] of checks){assert.ok(ok,name);console.log('PASS',name)}
console.log(`${checks.length}/${checks.length} Jen extra-quest source assertions passed`);
