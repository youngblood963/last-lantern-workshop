const fs=require('fs'); const assert=require('assert');
const src=fs.readFileSync(require('path').join(__dirname,'..','app.js'),'utf8');
const block=src.match(/title:"GANG LOOKOUT"[\s\S]*?(?=\n  \{ exclusive:true, title:|\n  \{ title:)/);
assert(block,'Gang Lookout encounter exists');
const sneak=block[0].match(/else if\(cmd\.includes\("sneak"\)\)\{([^}]*)\}/);
assert(sneak,'Sneak option exists');
assert(!/gainXp\s*\(/.test(sneak[1]),'Passive sneaking must not grant XP');
assert(/GANG LOOKOUT".*signalRounds:0/.test(src),'Lookout combat setup retained');
console.log('3/3 Gang Lookout escape reward checks passed');
