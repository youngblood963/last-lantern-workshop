const fs=require('fs'),path=require('path'),assert=require('assert');
const s=fs.readFileSync(path.join(__dirname,'..','app.js'),'utf8');
const checks=[
 ['Niko Collar retains +15 max HP metadata',s.includes('"Niko\'s Collar":{rarity:"legendary",type:"accessory",def:3,maxHpBonus:15,critBonus:0.02,secondChance:true}')],
 ['Equipping an accessory applies the max HP delta',s.includes('const hpDelta=(GEAR[name]?.maxHpBonus||0)-(GEAR[previous]?.maxHpBonus||0)')],
 ['Current HP remains bounded after accessory swap',s.includes('player.hp=Math.min(player.hp,player.maxHp)')],
 ['Second Chance requires the collar to be equipped',s.includes('const collarEquipped=player.accessory==="Niko\'s Collar"')],
 ['Second Chance triggers only from lethal state',s.includes('if(!collarEquipped || player.hp>0 || Number(player.flags.nikoSecondChanceDay)===today)return false')],
 ['Second Chance is limited to once per game day',s.includes('player.flags.nikoSecondChanceDay=today')],
 ['Second Chance restores 1 HP and safely retreats from combat',s.includes('player.hp=1;')&&s.includes('if(combatState)handleCombat("flee")')],
 ['Death flow checks Second Chance before penalties',s.includes('if(tryNikoSecondChance())return;\n  player.deathStreak=')]
];
for(const [label,ok] of checks){assert.ok(ok,label);console.log('PASS',label)}

const combatStart=s.indexOf('function handleCombat(cmd){');
const combatEnd=s.indexOf('function ',combatStart+10);
const combatBody=s.slice(combatStart,combatEnd>combatStart?combatEnd:undefined);
assert.ok(combatBody.includes(`player.accessory==="Niko's Collar"`),'Combat applies collar crit only while equipped');
assert.ok(combatBody.includes('Math.random()<criticalChance'),'Critical chance uses randomized probability');
assert.ok(combatBody.includes('baseAttackDamage*(critical?1.5:1)'),'Critical hit increases base attack damage by 50 percent');
assert.ok(combatBody.includes(`NIKO'S COLLAR FLARES — CRITICAL HIT!`),'Critical hit has distinct feedback');
console.log('PASS Niko collar critical hit integration');

console.log(`${checks.length}/${checks.length} assertions passed`);
