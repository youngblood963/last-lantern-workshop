const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync(require('path').join(__dirname,'..','app.js'),'utf8');
const a=src.indexOf('function handleCombat(cmd){');
const b=src.indexOf('  if(cmd==="u"||cmd==="i"',a);
assert(a>=0&&b>a);
const code=src.slice(a,b)+'\n}';
for(const source of ['encounter','gateGuards','seaportLiberation','seaportRoadFight','factoryFight','jenBoss','houseBoss','serviceBoss','roadWanderer','townWanderer']){
 const calls=[];
 const ctx={combatState:{source},stage:'combat',player:{flags:{}},add:()=>{},completeRoadTurn:()=>{calls.push('road');ctx.stage='between'},portLiberationRetreat:()=>{calls.push('portLiberation');ctx.stage='seaport'},portCombatRetreat:()=>{calls.push('portRoad');ctx.stage='seaportRoad'},factoryCombatRetreat:()=>{calls.push('factory');ctx.stage='factory'},arriveHouse:()=>{calls.push('house');ctx.stage='house'},showCurrentContext:()=>calls.push('town'),currentRoadWanderer:{},};
 vm.createContext(ctx);vm.runInContext(code+'\nthis.run=handleCombat;',ctx);
 ctx.run('flee');assert.equal(ctx.combatState,null,`${source}: combat state cleared`);assert.notEqual(ctx.stage,'combat',`${source}: not stranded in combat`);
 assert(calls.length||['gateGuards','serviceBoss','townWanderer'].includes(source),`${source}: retreat handler invoked`);
}
console.log('PASS Niko retreat routes: 10 combat contexts exit without combat softlock');
