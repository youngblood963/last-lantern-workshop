const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const gameDir=path.join(__dirname,'..');
const el=()=>({addEventListener(){},classList:{add(){},remove(){},toggle(){}},childNodes:[{nodeValue:''}],append(){},appendChild(){},querySelectorAll(){return []},style:{},dataset:{},focus(){}});
const nodes={},storage=new Map();const c=vm.createContext({console,document:{querySelector:s=>nodes[s]||(nodes[s]=el()),createElement:el,createTextNode:el,body:el()},window:{ROUTE127_QA_BUILD:true},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},setInterval:()=>1,clearInterval(){},setTimeout,clearTimeout,Date,Math});
let src=fs.readFileSync(path.join(gameDir,'app.js'),'utf8').replace(/startRefillTimer\(\);\s*titleScreen\(\);\s*$/,'');vm.runInContext(src,c);for(const f of ['casino.js','polish.js','expansion.js','crime.js','consolidation.js','factory.js','seaport.js','wanderer_fix.js','v55.js'])vm.runInContext(fs.readFileSync(path.join(gameDir,f),'utf8'),c);
const run=s=>vm.runInContext(s,c);let checks=0;const eq=(a,b)=>{assert.strictEqual(a,b);checks++;};const ok=v=>{assert.ok(v);checks++;};
run("stage='mercy';mercyLocation='amii';player.flags.v55AmiiTalk=true;player.flags.nikoRewardClaimed=false;player.pack=[]");
run('Math.random=()=>0.96');run("handleV48Command('pet niko')");eq(run('player.flags.nikoRewardClaimed'),true);eq(run('player.pack[0].name'),"Niko's Collar");eq(run('player.pack[0].type'),'accessory');
run("handleV48Command('pet niko')");eq(run('player.pack.length'),1); // one reward per character
run("player.pack=[];player.flags.nikoPendingRewards=['Giant Dog Bone'];handleV48Command('claim niko gift')");eq(run('(player.flags.nikoPendingRewards||[]).length'),0);eq(run("player.pack[0].name"),'Giant Dog Bone');
run("player.pack=[];player.flags.nikoPendingRewards=['Giant Dog Bone'];player.packMax=0;handleV48Command('claim niko gift')");eq(run('(player.flags.nikoPendingRewards||[]).length'),1);
run("player.flags.v55AmiiTalk=true;handleV48Command('pet alex')");eq(run('player.hp'),run('player.hp'));
eq(run("GEAR[\"Niko's Collar\"].def"),3);eq(run("GEAR[\"Niko's Collar\"].maxHpBonus"),15);eq(run("GEAR[\"Niko's Collar\"].critBonus"),0.02);eq(run("GEAR[\"Niko's Collar\"].secondChance"),true);
console.log(`v55.5 Niko/Alex rewards: ${checks}/${checks} assertions passed`);

// The application may schedule recurring timers; all synchronous assertions above are complete.
process.exit(0);
