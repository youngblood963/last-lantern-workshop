const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const dir=path.join(__dirname,'..'),el=()=>({addEventListener(){},classList:{add(){},remove(){},toggle(){}},childNodes:[{}],append(){},appendChild(){},querySelectorAll(){return []},style:{},dataset:{},focus(){}}),store=new Map();
const c=vm.createContext({console,document:{querySelector:el,createElement:el,createTextNode:el,body:el()},window:{ROUTE127_QA_BUILD:true},localStorage:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v)},setInterval:()=>1,clearInterval(){},setTimeout,clearTimeout,Date,Math});
for(const file of ['app.js','casino.js','polish.js','expansion.js','crime.js','consolidation.js','factory.js','seaport.js','wanderer_fix.js','v55.js']){let s=fs.readFileSync(path.join(dir,file),'utf8');if(file==='app.js')s=s.replace(/startRefillTimer\(\);\s*titleScreen\(\);\s*$/,'');vm.runInContext(s,c)}
const run=s=>vm.runInContext(s,c);let checks=0;function eq(a,b){assert.strictEqual(a,b);checks++}
run(`player.accessory="Niko's Collar";player.flags={};player.hp=0;day=7;stage='combat';combatState={source:'serviceBoss'};activeSaveSlot=0;`);
eq(run('tryNikoSecondChance()'),true);eq(run('player.hp'),1);eq(run('player.flags.nikoSecondChanceDay'),7);eq(run('stage'),'serviceRoad');
run('saveGame(2);player.flags.nikoSecondChanceDay=undefined;player.hp=0;loadGame(2)');
eq(run('player.flags.nikoSecondChanceDay'),7);
run("player.hp=0;stage='combat';combatState={source:'serviceBoss'}");eq(run('tryNikoSecondChance()'),false);
run('day=8');eq(run('tryNikoSecondChance()'),true);eq(run('player.hp'),1);
console.log(`Niko second chance save/load persistence: ${checks}/${checks} assertions passed`);

// The application may schedule recurring timers; all synchronous assertions above are complete.
process.exit(0);
