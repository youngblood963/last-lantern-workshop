const fs=require('fs'),vm=require('vm'),assert=require('assert');
const s=fs.readFileSync(require('path').join(__dirname,'..','app.js'),'utf8');
const a=s.indexOf('function tryNikoSecondChance(){'),b=s.indexOf('function handlePlayerDeath(){',a);
assert(a>=0&&b>a);
const code=s.slice(a,b);
function run({accessory="Niko's Collar",hp=0,used,day=3,combat=true}={}){
 const events=[],p={accessory,hp,flags:{}};if(used!==undefined)p.flags.nikoSecondChanceDay=used;
 const ctx={player:p,day,stage:'combat',combatState:combat?{source:'roadWanderer'}:null,updateHud:()=>events.push('hud'),add:(msg)=>events.push(msg),handleCombat:(cmd)=>{events.push(cmd);ctx.combatState=null;ctx.stage='between'}};
 vm.createContext(ctx);vm.runInContext(code+'\nthis.trigger=tryNikoSecondChance;',ctx);
 return {trigger:ctx.trigger,ctx,p,events};
}
let t=run();assert.equal(t.trigger(),true);assert.equal(t.p.hp,1);assert.equal(t.p.flags.nikoSecondChanceDay,3);assert.equal(t.ctx.stage,'between');assert.equal(t.ctx.combatState,null);assert(t.events.includes('flee'));
assert.equal(t.trigger(),false,'cannot trigger twice on same day');
t=run({used:2});assert.equal(t.trigger(),true,'refreshes on new day');
t=run({used:3});assert.equal(t.trigger(),false,'already spent today');
t=run({accessory:'Plain Ring'});assert.equal(t.trigger(),false,'unequipped');
t=run({hp:1});assert.equal(t.trigger(),false,'nonlethal');
console.log('PASS Niko Second Chance runtime: lethal rescue, retreat, once/day, day reset, unequipped, nonlethal');
