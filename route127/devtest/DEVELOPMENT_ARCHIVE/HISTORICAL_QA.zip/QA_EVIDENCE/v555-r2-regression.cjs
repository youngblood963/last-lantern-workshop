const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const dir=path.join(__dirname,'..');
class Element{
 constructor(){this.childNodes=[];this.children=this.childNodes;this.style={};this.dataset={};this.value='';this.disabled=false;this._text='';this.hidden=false;this.classList={add(){},remove(){},toggle(){},contains(){return false}};}
 appendChild(n){this.childNodes.push(n);n.parentElement=this;return n} append(n){this.appendChild(n)}
 set textContent(v){this._text=String(v);this.childNodes=[]}get textContent(){return this._text+this.childNodes.map(x=>x.textContent||'').join('')}
 set innerHTML(v){this._text='';this.childNodes=[]}get innerHTML(){return this.textContent}
 addEventListener(){} focus(){}querySelectorAll(){return []}querySelector(){return null}setAttribute(){}removeAttribute(){}insertAdjacentElement(_,n){this.appendChild(n)}getBoundingClientRect(){return {width:100,height:100}}remove(){}
}
const nodes={};const node=k=>nodes[k]||(nodes[k]=new Element());node('.utility-name').childNodes=[{nodeValue:''}];node('#side-inv').parentElement=new Element();
const storage=new Map();let clock=Date.now(),roll=.2;
const ctx=vm.createContext({console,document:{querySelector:node,querySelectorAll:()=>[],createElement:()=>new Element(),createTextNode:s=>({textContent:s}),body:new Element()},window:{ROUTE127_QA_BUILD:true,addEventListener(){}},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},setTimeout:fn=>{queueMicrotask(fn);return 1},clearTimeout(){},setInterval:()=>1,clearInterval(){},Date:class extends Date{static now(){return clock}},Math:Object.assign(Object.create(Math),{random:()=>roll}),requestAnimationFrame:fn=>fn()});
for(const file of ['app.js','casino.js','polish.js','expansion.js','crime.js','consolidation.js','factory.js','seaport.js','wanderer_fix.js','v55.js','recruitment.js']){let s=fs.readFileSync(path.join(dir,file),'utf8');if(file==='app.js')s=s.replace(/startRefillTimer\(\);\s*titleScreen\(\);\s*$/,'');vm.runInContext(s,ctx,{filename:file});}
const run=s=>vm.runInContext(s,ctx),text=()=>node('#screen').textContent,lines=()=>node('#screen').childNodes.map(x=>x.textContent),results=[];
async function drain(){for(let i=0;i<8;i++)await run('outputQueue')}
async function command(s){await run(`handleCommand(${JSON.stringify(s)})`);await drain()}
async function reset(){await drain();storage.clear();run(`resetPlayer();stage='mercy';mercyLocation='town';player.handle='RepairQA';player.flags.interfaceUnlocked=true;player.flags.mainSolaceQuest='complete';player.flags.mercyDiscovered=true;player.hp=player.maxHp;currentHotkeys={};numberedChoices={};busy=false;activeSaveSlot=1;`);node('#screen').innerHTML='';}
async function test(name,fn){try{await reset();await fn();await drain();results.push({name,pass:true})}catch(e){results.push({name,pass:false,error:e.stack,state:run('JSON.stringify({stage,flags:player.flags})'),tail:lines().slice(-35)});}}
(async()=>{
await test('Murphy main and Talk render exactly one menu through command pipeline',async()=>{await command('murphy');assert.equal(lines().filter(x=>x==="MURPHY'S WORKSHOP").length,1);await command('3');assert.equal(lines().filter(x=>x==='MURPHY — TALK').length,1);assert.equal(run("numberedChoices['3']"),'ask about relay station');});
await test('Save and load menus do not trigger duplicate fallback',async()=>{await command('save');assert.equal(lines().filter(x=>x==='SAVE / LOAD').length,1);await command('1');assert.equal(lines().filter(x=>x==='SAVE / LOAD').length,2);await command('2');assert.equal(lines().filter(x=>x==='SAVE / LOAD').length,2);assert(text().includes('LOAD GAME — SELECT A SLOT'));});
await test('Combat entry visibly renders one actionable menu and numeric attack works',async()=>{run(`startCombat({name:'QA ENEMY',level:1,hp:50,min:1,max:1,xp:0,bolts:0},'encounter')`);await drain();assert.equal(lines().filter(x=>x.includes('[1] ATTACK')).length,1);assert.equal(run("numberedChoices['1']"),'attack');await command('1');assert(run('combatState.hp')<50);});
await test('Combat items render once and healing consumes one item',async()=>{run(`player.hp=30;startCombat({name:'QA ENEMY',level:1,hp:50,min:1,max:1,xp:0,bolts:0},'encounter')`);await drain();await command('2');assert.equal(lines().filter(x=>x.includes('COMBAT ITEMS')).length,1);await command('1');assert.equal(run('player.hp'),40);assert.equal(run("findItem('Energy Bars').qty"),1);});
await test('Charge remains locked without all four bosses and final component',async()=>{run(`stage='factoryWorkshop';player.flags.factoryFinalComponent=true;factoryState().done=[0,1,2]`);await command('talk to forge');assert(!run('player.flags.portChargePrepared'));run(`factoryState().done=[0,1,2,3];player.flags.factoryFinalComponent=false;stage='factoryWorkshop'`);await command('talk to forge');assert(!run('player.flags.portChargePrepared'));});
await test('Forge prepares charge once after legitimate Factory flags; save/load retains it',async()=>{run(`stage='factoryWorkshop';factoryState().done=[0,1,2,3];player.flags.factoryFinalComponent=true;addPack('Factory Charge Component','quest')`);await command('talk to forge');assert(run('player.flags.portChargePrepared'));assert.equal(run("findItem('Prepared Dynamite Charge').qty"),1);assert(!text().includes('inner works still need'));await command('back');await command('talk to forge');assert.equal(run("findItem('Prepared Dynamite Charge').qty"),1);run('saveGame(1);player.flags.portChargePrepared=false;loadGame(1)');await drain();assert(run('player.flags.portChargePrepared'));});
await test('Full backpack boss swap banks old weapon without false dropped notice',async()=>{run(`player.packMax=0;player.weapon='Rusted Pipe';factoryAwardBossWeapon(0)`);await drain();assert(run("player.stash.some(x=>x.name==='Rusted Pipe')"));assert(text().includes('Previous weapon moved to bank'));assert(!text().includes('leave Rusted Pipe behind'));});
await test('Full backpack holds finished bandage then permits collection',async()=>{run(`stage='factoryBench';player.packMax=0;player.flags.v49Job={endsAt:0,success:true};v49Workbench()`);await drain();await command('collect result');assert(run('!!player.flags.v49Job'));assert(text().includes('HELD AT BENCH'));assert(!text().includes('leave Reinforced Bandage behind'));run('player.packMax=10');await command('collect result');assert(run("hasItem('Reinforced Bandage')"));assert(run('player.flags.v49RecipeBandage'));});
await test('Cleared boss rooms and Inspect no longer describe waiting bosses',async()=>{run(`factoryState().done=[0,1,2,3];factoryState().floor=1;factoryState().room=5;stage='factoryDungeonRoom';factoryRender()`);await drain();await command('inspect');assert(!text().includes('worker waits'));assert(text().includes('Grinder has been defeated'));});
await test('Held random equipment and liberation reward never claim an item was dropped',async()=>{run(`player.packMax=0;v555AwardEquipmentDrop();v555ClaimEquipmentDrop();stage='port55Docks';port55State().stage='free';port55Free();port55Claim()`);await drain();assert(!text().includes('behind'));assert(run('player.flags.pendingEquipmentDrops.length')>0);assert.equal(run('player.flags.port55PendingRewards.length'),1);assert(text().includes('remains held at the harbor'));});

await test('R2 Nessa numeric exit has one menu, works after reload, and preserves purchase commands',async()=>{
 run(`stage='seaport';port55State().freed=true;player.bolts=500`);await command('pet vendor');
 assert.equal(run("numberedChoices['6']"),'return to harbor');
 assert.equal(lines().filter(x=>x==='SEAPORT — PET VENDOR — NESSA').length,1);
 await command('1');assert(run("port55Owned().includes('Scrap Rat')"));assert.equal(run('player.bolts'),425);
 await command('6');assert.equal(run('stage'),'seaport');
 await command('pet vendor');run('saveGame(1);loadGame(1)');await drain();
 assert.equal(run("numberedChoices['6']"),'return to harbor');await command('6');assert.equal(run('stage'),'seaport');
});
await test('R2 numeric clinic sale accepts spare Common and Rare gear with confirmation',async()=>{
 run(`stage='mercy';mercyLocation='wayne';player.bolts=100;player.weapon='Rusted Pipe';player.armor='Worn Jacket';player.pack=[];addPack('Canvas Coat','armor');addPack("King's Breaker",'weapon');player.armor='Canvas Coat';player.pack[0].name='Worn Jacket'`);
 await command('sell items');await command('1');assert.equal(run('player.flags.v53Sale?.name'),'Worn Jacket');
 await command('1');assert.equal(run('player.flags.v53Sale.mode'),'confirm');await command('1');
 assert(!run("hasItem('Worn Jacket')"));assert.equal(run('player.bolts'),102);
 await command('1');assert.equal(run('player.flags.v53Sale?.name'),"King's Breaker");await command('1');assert.equal(run('player.bolts'),102);await command('1');assert.equal(run('player.bolts'),133);assert(!run(`hasItem("King's Breaker")`));
 run(`addPack('Canvas Coat','armor');addPack('Prepared Dynamite Charge','quest');GEAR['QA Legendary']={rarity:'legendary',type:'weapon'};addPack('QA Legendary','weapon')`);
 assert.equal(run("v48SellPrice(findItem('Canvas Coat'))"),0);assert.equal(run("v48SellPrice(findItem('Prepared Dynamite Charge'))"),0);assert.equal(run("v48SellPrice(findItem('QA Legendary'))"),0);
});
await test('R2 map identifies Seaport, submenus, road and obstruction including overlay/reload',async()=>{
 run(`player.level=7;roadGoal='east';stage='seaport';port55State().freed=true;updateHud()`);await command('town streets');assert(node('#live-map').textContent.startsWith('SEAPORT'));
 await command('q');assert(node('#live-map').textContent.startsWith('SEAPORT'));run('saveGame(1);loadGame(1)');await drain();assert(node('#live-map').textContent.startsWith('SEAPORT'));
 run(`stage='portRoad';portState().position=3;v49LiveMap()`);assert(node('#live-map').textContent.includes('SEAPORT ROAD'));assert(node('#live-map').textContent.includes('<YOU>'));
 run(`stage='portObstruction';v49LiveMap()`);assert(node('#live-map').textContent.includes('COLLAPSED OVERPASS'));
 run(`stage='port55Pets';returnStage='mercy';mercyLocation='town';v49LiveMap()`);assert(node('#live-map').textContent.startsWith('SOLACE'));
 run(`returnStage='seaport';v49LiveMap()`);assert(node('#live-map').textContent.startsWith('SEAPORT'));
 run(`player.level=4;v49LiveMap()`);assert.equal(node('#live-map').hidden,true);
});
await test('R2 harbor occupation text distinguishes defeated enforcers from freed residents',async()=>{
 run(`stage='seaport';port55State().stage='confront';port55Menu()`);await drain();assert(text().includes('Armed fishermen control'));
 node('#screen').innerHTML='';run('portLiberationVictory()');await drain();assert(!text().includes('Armed fishermen control'));assert(text().includes('Two residents remain captive'));
 run(`port55State().freed=true;port55Menu()`);await drain();assert(text().includes('The harbor is free'));
});
await test('R2 clinic death-reset notice only when an actual death streak is cleared',async()=>{
 run(`stage='mercy';mercyLocation='wayne';player.hp=50;player.bolts=100;player.deathStreak=0`);await command('treat wounds');assert(!text().includes('DEATH PENALTY RESET'));assert.equal(run('player.hp'),100);
 node('#screen').innerHTML='';run(`player.hp=90;player.deathStreak=2`);await command('treat wounds');assert(text().includes('DEATH PENALTY RESET'));assert.equal(run('player.deathStreak'),0);
 node('#screen').innerHTML='';run(`player.hp=50;player.bolts=1;player.deathStreak=2`);await command('treat wounds');assert(!text().includes('DEATH PENALTY RESET'));assert.equal(run('player.deathStreak'),2);
});
await test('R2 quick controls refresh immediately after Seaport combat victory',async()=>{
 run(`stage='seaport';startCombat({name:'QA ENFORCER',level:1,hp:1,min:1,max:1,xp:0,bolts:0},'seaportLiberation')`);await drain();
 assert(node('#utility-panel button:nth-of-type(2)').textContent.includes('USE ITEM'));
 await command('1');assert.equal(run('stage'),'seaport');assert.equal(node('#utility-panel button:nth-of-type(2)').textContent,'(I) INVENTORY');assert.equal(node('#utility-panel button:nth-of-type(2)').dataset.command,'inventory');
});

await test('R3 Manage Pets numeric equip, switch, unequip, reload and overlay exits',async()=>{
 run(`stage='seaport';port55State().freed=true;player.flags.ownedPets=['Scrap Rat','Ferret'];`);
 await command('i');await command('manage pets');await command('1');assert.equal(run('player.flags.equippedPet'),'Scrap Rat');
 await command('2');assert.equal(run('player.flags.equippedPet'),'Ferret');await command('3');assert.equal(run('player.flags.equippedPet'),null);
 await command('2');run('saveGame(1);loadGame(1)');await drain();assert.equal(run('player.flags.equippedPet'),'Ferret');
 await command('i');await command('manage pets');await command('i');await command('b');assert.equal(run('stage'),'seaport');
 await command('i');await command('manage pets');await command('4');assert.equal(run('stage'),'inventory');await command('b');assert.equal(run('stage'),'seaport');
 await command('i');await command('manage pets');await command('b');await command('b');assert.equal(run('stage'),'seaport');
});
await test('R3 return travel costs five turns, exhausted exit stays in town, repeat journey starts at Factory',async()=>{
 run(`stage='seaport';factoryState().done=[0,1,2,3];player.flags.portRoadCleared=true;portState().position=5;player.turns=0;testMode=false;`);
 await command('return west');assert.equal(run('stage'),'seaport');assert.equal(run('portState().position'),5);
 run('player.turns=20');const before=run('player.turns');for(let i=0;i<5;i++)await command('return west');assert.equal(run('stage'),'factoryWorkshop');assert.equal(run('player.turns'),before-5);
 run('player.flags.portChargePrepared=true;portState().position=5');await command('road to seaport');assert.equal(run('portState().position'),0);
 run('portState().cleared={2:true,4:true}');const turns=run('player.turns');for(let i=0;i<5;i++)await command('continue east');assert.equal(run('stage'),'seaport');assert.equal(run('player.turns'),turns-5);
});

// Full progression uses the real command parser, room costs and combat; HP restoration
// below is explicit automated test setup, never a claim of natural/browser gameplay.
await test('Fresh new game via Old House and Solace → Factory fights → Forge → charge → road → liberation → saved chapter completion',async()=>{
 run(`stage='title';titleScreen()`);await drain();await command('new game');await command('yes');await command('stand up');await command('RepairFresh');await command('yes');await command('check cabinet');await command('search room');await command('inspect computer');await command('hello');await command('listen');await command('log coordinates');
 assert.equal(run('player.level'),1);assert(!run('player.flags.factoryFinalComponent'));await command('testing');await command('lantern127');assert(run('testMode'));
 async function roadUntil(target){let steps=0;while(run('stage')!==target&&steps++<70){const st=run('stage');let action;
 if(st==='roadReady')action='road';else if(st==='turnComplete'||st==='questRoadComplete')action='continue';else if(st==='wandererRoad')action='move on';else if(st==='fork')action='continue to solace';else if(st==='settlement')action=text().includes('GUARD > State your business.')?'abandoned terminal sent me':'approach gate';else if(st==='encounter'){const opts=run('Object.values(numberedChoices)');action=['move on','back away','walk around','head for lights','keep moving','continue'].find(x=>opts.includes(x))||opts[opts.length-1];}else throw Error('Unexpected road state '+st);await command(action);}
 assert.equal(run('stage'),target);}
 await roadUntil('mercy');await command('east gate');await command('head east');await roadUntil('eastEnd');await command('enter factory');await command('tomorrow project terminal');await command('exit terminal');
 await command('enter inner factory');
 for(let f=0;f<4;f++){
  await command(String(f+1));await command(f===3?'4':'6');await command('fight');
  let rounds=0;while(run('stage')==='combat'&&rounds++<80){run('player.hp=player.maxHp');await command('attack')}
  assert.equal(run('factoryDone()'),f+1);await command('return to floor');await command('0');
 }
 assert(run('player.flags.factoryFinalComponent'));await command('5');await command('talk to forge');assert(run('player.flags.portChargePrepared'));await command('back');await command('road to seaport');assert.equal(run('stage'),'portObstruction');await command('use dynamite');assert(run('player.flags.portRoadCleared'));assert(!run("hasItem('Prepared Dynamite Charge')"));
 for(let n=0;n<5;n++){await command('continue east');let rounds=0;while(run('stage')==='combat'&&rounds++<80){run('player.hp=player.maxHp');await command('attack')}}
 assert.equal(run('stage'),'seaport');await command('investigate fishermen');await command('confront fishermen');let rounds=0;while(run('stage')==='combat'&&rounds++<80){run('player.hp=player.maxHp');await command('attack')}
 assert.equal(run('port55State().stage'),'free');await command('harbor docks');await command('free residents');assert(run('port55State().freed'));await command('the rusty anchor');await command('talk');await command('return to harbor');
 const stop=run('port55PatrolName().toLowerCase()');await command(stop==='docks'?'docks':stop);await command('talk kaiden');await command('talk');assert(run('player.flags.chapterOneComplete'));
 const journey=lines().join('\n');run('saveGame(1)');run('player.flags.chapterOneComplete=false;player.flags.portRoadCleared=false');run('loadGame(1)');await drain();assert(run('player.flags.chapterOneComplete'));assert(run('player.flags.portRoadCleared'));assert.equal(run('factoryDone()'),4);assert(run('port55State().freed'));
 fs.writeFileSync(path.join(__dirname,'v555-r2-progression-transcript.txt'),journey+'\n\nAFTER SAVE/LOAD:\n'+lines().join('\n'));fs.writeFileSync(path.join(__dirname,'v555-r2-final-state.json'),run('JSON.stringify({stage,level:player.level,hp:player.hp,turns:player.turns,bosses:factoryDone(),chargePrepared:player.flags.portChargePrepared,roadCleared:player.flags.portRoadCleared,seaport:port55State(),chapterComplete:player.flags.chapterOneComplete})'));});
fs.writeFileSync(path.join(__dirname,'v555-r2-results.json'),JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2));process.exitCode=results.some(x=>!x.pass)?1:0;
})();
