const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const dir=path.join(__dirname,'..'),el=()=>({addEventListener(){},classList:{add(){},remove(){},toggle(){}},childNodes:[{}],append(){},appendChild(){},querySelectorAll(){return []},style:{},dataset:{},focus(){}}),store=new Map();
const c=vm.createContext({console,document:{querySelector:el,createElement:el,createTextNode:el,body:el()},window:{ROUTE127_QA_BUILD:true},localStorage:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v)},setInterval:()=>1,clearInterval(){},setTimeout,clearTimeout,Date,Math});
for(const file of ['app.js','casino.js','polish.js','expansion.js','crime.js','consolidation.js','factory.js','seaport.js','wanderer_fix.js','v55.js']){let s=fs.readFileSync(path.join(dir,file),'utf8');if(file==='app.js')s=s.replace(/startRefillTimer\(\);\s*titleScreen\(\);\s*$/,'');vm.runInContext(s,c)}
const run=s=>vm.runInContext(s,c);let checks=0;const eq=(a,b)=>{assert.strictEqual(a,b);checks++};const ok=v=>{assert.ok(v);checks++};
function rarityAt(roll){run(`Math.random=(()=>{const a=[${roll/100},0];let i=0;return ()=>a[i++]??0})()`);return run("GEAR[v555RollEquipmentDrop()].rarity")}
eq(rarityAt(0),'common');eq(rarityAt(54.999),'common');eq(rarityAt(55),'uncommon');eq(rarityAt(84.999),'uncommon');eq(rarityAt(85),'rare');eq(rarityAt(97.999),'rare');eq(rarityAt(98),'epic');eq(rarityAt(99.999),'epic');
run("stage='road';player.pack=[];player.packMax=0;player.flags={};Math.random=(()=>{const a=[0,0];let i=0;return ()=>a[i++]??0})();v555AwardEquipmentDrop()");eq(run('(player.flags.pendingEquipmentDrops||[]).length'),1);const pending=run('player.flags.pendingEquipmentDrops[0]');ok(!!pending);run("player.packMax=10;v555ClaimEquipmentDrop()");eq(run('(player.flags.pendingEquipmentDrops||[]).length'),0);ok(run(`player.pack.some(i=>i.name===${JSON.stringify(pending)})`));
// Save/load integration: held rewards survive a real slot round-trip and can be claimed once.
run("player.pack=[];player.packMax=0;player.flags={};activeSaveSlot=0;stage='road';Math.random=()=>0;v555AwardEquipmentDrop();saveGame(2)");
const savedPending=run('player.flags.pendingEquipmentDrops[0]');ok(!!savedPending);
run("player.flags.pendingEquipmentDrops=[];loadGame(2)");
eq(run('player.flags.pendingEquipmentDrops[0]'),savedPending);
run("player.packMax=10;v555ClaimEquipmentDrop()");
eq(run('(player.flags.pendingEquipmentDrops||[]).length'),0);
ok(run(`player.pack.some(i=>i.name===${JSON.stringify(savedPending)})`));
eq(run('v555ClaimEquipmentDrop()'),false);
console.log(`v55.5 random equipment runtime: ${checks}/${checks} assertions passed`);
