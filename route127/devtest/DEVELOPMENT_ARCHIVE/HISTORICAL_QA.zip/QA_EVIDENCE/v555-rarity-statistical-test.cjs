const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const dir=path.join(__dirname,'..');
const el=()=>({addEventListener(){},classList:{add(){},remove(){},toggle(){}},childNodes:[{}],append(){},appendChild(){},querySelectorAll(){return []},style:{},dataset:{},focus(){}});
const c=vm.createContext({console,document:{querySelector:el,createElement:el,createTextNode:el,body:el()},window:{ROUTE127_QA_BUILD:true},localStorage:{getItem(){return null},setItem(){}},setInterval:()=>1,clearInterval(){},setTimeout,clearTimeout,Date,Math:Object.create(Math)});
for(const file of ['app.js','casino.js','polish.js','expansion.js','crime.js','consolidation.js','factory.js','seaport.js','wanderer_fix.js','v55.js']){let s=fs.readFileSync(path.join(dir,file),'utf8');if(file==='app.js')s=s.replace(/startRefillTimer\(\);\s*titleScreen\(\);\s*$/,'');vm.runInContext(s,c)}
let seed=123456789; c.Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296};
const counts={common:0,uncommon:0,rare:0,epic:0};const n=100000;
for(let i=0;i<n;i++){const rarity=vm.runInContext('GEAR[v555RollEquipmentDrop()].rarity',c);assert.ok(rarity in counts,`unexpected rarity ${rarity}`);counts[rarity]++}
for(const [rarity,target] of Object.entries({common:.55,uncommon:.30,rare:.13,epic:.02})){const actual=counts[rarity]/n;assert.ok(Math.abs(actual-target)<.01,`${rarity} ${(actual*100).toFixed(2)}% outside ±1 percentage point of ${target*100}%`)}
console.log(`v55.5 rarity statistical sampling: 4/4 distribution checks passed over ${n} drops; ${JSON.stringify(counts)}`);
