const fs=require('fs'),assert=require('assert'),path=require('path');
const s=fs.readFileSync(path.join(__dirname,'..','casino.js'),'utf8');
assert(s.includes("(r.game==='rats'&&!player.flags.port55Casino)"),'Saved rat round must be gated outside Seaport');
assert(s.includes("game==='rats'&&!player.flags.port55Casino"),'Rat racing selection must be gated');
assert(s.includes("player.level<5&&!['dice','rps','blackjack'].includes(r.game)"),'Early-level game gating retained');
console.log('PASS 3 rat racing saved-round gating assertions');
