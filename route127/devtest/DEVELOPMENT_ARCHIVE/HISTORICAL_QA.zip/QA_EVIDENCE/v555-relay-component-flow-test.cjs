const fs=require('fs'),assert=require('assert'),path=require('path');
const app=fs.readFileSync(path.join(__dirname,'..','app.js'),'utf8');
const checks=[]; function check(name,fn){fn();checks.push(name)}
check('durable four-part state initialized',()=>assert(app.includes('relayParts:{johnny:false,yard:false,branch:false,east:false}')));
check('legacy saves receive missing component keys',()=>assert(app.includes('function ensureRelayParts(){ if(!player.flags.relayParts||typeof player.flags.relayParts!=="object") player.flags.relayParts={johnny:false,yard:false,branch:false,east:false}; return player.flags.relayParts; }')));
check('component award prevents duplicate acquisition',()=>assert(app.includes('if(rp[key]){add("You\'ve already recovered what the Relay needs from here.","system");return false;}')));
check('component count reported out of four',()=>assert(app.includes('PARTS RECOVERED — ${relayPartCount()}/4')));
check('inventory displays components outside pack slots',()=>assert(app.includes('RELAY COMPONENTS — QUEST STORAGE (NO PACK SLOTS)')));
check('all four component labels shown in inventory',()=>{for(const x of ['Power Regulator','Antenna Servo','Shielded Feed Coupler','Signal-Conditioning Module'])assert(app.includes(x),x)});
check('Johnny acquisition path guarded by Relay discovery',()=>assert(app.includes('mercyLocation==="johnny" && player.flags.relayPartsRevealed && (cmd.includes("relay")||cmd.includes("regulator"))')));
check('yard acquisition requires defeated Yardman and discovery',()=>assert(app.includes('serviceRoadDepth===3 && player.flags.serviceBossDead') && app.includes('!ensureRelayParts().yard')));
check('Lower Access Road part requires revealed quest',()=>assert(app.includes('if(player.flags.relayPartsRevealed)awardRelayPart("branch","SHIELDED FEED COUPLER")')));
check('east equipment rack awards only after discovery',()=>assert(app.includes('awardRelayPart("east","SIGNAL-CONDITIONING MODULE")') && app.includes('SIGNAL-CONDITIONING MODULE')));
check('install command refuses fewer than four parts',()=>assert(app.includes('if(relayPartCount()<4){add(`RELAY REPAIR INCOMPLETE — ${relayPartCount()}/4 COMPONENTS RECOVERED`')));
check('install option appears only with all parts',()=>assert(app.includes('relayPartCount()===4 && player.flags.relayQuest!=="complete"?"   INSTALL COMPONENTS":""')));
console.log(`v55.5 Relay component flow: ${checks.length}/${checks.length} assertions passed`);
