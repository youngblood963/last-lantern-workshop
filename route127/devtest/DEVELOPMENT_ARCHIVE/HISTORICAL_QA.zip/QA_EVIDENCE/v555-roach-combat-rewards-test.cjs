const fs=require('fs');const assert=require('assert');
const src=fs.readFileSync(require('path').join(__dirname,'..','app.js'),'utf8');
const spec=src.match(/"ROACH NEST":\{name:"ROACH SWARM",level:1,hp:14,min:1,max:4,xp:(\d+),bolts:(\d+),end:/);
assert(spec,'Roach combat spec exists');
assert.strictEqual(Number(spec[1]),25,'combat awards 25 XP');
assert.strictEqual(Number(spec[2]),8,'combat awards 8 Bolts');
assert(src.includes('gainXp(20);gainBolts(7);addPack("Scrap Metal")'),'riskier van branch remains intact');
assert(src.includes('else if(cmd.includes("back")){add("You decide the van belongs to the roaches.");}'),'retreat grants no XP');
console.log('Roach reward regression: 4 assertions passed');
