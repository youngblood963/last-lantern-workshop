const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync(require('path').join(__dirname,'..','app.js'),'utf8');
const start=src.indexOf('  if(mercyLocation==="jenRoomChest"){');
const end=src.indexOf('  if(mercyLocation==="jenRoom"){',start);
assert(start>0&&end>start,'chest handler exists');
const handler=src.slice(start,end);
function run(command,state){const output=[];const context={cmd:command,mercyLocation:'jenRoomChest',player:state,add:(...a)=>output.push(a[0]),packSlotsUsed:()=>state.pack.filter(i=>!['key','quest'].includes(i.type)).length,updateHud:()=>{}};vm.runInNewContext("(function(){"+handler+"})()",context);return {output,location:context.mercyLocation};}
const p={flags:{rustyRoomOwned:true},name:'Tester',weapon:'Tire Iron',armor:'Cloth Vest',packMax:10,pack:[{name:'Scrap',type:'material',qty:8},{name:'Tire Iron',type:'weapon',qty:1},{name:'Quest Token',type:'quest',qty:1}],rustyRoomChest:[]};
run('deposit scrap x5',p);assert.equal(p.pack[0].qty,3);assert.equal(p.rustyRoomChest[0].qty,5);
run('withdraw scrap x2',p);assert.equal(p.pack[0].qty,5);assert.equal(p.rustyRoomChest[0].qty,3);
run('deposit tire iron',p);assert.equal(p.rustyRoomChest.length,1,'equipped gear protected');
run('deposit quest token',p);assert.equal(p.rustyRoomChest.length,1,'quest protected');
run('withdraw scrap x999',p);assert.equal(p.rustyRoomChest[0].qty,3,'overwithdraw protected');
run('deposit scrap x0',p);assert.equal(p.pack[0].qty,5,'zero quantity rejected');
run('deposit scrap x999999999999999999999999',p);assert.equal(p.pack[0].qty,5,'overflow quantity rejected');
run('deposit scrap x5',p);assert.equal(p.rustyRoomChest[0].qty,8);assert(!p.pack.some(i=>i.name==='Scrap'));
run('withdraw scrap x8',p);assert.equal(p.rustyRoomChest.length,0);assert.equal(p.pack.find(i=>i.name==='Scrap').qty,8);
const r=run('back',p);assert.equal(r.location,'jenRoom');assert(r.output.some(x=>x.includes("Tester'S ROOM")));
console.log('PASS 10 room-chest transfer, protection, quantity and navigation assertions');
