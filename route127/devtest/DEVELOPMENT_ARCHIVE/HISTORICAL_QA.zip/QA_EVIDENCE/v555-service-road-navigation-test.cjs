const fs=require('fs'),path=require('path'),assert=require('assert');
const s=fs.readFileSync(path.join(__dirname,'..','app.js'),'utf8');
const cost=s.match(/function branchReturnCost\(depth=serviceRoadDepth\)\s*\{([^}]+)\}/)?.[1]||'';
const service=s.match(/function serviceRoadChoices\(\)\s*\{([\s\S]*?)\n\}/)?.[1]||'';
const lower=s.match(/function branchLandmarkChoices\(\)\s*\{([\s\S]*?)\n\}/)?.[1]||'';
const route=s.slice(s.indexOf('if(stage==="relayBranch")'),s.indexOf('if(stage==="combat")'));
const checks=[
 ['Fast-return cost scales with branch depth',cost.includes('Math.floor(Number(depth)||1)')&&cost.includes('Math.max(1,')],
 ['Service Road offers Walk Back once',((service.match(/WALK BACK/g)||[]).length===1)],
 ['Lower Access Road offers Walk Back once',((lower.match(/WALK BACK/g)||[]).length===1)],
 ['Fast return is offered only beyond depth one',service.includes('if(d>1)parts.push')&&lower.includes('if(d>1)parts.push')],
 ['Service Road fast return checks available turns before spending',s.includes('if(cmd==="f"||cmd.includes("fast return")){const cost=branchReturnCost();if(!testMode&&player.turns<cost)')],
 ['Lower Access fast return checks available turns before spending',s.includes('if(cmd==="f"||cmd.includes("fast return")){const cost=branchReturnCost();if(!testMode&&player.turns<cost)')],
 ['Walk Back spends one turn and decrements depth',s.includes('spendTurn();player.flags.branchReturning=true;serviceRoadDepth=Math.max(0,serviceRoadDepth-1)')],
 ['Returning from branch to fork does not charge a second intersection turn',s.includes('You climb back to the Route 127 fork.')&&!s.includes('spendTurn();spendTurn();')],
 ['Lower Access continuation stops at depth three',s.includes('if(serviceRoadDepth>=3)')],
 ['Fork exposes reverse-direction choice',s.includes('(R) REVERSE DIRECTION')]
];
for(const [label,ok] of checks){assert.ok(ok,label);console.log('PASS',label)}
console.log(`${checks.length}/${checks.length} assertions passed`);
