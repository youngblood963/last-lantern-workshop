const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const src=fs.readFileSync(path.join(__dirname,'..','app.js'),'utf8');
const start=src.indexOf('function branchReturnCost('),end=src.indexOf('function branchLandmark(kind,cmd)',start);
assert(start>=0&&end>start,'live navigation functions available');
const ctx={serviceRoadDepth:1,player:{flags:{}},ensureRelayParts:()=>({yard:false})};
vm.createContext(ctx);vm.runInContext(src.slice(start,end)+'\nthis.cost=branchReturnCost;this.service=serviceRoadChoices;this.lower=branchLandmarkChoices;',ctx);
let n=0;function check(cond,msg){assert.ok(cond,msg);n++;}
for(let depth=1;depth<=3;depth++){
 ctx.serviceRoadDepth=depth;
 check(ctx.cost()===depth,`depth ${depth} return cost`);
 for(const [label,menu] of [['service',ctx.service()],['lower',ctx.lower()]]){
  check((menu.match(/WALK BACK/g)||[]).length===1,`${label} walk back unique at ${depth}`);
  check((menu.includes('FAST RETURN TO FORK'))===(depth>1),`${label} fast return gate at ${depth}`);
  if(depth>1)check(menu.includes(`FAST RETURN TO FORK — ${depth} TURNS`),`${label} fast return cost at ${depth}`);
 }
}
ctx.serviceRoadDepth=1;ctx.player.flags.v39_service_1_inspect=true;ctx.player.flags.v39_service_1_search=true;
check(!ctx.service().includes('INSPECT TRUCK')&&!ctx.service().includes('SEARCH ROADSIDE'),'consumed service landmarks hidden');
ctx.player.flags.v39_lower_1_inspect=true;ctx.player.flags.v39_lower_1_search=true;
check(!ctx.lower().includes('INSPECT DRAINAGE WALL')&&!ctx.lower().includes('SEARCH TOOL CRATE'),'consumed lower landmarks hidden');
ctx.serviceRoadDepth=3;ctx.player.flags.serviceBossDead=true;ctx.player.flags.relayPartsRevealed=true;
check(ctx.service().includes('SEARCH MAINTENANCE YARD'),'yard available after boss');
ctx.player.flags.maintenanceYardSearched=true;ctx.ensureRelayParts=()=>({yard:true});
check(!ctx.service().includes('SEARCH MAINTENANCE YARD'),'yard hidden after completion');
console.log(`PASS service road live runtime: ${n} assertions`);
