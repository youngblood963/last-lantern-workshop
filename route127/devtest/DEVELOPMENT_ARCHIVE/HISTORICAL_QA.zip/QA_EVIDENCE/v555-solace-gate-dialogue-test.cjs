const fs=require('fs'),assert=require('assert');
const src=fs.readFileSync(require('path').join(__dirname,'..','app.js'),'utf8');
const checks=[
  ['gate offers terminal explanation',src.includes('ABANDONED TERMINAL SENT ME')],
  ['gate offers trade',src.includes('LOOKING TO TRADE')],
  ['gate offers Relay Station',src.includes('LOOKING FOR THE RELAY STATION')],
  ['gate offers passing through',src.includes('JUST PASSING THROUGH')],
  ['gate offers fight',src.includes('PICK A FIGHT')],
  ['fight starts guard combat with turn cost',src.includes('},"gateGuards",true,false)')],
  ['Jen rescue is one-time',src.includes('!player.flags.jenGateRescueUsed')&&src.includes('player.flags.jenGateRescueUsed=true')],
  ['gate rescue uses normal death penalties',src.includes('const penalty=travel+2;')&&src.includes('RESCUE TRAVEL: ${travel} TURNS')],
  ['backing off restores the gate challenge',src.includes('if(c.source==="gateGuards"){stage="settlement";player.flags.solaceGateChallenge=true')],
  ['guard victory enters Solace without road-turn completion',src.includes('else if(source==="gateGuards"){player.flags.solaceGateChallenge=false;player.flags.mercyDiscovered=true')],
];
for(const [name,ok] of checks){assert.ok(ok,name);console.log('PASS',name)}
console.log(`${checks.length}/${checks.length} Solace Gate source assertions passed`);
