const fs=require('fs');const assert=require('assert');
const s=fs.readFileSync(require('path').join(__dirname,'..','app.js'),'utf8');
const checks=[
 ['Tim offers the contract',s.includes('ACCEPT TERRIBLE BILLY CONTRACT')],
 ['Contract acceptance is one-time',s.includes('player.flags.terribleBillyBounty="active"')],
 ['Hunt requires an active contract',s.includes('player.flags.terribleBillyBounty!=="active"')],
 ['Hunt starts named combat',s.includes('name:"TERRIBLE BILLY",level:5,hp:42,min:7,max:12,xp:70,bolts:35')],
 ['Victory creates proof',s.includes('player.flags.terribleBillyBounty="proof"')],
 ['Quest journal tracks active bounty',s.includes('BOUNTY — TERRIBLE BILLY [')],
 ['Quest journal tracks completed bounty',s.includes('BOUNTY — TERRIBLE BILLY — COMPLETE')],
 ['Collection is idempotent by proof state',s.includes('else if(player.flags.terribleBillyBounty==="proof"){player.flags.terribleBillyBounty="done"')],
 ['Completion grants approved reward',s.includes('gainXp(140);gainBolts(100)')],
 ['Save-compatible character flags are used',s.includes('player.flags.terribleBillyBounty')]
];
for(const [name,ok] of checks){assert.ok(ok,name);console.log('PASS',name)}
console.log(`${checks.length}/${checks.length} assertions passed`);
