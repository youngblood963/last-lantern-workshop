const fs = require('fs');
const src = fs.readFileSync(require('path').join(__dirname, '..', 'app.js'), 'utf8');
const checks = [
  ['Tim work dialogue presents the Old House bounty', /TROUBLE AT THE OLD HOUSE/.test(src)],
  ['Contract can be accepted at Tim', /accept trouble at the old house/.test(src)],
  ['Acceptance creates active per-character state', /timHouseBounty="active"/.test(src)],
  ['House squatter victory converts active contract to proof', /if\(player\.flags\.timHouseBounty==="active"\)player\.flags\.timHouseBounty="proof"/.test(src)],
  ['Victory presents proof hand-in instruction', /BOUNTY PROOF ACQUIRED/.test(src)],
  ['Collect Bounty requires proof state', /player\.flags\.timHouseBounty==="proof"/.test(src)],
  ['Payout marks contract done before awarding', /player\.flags\.timHouseBounty="done";gainXp\(100\);gainBolts\(75\)/.test(src)],
  ['Quest log lists active bounty', /BOUNTY — TROUBLE AT THE OLD HOUSE/.test(src)],
  ['Quest log lists completed bounty reward', /Returned proof to Tim\. Reward: 100 XP/.test(src)],
  ['Existing house quest state remains used', /player\.flags\.houseQuest="cleared"/.test(src)],
];
let failed=0; for (const [name, ok] of checks) { console.log(`${ok?'PASS':'FAIL'} ${name}`); if(!ok) failed++; }
console.log(`${checks.length-failed}/${checks.length} passed`); process.exitCode=failed?1:0;
