const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(require('path').join(__dirname,'../expansion.js'),'utf8');
const fn=source.match(/function v50WeightedWanderer\(pool\)\{[\s\S]*?\n\}/);
assert(fn,'weighted wanderer function found');
const context=vm.createContext({player:{level:1},Math});vm.runInContext(fn[0],context);
const pool=Array.from({length:10},(_,i)=>({name:'W'+(i+1),level:i+1}));
assert.strictEqual(vm.runInContext('v50WeightedWanderer([])',context),null);
for(let level of [1,5,10]){
 context.player.level=level;const counts=Array(10).fill(0);
 for(let i=0;i<30000;i++)counts[context.v50WeightedWanderer(pool).level-1]++;
 assert(counts[level-1]>counts[level===1?9:0],`level ${level} should favor its own band`);
 console.log('Level',level,'encounter distribution',counts.join(','));
}
console.log('PASS: wanderer level-aware selection, empty pool and preserved identifiers');
