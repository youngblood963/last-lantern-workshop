const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(require('path').join(__dirname,'..','app.js'),'utf8');
const start=source.indexOf('function handleCombat(cmd){');
const end=source.indexOf('\nfunction ',start+10);
assert(start>=0&&end>start);
const code=source.slice(start,end);
function fight(randoms,initialHp=100){
  const messages=[];const player={weapon:"Pipe",hp:initialHp,maxHp:initialHp,flags:{},turns:50};
  const rand=[...randoms];const customMath=Object.create(Math);customMath.random=()=>rand.length?rand.shift():0.5;
  const ctx={Math:customMath,combatState:{name:'THE YARDMAN',hp:55,maxHp:55,min:7,max:12,xp:65,bolts:28,source:'serviceBoss'},player,stage:'combat',add:x=>messages.push(String(x)),rollDamage:()=>1,isDark:()=>false,armorDefense:()=>0,updateHud:()=>{},gainXp:()=>{},gainBolts:()=>{},flushResults:()=>{},completeRoadTurn:()=>{},resultBuffer:[],petCombatRound:()=>{},handlePlayerDeath:()=>{ctx.died=true}};
  vm.createContext(ctx);vm.runInContext(code+'\nthis.attack=handleCombat;',ctx);ctx.attack('attack');return {player,messages,ctx};
}
// Miss roll first, no retaliation.
let miss=fight([0.01]);assert.equal(miss.player.hp,100);assert(miss.messages.some(x=>x.includes('swings wide')));
// Miss check fails, heavy check succeeds, damage roll picks minimum 13.
let heavy=fight([0.9,0.01,0]);assert.equal(heavy.player.hp,87);assert(heavy.messages.some(x=>x.includes('overhead swing')));
// Standard roll, 7 minimum.
let standard=fight([0.9,0.9,0]);assert.equal(standard.player.hp,93);assert(!standard.messages.some(x=>x.includes('overhead swing')));
// Damage cannot exceed remaining HP and death fires once.
let death=fight([0.9,0.01,0],5);assert.equal(death.player.hp,0);assert.equal(death.ctx.died,true);assert(death.messages.some(x=>x.includes('YOU TAKE 5')));
console.log('Yardman runtime: 9 assertions passed');
