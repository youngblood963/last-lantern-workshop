const fs=require('fs'),assert=require('assert');
const src=fs.readFileSync(require('path').join(__dirname,'..','app.js'),'utf8');
assert(src.includes('c.source==="serviceBoss" && Math.random()<0.15'),'Yardman miss chance');
assert(src.includes('c.source==="serviceBoss" && Math.random()<0.20'),'Yardman heavy swing chance');
assert(src.includes('13+Math.floor(Math.random()*4)'),'Heavy swing must deal 13-16 raw damage');
assert(src.includes('hp:55,min:7,max:12,xp:65,bolts:28'),'Boss base stats unchanged');
assert(src.includes('if(heavySwing)add('),'Heavy attack should be telegraphed');
console.log('5/5 Yardman structural assertions passed');
