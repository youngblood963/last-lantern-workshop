# FORGE — ROUTE 127 BANKING, IDENTITY & CLOUDFLARE WORK ORDER

**Prepared:** October 20, 2026  
**Type:** Focused follow-up to R6 (do not replace or interrupt R6).  
**Owner:** Forge — implementation, testing and packaging. Luna — narrative/system design and QA. Syn — game direction.

## EXECUTION AUTHORIZATION
Complete the scoped tasks **autonomously**, in order, without pausing for approval after individual fixes. Inspect the real code and existing backend before editing. Fix routine issues and write tests. Ask only if credentials/access are genuinely unavailable, if a destructive schema migration is needed, or if preserving existing saved characters is impossible with the proposed approach. **Do not report features as working until demonstrated by tests.** Avoid creating a pile of separate QA/notes files: update `CHANGELOG.md`, `QA_HISTORY.md`, and `DEVELOPMENT_NOTES.md`.

## 0 — RECOVER AND AUDIT EXISTING BACKEND (FIRST)
We previously worked on Cloudflare infrastructure: production-oriented Worker `route127-api`, D1 `route127-world`, dev Worker `route127-dev-api`, D1 `route127-dev`, and an experimental **Shared World Probe** deployed via Last Lantern Workshop. A test character was retrievable in prototype testing, but **automatic live-game character synchronization was not established**. Names of assets and old test results are historical context, not proof they still exist or are accessible.

- Find the existing Cloudflare Worker source, D1 schema/migrations, Shared World Probe, any dev-game integration adapter, and associated repo/deployment references. Inspect current R6 (once available), not just old R5.
- Produce a concise inventory: what exists, what's deployed, what is reachable, what is authenticated, what's only prototype, and what is missing. Clearly separate **verified** from **historical/unverified**.
- **Do not create a second backend or new production database by default.** Reuse the existing architecture where suitable.
- Perform integration in development/staging first. No production writes, public endpoint launches, credential rotation, destructive migration, or cutover without an explicit safe plan and needed approval. Never put secrets in browser JavaScript or ZIPs.
- Preserve existing local saves. Plan and test migration/association with permanent player ID; avoid silently converting a test character into a real account. If backend integration cannot be safely completed due to missing access, finish local-compatible portions, document the exact blocker and next step; do not claim cloud saving works.

## 1 — REMOVE UNWANTED BANKING FEES
- Remove current withdrawal-fee charges and fee-discount calculations from Amii and recruited Seaport bankers. **Deposits and withdrawals are always free.**
- Shared bank funds must remain consistent between Solace and Seaport. Preserve balances, saves and existing banking menus.
- Audit for hidden fees and fee-related text in all menus.

## 2 — DAILY BANK INTEREST
**Approved rates** (one active rate for the shared account, not stacked):

| Banker | Daily rate |
|---|---:|
| Amii / no recruited Seaport banker | 1.0% |
| Seaport aptitude 1/5 | 1.0% |
| Seaport aptitude 2/5 | 1.5% |
| Seaport aptitude 3/5 | 2.0% |
| Seaport aptitude 4/5 | 2.5% |
| Seaport aptitude 5/5 | 3.0% |

- Only **up to 5,000 deposited Bolts** earn interest. Maximum daily interest at 3% = **150 Bolts**.
- Interest is paid **at most once per real-world day per player/shared account**, regardless of which bank is visited, refreshes, reloads, devices or save-slot changes. No travel turns consumed.
- Interest is **non-compounding by design**: earned interest must not automatically increase the interest-bearing principal. Keep a clearly defined eligible principal basis (e.g. principal/interest ledger) and honor ordinary deposits and withdrawals. Implement unambiguous behavior if player withdraws interest or reduces principal; document it and test it. Avoid double-counting.
- Deposit cutoffs: funds deposited shortly before the daily payment are **not instantly eligible** for an entire day's reward. Use a consistent real-time accrual window or eligible-at-period-start snapshot. Banker aptitude changes apply from the next earning period, not retroactively.
- Make the bank UI show applicable rate, interest-eligible principal, last payment and next eligibility/payment, using consistent rules in both banks. Display Bolt amounts rounded to whole Bolts with a deterministic policy.
- For server-authoritative mode use **trusted server time**, atomic/idempotent crediting and durable ledgers in D1 to prevent local-clock edits, concurrent requests and duplicate claims. **Do not claim anti-cheat protection for local-only browser state.** Until secure backend integration is complete, clearly flag prototype interest as local-only and avoid launching exploitable global balances.
- Test minimum/zero, 4,999/5,000/5,001 deposits, 1–5 aptitude rates, no-hire baseline, account changes, >1 day gaps, midnight/time zones, relaunch, rollback, multiple tabs/devices and reconnection.

## 3 — UNDERGROUND CHARACTER NAME CHANGE (BOTH BANKS)
**Cost: 500 Bolts, one-time per successful change**. Offered by Amii and a staffed Seaport bank (only after liberation and recruitment rules permit bank service). Preserve existing bank systems.

Suggested Amii line: *“Sure, I can change your name. But it's not strictly legal. Five hundred Bolts. Cash. No questions. And a new name won't erase what you've done.”* Give Seaport's banker distinct but similarly shady dialogue.

- Present current name, cost, proposed new name and explicit confirm/cancel. Validate length, safe character set, blank inputs, reserved/offensive/system names where appropriate. No fee on cancellation, invalid name, or failed write. Deduct exactly 500 on confirmed successful commit.
- Create or reuse a **stable, opaque, permanent character ID** that does not change when display name changes. Preserve quest progress, saved items, pet/skills, level, bank, bounties, lifetime notoriety, ownership and future PvP associations. Do not use name as a primary key for identity-sensitive game mechanics.
- For online/global identities, name uniqueness and ownership must be enforced by the **backend** (atomic check/update); local-browser checking is not a security guarantee. Do not imply existing multiplayer/PvP is live.
- Migration: existing character slots keep their established characters. Handle pre-ID saves and duplicate test names deterministically without data loss; ensure future server IDs cannot be spoofed by editing browser saves. Do not merge distinct local characters.
- Test both banks, success, insufficient funds, cancelled/rejected names, same-name attempts, save/reload, source names on bulletin boards, persistence of crime record, and concurrency once server-connected.

## 4 — GAME / BACKEND INTEGRATION CHECKPOINT
**Do not turn this into an unbounded multiplayer project.** Minimum deliverable: demonstrate safe dev-only character registration/lookup by immutable ID from the *current* game and the Shared World Probe, or document exact missing access/technical blocker. If ready, add minimal authenticated dev synchronization for identity and status without exposing sensitive game-state writes to arbitrary clients. Cloud saves/global banking/PvP/one-of-a-kind ownership are **not automatically approved for public launch** by this work order.

- All remote modifications require explicit authentication, authorization and server-side validation.
- Prevent double-registration and avoid duplicate player identities on reload.
- Keep offline gameplay functioning, with a clear sync status and no destructive overwrite on reconnection.
- Do not promise global name uniqueness, real-world-clock-resistant interest, global Legendary uniqueness or PvP identity integrity until corresponding server authority is actually live and tested.

## 5 — QA, HANDOFF AND DELIVERY
- First establish R6 baseline and preserve the existing Luna ANSI artwork, credits, Seaport, recruitment, and other working features; do not regress Factory–Seaport road repairs or R6 menu changes.
- Run automated unit/integration tests plus explicit banking/name-change regression cases. Report tests actually run, pass/fail counts, and any untested areas. Perform a dev Worker/D1 end-to-end smoke test **only if access is legitimately available**.
- Deliver **Development and Player ZIPs**, plus a concise summary of backend status and any required manual Cloudflare setup or environment variables (names only, never secret values).
- Preserve DEV-only QA shortcuts and prevent Player build from exposing debugging or admin routes.
- Do not create extra prototypes or experimental game copies unless needed to test safely.

## OUT OF SCOPE FOR THIS TASK
Do not implement PvP, global Legendary ownership, Endless Factory, elaborate server economy, long-form crafting redesign, or unrelated new quests. Those belong in later work orders.

**Definition of done:** No banking fees; correct and clearly disclosed capped interest math; 500-Bolt name-change flow in both banks; immutable character identity; verified preservation of saves and criminal records; accurately reported Cloudflare integration status; tested and packaged builds. **If the backend integration remains unfinished, label it unfinished clearly.**
