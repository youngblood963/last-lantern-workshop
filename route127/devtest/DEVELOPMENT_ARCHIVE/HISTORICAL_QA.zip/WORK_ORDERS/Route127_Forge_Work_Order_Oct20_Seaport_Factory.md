# FORGE WORK ORDER — ROUTE 127 v55.5 R4
## Autonomous demo stabilization, Factory / Seaport overhaul & credits

**Authority:** Approved by project director Syn, October 20, 2026. **Baseline:** latest cleaned `Route127_v55_5_R4_Development_Cleaned` package. Inspect actual build and existing implementations before editing; do not use the historical v55.4 package as a replacement baseline. **Goal:** ship working **Development and Player ZIPs** for a complete Level 1–10 demo replay, with no regressions or lost save compatibility.

## AUTONOMOUS AUTHORIZATION — DO NOT STOP BETWEEN PHASES

**Complete every approved phase in sequence without stopping to ask permission after each task or phase.** Fix incidental routine bugs, make reasonable implementation decisions consistent with these requirements, and run targeted tests as you go. Ask Syn **only** if a change would materially contradict the approved design, irreversibly lose saved progress, or demand removal of an existing meaningful feature. If a prerequisite proves genuinely impossible, document precisely why, continue independent tasks, and report it in the final handoff; don't silently skip items. Do not claim a feature tested when only code was inspected. Keep the existing three consolidated docs (`CHANGELOG.md`, `QA_HISTORY.md`, `DEVELOPMENT_NOTES.md`) updated; do not create dozens of per-fix report files. No endless browser testing: use focused automated checks and a carefully scoped actual player-flow pass. Deliver **one Development ZIP, one Player ZIP, and one final summary/report** when finished.

**Priority:** (1) blocker repairs and state correctness; (2) Factory support/quest mechanics; (3) Seaport liberation and recruitment/menu state; (4) credits, visuals and polish. Verify each phase and then **continue automatically**.

## PHASE 1 — CRITICAL SYSTEMS AND EXISTING PLAYTEST DEFECTS

1. **Factory crafting blocker (observed):** Player finished Forge's crafting tutorial, has Scrap Metal in inventory, yet Workshop Kit recipe says `Scrap Metal 0/1`, `Cloth 0/2` and `See Forge for Workshop Kit`. Reproduce, inspect tutorial flags, recipe state, stack/count code and actual item IDs; fix recipe unlock and material detection (do not assume cause). Correctly consume materials, respect crafting timers, handle missing Cloth honestly, and survive save/reload.
2. **Installed Relay components stuck in pack (repeat observed):** Correct inventory/quest state when parts are installed. Installed parts must not rattle around as usable backpack clutter; preserve quest completion and migrate existing saves safely. Do not destroy parts required for unfinished quests. Check previous v55.4 issue concerning quest item pack counting.
3. **Full-pack loot:** When player receives an item and all ten slots are occupied, offer `1. Leave Behind` / `2. Replace an Item` instead of automatically abandoning loot. Display eligible pack contents and confirm discard/swap; protect equipped and quest items; show extra warning for Rare/Epic/Legendary. No accidental duplicates, reward farming, or inventory limit bypass. Test with Pack Mule's variable capacity from Phase 3.
4. **Wanderer selling:** Hollis the Cook refused selling a non-equipped Uncommon Yardman's Wrench for 12 Bolts with generic `Sale changed or funds insufficient`. Verify merchant cash, item eligibility, state and transaction; show a specific reason and merchant available Bolts. Retest a funded wanderer and established town traders. Don't treat a low-cash merchant as a code bug without evidence.
5. **Quest journal:** `Q` presents `1. Active Quests`, `2. Completed Quests`, `B. Back`; show current main objective first, active side quests, and browseable completed quests. Do not reveal undiscovered quests. Viewing is free; progress and completion survive save/load. Keep notifications short, not multi-screen walls of text.
6. **Historical QA recheck:** Reproduce **on R4** before re-fixing previously reported issues (global duplicate menus, dead/conflicting hotkeys, zero-turn QA access, shop navigation, road travel direction/counters, encounter reward errors, relevant NPC interactions). These 53 prior requests are in the attached consolidated notes. Historical reports are *not* proof issues remain. Preserve the confirmed repaired pet vendor loop. Authorized QA_MODE testing must remain isolated from Player build.

## PHASE 2 — FACTORY, STORY AND ROAD QUALITY

7. **Factory quartermaster — Rusty:** Add an always-reachable small supply/trading station near Factory entrance, accessible before/after Foreman. Reuse established vendor buy/sell flows. Buy bandages, energy bars/basic consumables and a limited rotating Common/occasional Uncommon selection; sell unwanted weapons/armor/scrap. Prices moderately above Solace to preserve tradeoff; sufficient and transparent merchant funding and clear buy/sell errors. No travel turns merely to trade. Quest/equipped item sale protections, inventory limits, persistence and no unintended story bypass. Avoid confusion with the separate Seaport **Rusty Anchor** tavern.
8. **Factory access structure:** **PRESERVE** the existing rule that **all three minibosses must be defeated to unlock the basement** and the Foreman. This was explicitly praised by Syn. Do **not** force clearing every Factory room or required encounters just to unlock minibosses. Exploring remains optional but worthwhile (better loot/lore/supplies/advantages); direct boss rushing is a legitimate route. The Factory remains accessible for replay after the demo, respecting existing enemy respawn rules. Future endless-descent challenge, global leaderboard and uniquely owned Legendary armor are **BACKLOG ONLY**—do not build them now. No fixed one-bandage challenge restriction.
9. **Main quest staging / narrative causality:** Preserve Tomorrow Project / New Dominion lore. When Factory reached, update objective to investigate Factory terminal; terminal explains communications with Seaport have ceased and points to Forge. Objective to speak to Forge. Use this approved line: **“Figured someone was coming when that terminal booted up. Damn thing’s been quiet for years.”** Forge explains boulder and dynamite plan. Clearly track component collection, return to Forge, crafted dynamite, destroy boulder, travel to Seaport, liberate town, visit Seaport Workshop terminal. Each stage must be persistent, replay-safe, and understandable, without conflicting status updates. **Do not assume miniboss component drops**—audit current Factory floors/quest architecture; components should be found in exploration/scenarios, but do not impose mandatory clear-every-room requirements. Resolve any design conflict minimally while preserving three-boss basement gate and deterministic acquisition of required quest items, not random loot drops. Don't invent unsupported component names. Do not reset existing quest progress.
10. **Road encounter overhaul:** Audit encounter generator and outcomes globally (Iron Choir, Lime Fog, Dust Horses etc.), not simply rewrite three snippets. Reduce repetitive `lose HP, gain XP/Bolts` vs `back away = nothing`; make risks, damage causes, loot discoveries, alternate outcomes meaningful and clearly narrated. Review East Road mix of combat, wanderers and discoveries, respecting cooldowns and random variation. Preserve established currency/materials/mechanics; keep rewards exploit-safe, correctly accounted, and save-stable.
11. **ASCII art at Level 5:** Add compact readable monospaced scenes for major locations/encounters/bosses, with gradual rollout and mobile readability. Level **5**, not 6. Preserve early presentation and existing casino visuals. Include eccentric Crazy Steve advertising casino games on an ASCII sandwich board, updated for new games, without breaking menus. Avoid lengthy scrolling art for routine actions.

## PHASE 3 — SEAPORT LIBERATION & PET MARKET (APPROVED MENU DESIGN)

12. **Enforce occupied/liberated town states, not just disabled services.** Before liberation only show:

```
=== OCCUPIED SEAPORT ===
1. Harbor Docks
2. Return West
```

At **Harbor Docks**, move existing working **Inspect Fishermen → Confront Fishermen** main-quest flow off the top-level menu; preserve the encounter. No premature Town Streets, Kaiden, vendor areas, Rusty Anchor/Mia, Pet Store or Demo Status. Protect underlying commands/routes as well as menu visibility against bypass.

13. **After winning fishermen battle:** Immediately show an in-context `1. Free the Survivors / 2. Back Away` prompt. Freeing survivors **completes liberation**, persists state, unlocks recruitment and post-liberation town options; `Back Away` keeps residents waiting without replaying battle or double-awarding combat. Do not require navigating to an unrelated empty area to free residents. Be clear that defeated enemies alone don't finish the liberation quest.

14. **After liberation top menu exactly five options:**

```
=== SEAPORT ===
1. Town Streets
2. Harbor Docks
3. Market Area
4. Rusty Anchor
5. Return West
```

**Market Area** (not available before liberation) has:

```
1. Clinic
2. General Store
3. Workshop
4. Bank
5. Pet Store
6. Return to Seaport
```

Clinic, General Store, Workshop and Bank remain **vacant/unavailable until their corresponding vendor is recruited** (can show `[VACANT]` after liberation, but no unstaffed services). The **Pet Store** is revealed and functional immediately after liberation; existing pet vendor does **not** need a recruit. The **Rusty Anchor** is separate, with Mia, games and consumables, and becomes accessible only after liberation. Keep meaningful Town Streets/Kaiden dialogue for post-liberation. Remove nonfunctional top-level `Demo Status`, avoid dead-end `Harbor Entrance → Return` and old empty `Free Residents → No one is here yet`; preserve any true internal dependencies rather than blindly deleting state. Do not add unnecessary extra top-level options. Return West works both states.

15. **Recruitment gating:** Wanderer recruitment is completely hidden/unavailable in UI, dialogue and actions **before** `Seaport liberated` flag; after liberation, wandering vendor recruitment and assignments function in player's own Seaport instance. Staffing and services survive save/reload. Don't confuse liberation (unlocks recruitment) with terminal completion (ends demo main story).

16. **Pet vendor improvements:** Preserve fixed menu escape/back behavior; show each current pet's **real** benefits, prices and owned/active state, with compact mobile copy; do not invent buffs for old pets. Preserve **Scrap Rat's Bolt-finding ability** and all existing creatures. Add **Pack Mule**, price **350 Bolts** (higher than the 230-Bolt ferret), **+2 inventory capacity while active**: usual 10 slots becomes 12. Pet bonuses do not stack if one active pet is the existing rule. If switching pets while carrying 11–12 items, never silently delete items; prevent new item intake until below active limit, with clear explanation. Test purchasing, equipping, switching, full-pack replacement, selling/trading, quest items, and saves. No combat bonus for Pack Mule. Descriptive line suggested: *“Stubborn, slow, and smells terrible. But it'll carry your junk without complaining. Much.”*

17. **Seaport Workshop terminal / demo finish:** After liberation main objective is visiting an accessible Tomorrow Project terminal *inside* the Workshop (coordinate carefully with Workshop recruitment: main quest terminal must be accessible even if business not staffed, e.g., a quest-only terminal interaction in otherwise vacant Workshop). Terminal restores transmissions with message along lines of **“Seaport is transmitting again… You gave these people a tomorrow.”** Mark main quest/demo completed **once** and save **before** credits. All exploration, recruitment, services and side quests continue; no hard end or forced new game. Terminal may be revisited without repeating completion rewards or forced movie.

## PHASE 4 — DELIGHTFUL, OPTIONAL DEMO CREDITS (NO GAME BLOCKERS)

18. **20-second cinema-style ANSI/terminal scrolling end credits:** Automatically play on the first successful Workshop terminal demo completion; approximately **20 seconds**, skippable by key/tap, no permanent input lock, and replayable through a **Credits** control on the right-side interface. Right-side control must be reachable on mobile without obstructing gameplay. Credits repeat the same three staff with knowingly absurd titles; preserve serious in-world tone until the movie credits. Suggested entries (adapt for rhythm):

```
ROUTE 127 — THE BEGINNING
A LAST LANTERN WORKSHOP PRODUCTION

GAME DIRECTOR                 SYN
LEAD DEVELOPER               FORGE
HEAD OF HUMAN RESOURCES      LUNA
DIRECTOR OF QUESTIONABLE DECISIONS  SYN
CHIEF BUG MANUFACTURER       FORGE
DIRECTOR OF BUG COMPLAINTS   LUNA
EXECUTIVE DIRECTOR OF MORE FEATURES SYN
EMPLOYEE MOST LIKELY TO NEED A RESTART FORGE
EMPLOYEE OF THE MONTH (SELF-APPOINTED) LUNA
ENTIRE ACCOUNTING DEPARTMENT SYN
UNPAID INTERN               FORGE
OFFICE MORALE               CHEESEBURGER

SPECIAL THANKS TO EVERYONE WHO BELIEVED
THREE IDIOTS COULD BUILD A WASTELAND.
```

19. **Running Cheeseburger Easter egg:** A tiny, amusing **animated pixel/ASCII cheeseburger with legs** runs across the bottom of the credits screen **twice**, first left-to-right, then right-to-left faster. It is a visual gag, **not** a fight, reward, interactive item or new enemy. Animation stays clipped within credit viewport, scales on mobile, and respects reduced-motion preferences. Keep credit text legible; don't obscure controls.
20. **Final demo message** after credits or when skipped:

```
THANK YOU FOR PLAYING THE ROUTE 127 DEMO!
THE ROAD DOESN'T END HERE.
Seaport has been liberated, and there's still more to explore.
Recruit survivors, rebuild your town, and explore the wasteland.
More adventures are coming.
PRESS ANY KEY / TAP TO CONTINUE
```

Afterward return to regular Seaport play; replayed credits should not set quest flags, change inventory, issue awards or strand the player. Verify single trigger, skip, replay, reduced-motion, mobile layout, switching tabs/reload, and normal game control afterward.

## RELEASE ACCEPTANCE / TEST MATRIX

- **Player build:** Must not expose QA/God Mode, hidden bypasses, pre-liberation vendors/recruitment, or progression shortcuts. **Development build:** preserve authorized QA testing bypasses, explicitly labelled and isolated.
- **Main path:** new character → Solace/Relay → Factory terminal and Forge → acquire/craft dynamite → three-miniboss basement gate/Foreman as currently designed → clear boulder → Seaport Harbor Docks inspect/confront → win fight → free survivors → terminal → credits → continued play. Where sequence differs in code, adapt without resetting playable saves or arbitrarily adding mandatory grind.
- **State transitions:** pre/post liberation menus, survivor prompt Back Away, boss gate, quest completion, vacant/staffed vendors, recruitment and credits flags all survive save/load and never duplicate rewards.
- **Inventory/economy:** 10 vs 12 slots, over-capacity pet swap, replacement confirmation, merchant funds, sales and quest protections; no lost items or dupes.
- **Controls:** each visible numbered option performs advertised action; `B` back works; no looping vendor menus, duplicated menus or disabled choice traps. All major flows tested on narrow mobile width as well as desktop.
- **Honest completion reporting:** For each requirement label **PASS tested / FIXED code-only (not runtime verified) / BLOCKED** with evidence. Archive historical issues in `QA_HISTORY.md`; don't indiscriminately report all 53 old items as current bugs.
- **Packaging:** one clean Development ZIP and one clean Player ZIP, matching version labels, no historical QA debris, no excess new document files. Preserve original artifacts and avoid modifying deployed/live website as part of this order.

---

## APPENDIX — PREVIOUSLY CONSOLIDATED OCT 15 + OCT 20 NOTES

These are incorporated as historical/test-reference material. **This work order's newer approved Seaport, Factory and credits decisions take precedence where older notes suggest a different flow.** Do not treat historical observations as current bugs without retesting.

# ROUTE 127 — CONSOLIDATED PLAYTEST FINDINGS & FORGE BACKLOG

**Compiled:** October 20, 2026  
**Current test build:** v55.5 R4 (cleaned development package)  
**Historical reference:** October 15 v55.4 comprehensive work order (53 findings), reproduced at end for completeness.

> **Status rule:** Old reports are historical, not proof a defect still exists in R4. Verify each against the current build before making changes. Items personally observed October 20 are marked **Observed R4**. Approved designs are **Requested**, not yet implemented or tested. Do not mark work done without verification.

## A. CURRENT PLAYTEST — OCTOBER 20 (PRIORITIZED)

### P0 — Functionality / progression

1. **Crafting after tutorial — Observed R4.** At Factory workbench, Workshop Kit displays Cloth 0/2 and Scrap Metal 0/1 even though player has scrap metal; text insists 'See Forge for Workshop Kit' despite tutorial already completed. Reproduce with save having tutorial complete and material in bag. Inspect recipe-unlock flags, actual material names/quantities, consumption, crafting timer, and save/load; fix underlying cause. Do not assume a specific cause.
2. **Relay quest components linger after installation — Observed R4; reported previously.** Player still has installed Relay parts listed in pack. Audit whether installed quest pieces should be consumed/flagged and removed; migrate existing saves without resetting completion or duplicating parts. Also reconcile with prior v55.4 finding about quest-only items appearing outside pack.
3. **Main-story causality and objective state — Requested redesign.** Preserve the existing world/faction lore; implement explicit, persistent quest stages below (section B). Existing side quests and boss rewards must continue to function.

### P1 — Gameplay and usability

4. **Pack full on road — Observed R4.** Currently silently forfeits Wire with 'Pack full, you leave the Wire behind'. Approved two options: `1. Leave Item Behind` / `2. Replace Item in Pack`. Replacing shows pack, lets player choose a discard candidate, confirms substitution, and protects equipped/quest items; warn before sacrificing Rare+ equipment. No free storage, extra pack capacity, or bypasses. Player is responsible for arriving with free room.
5. **Road encounter uniformity — Observed R4.** Iron Choir, Lime Fog, Dust Horses present repeated 'risk HP for Bolts+XP versus Back Away for nothing'. Overhaul encounter distribution and meaningful outcomes *globally*, not just text on these three: combat/wanderers/discovery balance; decisions, loot variety, clues, equipment/materials, moral trade-offs, consequences; contextual injury/loot explanations, plausible alternatives, occasional safe retreat. Reuse existing systems; no new currencies or invented mechanics. Check rewards and exploit loops, repetition, save/load, intended turns. Examples: Iron Choir needs coherent injury/guard alert explanation and reviewed choices; Lime Fog 'surveyor kit' narrative should match actual Wire + Bolts, or properly implement a kit; Dust Horses has plausible Bolt source but similar outcome loop. Earlier October 20 proposed 'tie off bells vs stumble escaping' is a requested change, not proof the code currently behaves that way.
6. **Selling Uncommon unequipped gear to wanderers — Observed R4 / cause unconfirmed.** Hollis the Cook refused Yardman's Wrench (12 Bolts) with generic 'Sale changed or funds insufficient'. Check wanderer funds, available cash display, item eligibility, and actual transaction logic. Return precise reason (including merchant balance). Retest same item with Johnny and a funded wanderer before claiming root cause; protect quest/equipped/Legendary gear appropriately.
7. **Quest journal — Requested.** `Q` opens `1. Active Quests / 2. Completed Quests` instead of a wall of text; active main objective first; progress and side objectives; only discovered quests; completed entries browseable; saves persist; no turns charged. Quest-stage update toast concise.
8. **Road mix — needs verification.** Three discoveries in a row on East Road; check intended distribution of real combat, wanderers, and narrative discoveries against actual weighted selectors and cooldowns. No assumption that random streak itself proves a bug.

### P2 — Presentation

9. **ASCII expansion unlocks at LEVEL 5, not level 6 — Approved.** Levels 1–4 existing progression unaffected. Level 5+ art in road scenarios, settlement exteriors, interiors, NPC/vendor spaces and special bosses; retain casino art; monospace/mobile-safe widths; avoid verbose repeated output, preserve hotkeys. Scenes from lore descriptions; bigger art for signature scenes. Introduce level-5 reveal, not a level-6 unlock.
10. **Crazy Steve ASCII — Approved.** Level 5+ sandwich-board character illustration when announcing new casino games; change message/board to reflect promoted games. Under Level 5 preserve text-only announcements. Do not change casino gameplay.
11. **Forge dialogue continuity — Approved exact direction.** Replace 'The terminal sent word you were coming' with natural reaction e.g. **'Figured someone was coming when that terminal booted up.'** Terminal activation alerts Forge by sound/activity, not a supernatural message.

## B. APPROVED MAIN QUEST FLOW — LEVELS 1–10 DEMO

1. Arrive Factory: mark previous travel objective complete; new **Investigate the Factory Terminal**.
2. Factory Tomorrow Project terminal: actual transmission reveals Seaport's contact lost; armed unknown group reported; tells player to find Forge. Update to **Talk to Forge**.
3. Forge: reacts to terminal boot ('Figured someone was coming when that terminal booted up.'), explains a boulder blocks East Road and dynamite requires four components from Factory. Objective **Find Four Components**.
4. Four guaranteed, discoverable components via exploration scenarios, distributed across Factory levels; **not miniboss loot**. Minibosses and final Foreman remain meaningful gates with existing gear rewards; Foreman is mandatory climactic obstacle. Make collection and quest state persistent and softlock-free; no unearned repeatable rewards.
5. Once four acquired, objective **Return to Forge**. Use existing real-time crafting to craft dynamite (after crafting issues are fixed), then **Destroy the Boulder**, then **Head to Seaport**. Do not consume components prematurely.
6. On Seaport entry, learn occupation is connected to New Dominion, objective **Liberate Seaport**; maintain existing liberation mechanics.
7. On liberation, **Go to the Seaport Workshop Terminal**. Place accessible Tomorrow Project communications terminal in Workshop; relay-restoration message closes the story, congratulates demo completion, advises there is still plenty to explore. Mark main quest complete after terminal interaction, persist, make replayable without re-awarding rewards. No forced endgame.
8. **Recruitment unlocks upon Seaport LIBERATION**, not upon finale terminal interaction. Before liberation, no recruitment prompts, options or hints at all.

## C. HISTORICAL NOTES / TRIAGE

The complete earlier v55.4 53-finding work order is preserved below, unedited in substance. Forge should compare each earlier bug with the cleaned R4 build and its `CHANGELOG.md`, `QA_HISTORY.md`, `DEVELOPMENT_NOTES.md` before changing any working system. Previously addressed bugs should be tagged **Fixed / Verified / Regressed / Still Open / Not Reproduced** rather than indiscriminately reimplemented.

Other recurring themes from October 17 playthrough: overall story lacks motivations and transitions; actual Factory and Seaport content needs hands-on playtest; challenge/depth are still weaker than intended. Preserve pacing and do not add unrelated new systems.

## D. IMPLEMENTATION / ACCEPTANCE RULES

- Work from **Route127_v55_5_R4_Development_Cleaned**; keep a clean original. The cleanup put historical QA scripts in an archive; extract only what tests require.
- Separate critical crafting/inventory fixes, story-quest refactor, road encounter pass, and ASCII art into independently testable commits/stages. Avoid unrelated code edits.
- Maintain existing save compatibility; provide migrations for quest flags/consumed items; test partial progress, repeat interactions, death/reload, full inventory, and zero-turn QA access.
- Validate main quest in a fresh and existing save from Factory → Forge → components → dynamite → boulder → Seaport → liberation → terminal; check that post-liberation recruitment remains gated correctly.
- Update **only** existing `CHANGELOG.md`, `QA_HISTORY.md`, `DEVELOPMENT_NOTES.md` for routine documentation. No more tiny reports; historical archive retained separately.
- No assumptions of PASS based only on static checks. Include tests, actual findings, and anything not verified.
- Keep the **Player** bundle free of QA-only tools. Do not modify live playtest/game deployment without the user's instruction.

---

# APPENDIX — OCTOBER 15 PLAYTEST WORK ORDER (HISTORICAL SOURCE)

# 🔧 FORGE — ROUTE 127 v55.5 WORK ORDER

## Comprehensive Playtest Repairs, Encounter Balance & Interface Stabilization

**Baseline:** Route 127 v55.4 Development ZIP\
&#x20;**Source:** Syn's October 15 playtest — 53 findings and development requests.

### MISSION

Repair confirmed bugs, implement approved encounter and NPC improvements, and stabilize Route 127 for another complete Level 1–10 playtest.

**Priorities:**

1. &#x20;Eliminate game-wide duplicate menus.&#x20;
2. &#x20;Repair quest tracking and QA access.&#x20;
3. &#x20;Improve encounter variety, combat balance, and rewards.&#x20;
4. &#x20;Streamline NPC interactions, inventory, and services.&#x20;
5. &#x20;Preserve all completed gameplay systems and save compatibility.&#x20;

### NON-NEGOTIABLE REQUIREMENTS

- &#x20;Preserve all existing saves, characters, quests, pets, equipment, and completed fixes.&#x20;
- &#x20;Inspect actual v55.4 code before modifying mechanics.&#x20;
- &#x20;Make targeted repairs; do not rewrite functioning systems.&#x20;
- &#x20;Preserve the existing gradual ANSI color progression and planned Level 10 pixel-art transition.&#x20;
- &#x20;Do not rebalance Factory bosses or change completed Seaport progression.&#x20;
- &#x20;Do not perform a lengthy browser playthrough.&#x20;
- &#x20;Run targeted automated tests and regression checks.&#x20;
- &#x20;Deliver Development and Player ZIPs, changelog, and QA report.&#x20;
- &#x20;Do not silently discard any work-order requirements.&#x20;

---

# 🔴 PHASE 1 — CRITICAL BUG REPAIRS

### 1. Game-Wide Duplicate Menu Rendering

**Highest priority.**

Syn reports duplicate menus throughout v55.4, particularly after the most recent fix.

Confirmed examples:

- &#x20;Save/Load menu displays twice.&#x20;
- &#x20;Town navigation.&#x20;
- &#x20;Jen's bar.&#x20;
- &#x20;Vendor selling interfaces.&#x20;
- &#x20;Other repeated interaction menus.&#x20;

**Required:**

- &#x20;Compare v55.3 and v55.4 menu-rendering changes.&#x20;
- &#x20;Identify the shared cause.&#x20;
- &#x20;Prevent duplicate output from menu transitions, command handling, and repeated callbacks.&#x20;
- &#x20;Preserve numeric commands, hotkeys, and existing functionality.&#x20;
- &#x20;Test every major NPC and location menu.&#x20;

Do not merely hide duplicate text.

### 2. Zero-Turn QA Access

At zero remaining turns, Syn could not enter Testing Mode.

**Required:**

- &#x20;Authorized QA Mode must remain accessible at zero turns.&#x20;
- &#x20;Allow QA turn replenishment without resetting the character.&#x20;
- &#x20;Preserve quests, equipment, location, and save state.&#x20;
- &#x20;Keep ordinary player restrictions intact.&#x20;
- &#x20;Prevent QA commands from becoming accessible in Player builds.&#x20;

### 3. Relay Station Quest Component Audit

Playtest observations:

- &#x20;Power Regulator obtained from Johnny but not visible in regular inventory.&#x20;
- &#x20;Antenna Servo required multiple Maintenance Yard searches.&#x20;
- &#x20;Shielded Coupler required leaving and returning.&#x20;
- &#x20;Player initially believed installation was unavailable but subsequently remembered the fourth component.&#x20;

**Required:**

- &#x20;Verify all four component acquisition conditions.&#x20;
- &#x20;Verify quest journal tracking.&#x20;
- &#x20;Confirm intentional quest items remain outside the 10-slot backpack.&#x20;
- &#x20;Ensure collected components display consistently.&#x20;
- &#x20;Prevent duplicate component acquisition.&#x20;
- &#x20;Verify installation works after all four components are obtained.&#x20;
- &#x20;Preserve existing main quest progression.&#x20;

Do not classify the installation menu as broken solely because the fourth component was missing.

### 4. ANSI Color Rendering

Observed:

- &#x20;Random blue letter inside ordinary “tire iron” text.&#x20;
- &#x20;Hollis's entire dialogue and description rendered green instead of only his name.&#x20;

**Required:**

- &#x20;Audit color-span boundaries and reset behavior.&#x20;
- &#x20;Prevent NPC name colors from leaking into surrounding text.&#x20;
- &#x20;Preserve rarity colors and level-dependent presentation.&#x20;

---

# 🟠 PHASE 2 — ENCOUNTER BALANCE & VARIETY

### 5. Encounter Reward Audit

**Fundamental rule:** Combat should generally award more XP than safer alternatives within the same encounter.

Confirmed examples:

| Encounter          | Choice                    | Observed result         |
| ------------------ | ------------------------- | ----------------------- |
| Roach Nest         | Kick Open Can             | −9 HP, +20 XP, +7 Bolts |
| Roach Nest         | Attack                    | +18 XP, +4 Bolts        |
| Highway Robbers    | Run, spear catches player | −6 HP, +6 XP            |
| Broken Cleaner Bot | Wait for battery          | +7 XP, +3 Bolts         |

Audit all encounter branches.

**Balance guidelines:**

- &#x20;Combat: Highest XP and appropriate loot.&#x20;
- &#x20;Successful risky skill checks: Moderate XP.&#x20;
- &#x20;Clever problem-solving: Modest XP.&#x20;
- &#x20;Passive waiting, leaving, or escaping: Generally zero XP.&#x20;
- &#x20;Rewards must reflect actual danger and resource consumption.&#x20;

Preserve existing nighttime XP bonuses.

### 6. Encounter Repetition

Syn encountered the Roach Nest multiple times and repeatedly encountered Hollis.

**Required:**

- &#x20;Audit actual encounter pool size.&#x20;
- &#x20;Audit spawn weights and repetition frequency.&#x20;
- &#x20;Introduce temporary repeat protection.&#x20;
- &#x20;Preserve repeatable encounters and persistent wanderer inventories.&#x20;
- &#x20;Expand encounter variety where necessary.&#x20;

### 7. Wanderer Levels

Earlier source inspection identified 12 named wanderers with fixed levels approximately 2–5.

**Required:**

- &#x20;Verify v55.4 definitions.&#x20;
- &#x20;Expand appropriate wanderer difficulty toward Levels 1–10.&#x20;
- &#x20;Ensure higher-level wanderers appear as players progress.&#x20;
- &#x20;Preserve recurring character identities and persistence.&#x20;

### 8. Security Drone

Verify actual outcomes for:

- &#x20;Fight/Smash Drone.&#x20;
- &#x20;Circle Behind.&#x20;
- &#x20;Move On.&#x20;

Ensure Circle Behind provides a meaningful risk/reward opportunity while Move On safely ends the encounter without rewards.

### 9. Highway Robbers

Two enemies: tire iron and spear.

Implement meaningful multi-enemy combat with individual enemy HP and loot.

**Run:**

- &#x20;Proposed 60% success / 40% failure, subject to existing balance audit.&#x20;
- &#x20;Successful escape: No XP.&#x20;
- &#x20;Failed escape: −15 HP, no XP.&#x20;

**Throw 5 Bolts:** Safe escape without XP.

### 10. Gang Lookout

Lookout has three combat rounds to signal reinforcements.

Proposed enemy statistics:

- &#x20;Lookout: 18 HP.&#x20;
- &#x20;Leader: 35 HP.&#x20;
- &#x20;Two members: 20 HP each.&#x20;
- &#x20;Maximum two enemy attacks per combat round.&#x20;

Stopping the signal should provide a tactical advantage.

### 11. Yardman

Increase difficulty:

- &#x20;55 HP.&#x20;
- &#x20;Standard damage 7–12.&#x20;
- &#x20;Occasional heavy swing 13–16.&#x20;
- &#x20;Appropriate miss chance.&#x20;
- &#x20;Improved loot.&#x20;

Preserve quest completion and rewards.

### 12. Other Encounter Improvements

Audit and improve:

- &#x20;Six-Toed Footprints.&#x20;
- &#x20;Garden Gnomes.&#x20;
- &#x20;Dust Over Schoolyard: increase dust damage from 2 to 10 HP.&#x20;
- &#x20;Service Road random encounters.&#x20;
- &#x20;Torn Backpack and Broken Radio salvage.&#x20;
- &#x20;Wheelbarrow snake encounter.&#x20;
- &#x20;Missing Stairs floor collapse.&#x20;
- &#x20;Lone Scavenger trade and intimidation.&#x20;
- &#x20;Sprained Runner.&#x20;
- &#x20;Broken Cleaner Bot battery description and passive rewards.&#x20;

Combat must close the current encounter; noncombat investigation options may remain available until combat begins.

---

# 🟡 PHASE 3 — NPC INTERACTIONS & QUESTS

### 13. Solace Gate

Introduce the armed guard encounter with meaningful dialogue options:

1. &#x20;Abandoned terminal sent me here.&#x20;
2. &#x20;Looking to trade.&#x20;
3. &#x20;Looking for the Relay Station.&#x20;
4. &#x20;Just passing through.&#x20;
5. &#x20;Pick a fight.&#x20;

Preserve quest unlocks and access rules.

Include the approved one-time Jen rescue after defeat by gate guards, with normal death penalties and preserved bounty.

### 14. Tim

Consolidate Talk:

1. &#x20;About Solace.&#x20;
2. &#x20;Work.&#x20;
3. &#x20;Bounties.&#x20;
4. &#x20;Collect Bounty.&#x20;
5. &#x20;Pay Off Bounty.&#x20;
6. &#x20;Relay Station.&#x20;
7. &#x20;Never Mind.&#x20;

Add approved Terrible Billy and Trouble at Old House bounty quests.

Bounty boards remain informational; proof collection triggers payment.

### 15. Jen

Preserve the existing tavern introduction.

Update her character description to reflect her confidence, wit, mischievous eyes, kindness, and strength.

Repair dialogue incorrectly routing to Tim.

Talk categories:

- &#x20;Solace.&#x20;
- &#x20;Road.&#x20;
- &#x20;Work.&#x20;

Preserve Last Call and add Unpaid Tab and A Familiar Face.

### 16. Johnny

Simplify:

1. &#x20;View Stock.&#x20;
2. &#x20;Sell Items.&#x20;
3. &#x20;Talk.&#x20;
4. &#x20;Back.&#x20;

Preserve Deal Gone Bad and existing inventory rotation.

### 17. Murphy

Use:

```
```

```
MURPHY'S WORKSHOP

[1] CRAFTING RECIPES
[2] INSPECT CORVETTE
[3] TALK
(B) BACK
```

Talk:

1. &#x20;Ask About Work.&#x20;
2. &#x20;Ask About Corvette.&#x20;
3. &#x20;Ask About Relay Station.&#x20;
4. &#x20;Back.&#x20;

Preserve One Good Belt, crafting, and Corvette foreshadowing.

Do not unlock Corvette fast travel yet.

### 18. Wayne

Talk:

1. &#x20;Ask About Work.&#x20;
2. &#x20;Ask About Solace.&#x20;
3. &#x20;Ask About Road.&#x20;
4. &#x20;Back.&#x20;

Preserve The Last Patient and Old House quests, healing services, and house storage unlock.

### 19. Amii

Add TALK to her banking menu.

Talk:

1. &#x20;Ask About Banking.&#x20;
2. &#x20;Ask About Niko and Alex.&#x20;
3. &#x20;Back.&#x20;

Preserve secure bank storage and existing dog dialogue.

### 20. Wanderer Interactions

Audit:

- &#x20;Talk dialogue variety.&#x20;
- &#x20;Failed theft reactions.&#x20;
- &#x20;Theft lockouts.&#x20;
- &#x20;Crime escalation.&#x20;
- &#x20;Browse Wares functionality.&#x20;
- &#x20;Persistent inventory.&#x20;
- &#x20;Repeat encounters.&#x20;

Avoid redundant nested Talk commands and duplicate choices.

Preserve established bounty values unless changes are explicitly approved.

---

# 🟢 PHASE 4 — INVENTORY, EQUIPMENT & SERVICES

### 21. Selling Interface

Replace cumbersome nested selling menus.

- &#x20;Display inventory with prices immediately.&#x20;
- &#x20;Single-item sales complete directly.&#x20;
- &#x20;Stacked items support quantity selection.&#x20;
- &#x20;Rare/Epic equipment requires confirmation.&#x20;
- &#x20;Protect equipped and quest items.&#x20;
- &#x20;Prevent duplication and incorrect Bolt calculations.&#x20;

### 22. Rusty Lantern Player Room

One-time 500-Bolt purchase.

Display:

```
```

```
THE RUSTY LANTERN
<CHARACTER NAME>'S ROOM
```

Include:

- &#x20;Rest.&#x20;
- &#x20;Chest.&#x20;
- &#x20;Look Around.&#x20;
- &#x20;Return.&#x20;

Rest effectiveness per game day:

- &#x20;First: 100%.&#x20;
- &#x20;Second: 75%.&#x20;
- &#x20;Third: 50%.&#x20;
- &#x20;Fourth: 25%.&#x20;
- &#x20;Fifth onward: 0%.&#x20;

Room is safe from attacks.

Chest remains potentially vulnerable to future player theft; Amii's bank is completely secure.

### 23. Gambling

Levels 1–4:

- &#x20;Dice.&#x20;
- &#x20;Rock-Paper-Scissors.&#x20;
- &#x20;Blackjack.&#x20;

Level 5+:

- &#x20;Slots.&#x20;

Seaport:

- &#x20;Rat Racing.&#x20;

Preserve proper betting and payout accounting.

### 24. Accessories

Implement one accessory equipment slot.

Common:

- &#x20;Worn Leather Wristband.&#x20;
- &#x20;Lucky Bottle Cap.&#x20;
- &#x20;Reinforced Belt.&#x20;

Uncommon:

- &#x20;Scavenger's Charm.&#x20;
- &#x20;Rusted Dog Tags.&#x20;
- &#x20;Road Warrior's Bracelet.&#x20;

Rotate accessories through Mara's inventory.

### 25. Niko's Rewards

After existing Niko/Alex dialogue:

- &#x20;Pet Alex: Barking reaction, no damage.&#x20;
- &#x20;Pet Niko: One randomized reward per character.&#x20;

Reward table:

- &#x20;30% Niko's Lucky Vest.&#x20;
- &#x20;25% Giant Dog Bone.&#x20;
- &#x20;25% Rusty License Plate.&#x20;
- &#x20;15% Level-appropriate Rare equipment.&#x20;
- &#x20;5% Legendary Niko's Collar.&#x20;

Collar:

- &#x20;+15 max HP.&#x20;
- &#x20;+3 DEF.&#x20;
- &#x20;+2% critical chance.&#x20;
- &#x20;Once-per-game-day Second Chance at 1 HP.&#x20;

Prevent repeated reward farming.

True global uniqueness requires shared-world ownership infrastructure; do not falsely implement local-only tracking as globally unique.

### 26. Cheeseburger

Legendary pet rat obtained through a 5% slot jackpot.

- &#x20;+6 inventory slots.&#x20;
- &#x20;Ordinary Pack Rat: +2 slots.&#x20;
- &#x20;Crazy Steve presents the jackpot.&#x20;
- &#x20;One globally when multiplayer ownership tracking is available.&#x20;
- &#x20;No trading, selling, or duplication.&#x20;

Preserve Seaport rat racing.

---

# 🔵 PHASE 5 — PROGRESSION & WORLD SYSTEMS

### 27. Random Equipment Drops

Target distribution:

- &#x20;Common: 55%.&#x20;
- &#x20;Uncommon: 30%.&#x20;
- &#x20;Rare: 13%.&#x20;
- &#x20;Epic: 2%.&#x20;

Preserve guaranteed quest and boss rewards.

### 28. Factory Crafting Progression

Verify approved Iron Reaper blueprint:

- &#x20;Level 6.&#x20;
- &#x20;18–27 damage.&#x20;
- &#x20;Optional 10% bleed chance.&#x20;
- &#x20;8 Scrap, 4 Wire, 3 Cloth, 75 Bolts.&#x20;

Preserve existing crafting unlocks and timers.

### 29. Day/Night Cycle

Audit actual day/night transition rules.

Syn observed darkness beginning early and persisting through extended town interactions.

Verify:

- &#x20;Turn thresholds.&#x20;
- &#x20;Day advancement.&#x20;
- &#x20;Nighttime damage bonus.&#x20;
- &#x20;Nighttime XP bonus.&#x20;
- &#x20;Zero-turn town interactions.&#x20;

Do not change timing without establishing existing behavior.

### 30. Service Road Navigation

Audit Walk Back and reverse-direction choices.

Avoid duplicate travel commands and incorrect turn costs.

### 31. Solace Town Navigation

Remove obsolete visible typed-command prompts where numbered menus already exist.

Preserve compatible hidden typed commands.

---

# 🧪 PHASE 6 — REGRESSION TESTING

Forge must test:

1. &#x20;Every major menu displays exactly once.&#x20;
2. &#x20;All numbered choices and hotkeys work.&#x20;
3. &#x20;Save/load preserves inventory, quests, and location.&#x20;
4. &#x20;QA Mode remains accessible at zero turns.&#x20;
5. &#x20;Relay components can be acquired and installed.&#x20;
6. &#x20;Encounter XP and rewards match intended risk.&#x20;
7. &#x20;Combat does not duplicate rewards.&#x20;
8. &#x20;Wanderer encounters retain persistent identities.&#x20;
9. &#x20;NPC dialogue routes correctly.&#x20;
10. &#x20;Quest rewards cannot be farmed.&#x20;
11. &#x20;Storage and banking remain secure and persistent.&#x20;
12. &#x20;Pets and accessories survive save/load.&#x20;
13. &#x20;Gambling cannot duplicate payouts.&#x20;
14. &#x20;Level-dependent colors render correctly.&#x20;
15. &#x20;Factory and Seaport progression remain functional.&#x20;

**Use targeted automated testing. Do not conduct a full browser playthrough.**

---

# 📦 REQUIRED DELIVERABLES

1. **Route127_v55_5_Development.zip**&#x20;
2. **Route127_v55_5_Player.zip**&#x20;
3. &#x20;Detailed CHANGELOG.&#x20;
4. &#x20;QA report showing passed tests, failures, and remaining issues.&#x20;
5. &#x20;Updated browser-openable playtest checklist.&#x20;

**If any feature cannot be completed safely, document it explicitly rather than silently omitting it.**

---

### FINAL INSTRUCTION TO FORGE

**Fix the game-wide duplicate menu regression first.** It is the primary blocker preventing comfortable playtesting.

Preserve everything that already works.

Proceed autonomously with approved repairs and testing. Only request clarification for significant design conflicts or destructive changes.

**Objective: Deliver a stable v55.5 build ready for Syn's next playtest.**